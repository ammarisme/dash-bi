import sys
import time

from sqlalchemy import func
from sqlalchemy.orm import Session

from hrc.common.database import get_mysql_connection
from hrc.integration_db.models import JobDemographic, IClaim, ClaimDemographic
from hrc.settings import CONFIGURATION


def create_demo_job(engine, license_key):
    session = Session(bind=engine, expire_on_commit=False, autocommit=True)
    with session.begin():
        job_demographic = JobDemographic()
        job_demographic.IntegrationStatus = 0
        job_demographic.LicenseKey = license_key
        session.add(job_demographic)

    session = Session(bind=engine, expire_on_commit=False, autocommit=True)
    with session.begin():
        job_demo_id = session.query(func.max(JobDemographic.id)).scalar()
        return job_demo_id

    return None


def accumulate_all_pending_demo(license_key, demo_job_id, engine,
                                intake_status=None, no_status_change=False):
    session = Session(bind=engine, expire_on_commit=False, autocommit=True)
    no_status_change = intake_status != 200
    with session.begin():
        if intake_status is not None:
            pending_claims = session.query(IClaim).filter(
                IClaim.LicenseKey == license_key,
                IClaim.IntegrationStatus == intake_status).all()
        else:
            pending_claims = session.query(IClaim).filter(
                IClaim.LicenseKey == license_key,
                IClaim.IntegrationStatus.in_(
                    (200,)
                )).all()
        claim_demos = []
        for claim in pending_claims:
            claim_demographic = ClaimDemographic()
            claim_demographic.IntegrationStatus = 0
            claim_demographic.LicenseKey = license_key
            claim_demographic.claimid = claim.claimid
            claim_demographic.job_demo_id = demo_job_id

            claim_demos.append(claim_demographic)
        claimids = [claim.claimid for claim in pending_claims]
        upd = session.query(IClaim).filter(IClaim.claimid.in_(claimids)).update({
            IClaim.IntegrationStatus: 220},
            synchronize_session=False)

        session.add_all(claim_demos)


def redistribute_claims_of_job(split_into, demo_job_id, license_key, engine=None):
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        max_jobid = session.query(func.max(JobDemographic.id)).scalar()
        for i in range(split_into):
            jobid = max_jobid + i + 1
            job = JobDemographic(
                LicenseKey=license_key,
                id=jobid,
                IntegrationStatus=0,
                ParentJob=demo_job_id
            )
            session.add(job)

    session = Session(autocommit=True, bind=engine)
    with session.begin():
        pending_claims = session.query(ClaimDemographic).filter(ClaimDemographic.job_demo_id == demo_job_id).all()
        claimids = [claim.claimid for claim in pending_claims]

        for i in range(split_into):
            jobid = max_jobid + i + 1
            start = 1 + int(len(claimids) / split_into) * (i)
            end = (i + 1) * int(len(claimids) / split_into)
            print(start, end)
            setclaims = claimids[start:end]
            setclaims = tuple(setclaims)
            upd = session.query(ClaimDemographic).filter(ClaimDemographic.claimid.in_(setclaims)) \
                .update({ClaimDemographic.job_demo_id: jobid}, synchronize_session=False)


def stop_all_demojob_containers(docker_client, license_key):
    containers = docker_client.containers.list()
    number_of_containers = len(containers)
    print("Currently running :", number_of_containers)
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-demo-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            container.kill()

    return number_of_containers


def start_all_demo_jobs(docker_client, license_key, chained, intake_status=0, sleep_time=60, engine=None):
    containers = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_demo_claims_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        cursor.close()
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)

    for job in pending_claims:
        try:
            print('running : ', job[0])
            cont = start_demo_job(
                jobid=job[0], templateid='1', license_key=job[1],
                docker_client=docker_client, intake_status=intake_status,
                chained=chained
            )
            containers.append(cont)
        except:
            print(sys.exc_info())
    return containers


def start_demo_job(license_key, jobid, templateid, intake_status, docker_client, chained):
    docker_mode = CONFIGURATION.MODE
    env_variables = dict({'MODE': docker_mode,
                          'JOB_ID': jobid,
                          'TEMPLATE_ID': templateid,
                          'NETWORK': 'host',
                          'INTAKE_STATUS': intake_status,
                          "CHAINED": chained
                          })

    print(env_variables)
    cont = docker_client.containers.run(image="demo-job-runner",
                                        environment=env_variables
                                        , detach=True
                                        , name=str(license_key) + '-demo-job-runner-' + str(jobid)
                                        , network="host"
                                        )
    return cont
