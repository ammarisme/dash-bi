import copy
import os


class configuration():
    def __init__(self, mode):
        self.MODE = mode
        self.FTP_LOCATION = None
        self.FTP_PORT = None
        self.FTP_USERNAME = None
        self.FTP_PASSWORD = None

        self.DB_HOST_NAME = None
        self.DB_HOST_NAME_DOCKER = None
        self.DB_NAME = None

        self.DOCKER_HOST = None
        self.DOCKER_DOCKER_HOST = None

        self.MONGO_CON_STRING = None
        self.DOCKER_MONGO_CON_STRING = None

        self.MYSQL_USER = None
        self.MYSQL_PASSWORD = None
        self.SAVE_FTP = False
        self.API_URL_DOCKER = None
        self.API_URL = None
        self.OPS_USER_TOKEN = None

        self.DATEFORMAT = "%#m/%#d/%Y %#I:%#M:%#s %p"
        self.UHC_CLIENT_ID = None
        self.UHC_CLIENT_SECRET = None
        self.UHC_OAUTH_URL = None
        self.ALLOWED_METHODSs = ['get', 'post', 'put', 'delete', 'head', 'options', 'trace']
        self.DEFAULTS = None
        self.set_application_environement_settings(mode)

    def set_application_environement_settings(self, mode):
        print('Application mode :', mode)
        self.MODE = mode
        if mode == 'qatest':
            self.FTP_LOCATION = '119.235.4.18'
            self.FTP_PORT = '21'
            self.FTP_USERNAME = 'qatest'
            self.FTP_PASSWORD = '4\\\FT`SeeC5ggb6]'  # 4\\FT`SeeC5ggb6]
            self.DB_HOST_NAME = '20.0.0.110:3306'
            self.DB_HOST_NAME_DOCKER = '20.0.0.110:3306'
            self.DB_NAME = 'dev'
            self.API_URL = 'http://127.0.0.1:4000'
            self.API_URL_DOCKER = 'http://host.docker.internal:4000'
            self.DOCKER_HOST = 'tcp://127.0.0.1:2375'
            self.DOCKER_DOCKER_HOST = 'tcp://host.docker.internal:2375'
            # self.MONGO_CON_STRING = 'mongodb://host.docker.internal:27017/admin'
            self.MONGO_CON_STRING = 'mongodb://20.0.0.110:27017/'
            self.DOCKER_MONGO_CON_STRING = 'mongodb://20.0.0.110:27017/'
            self.MYSQL_USER = 'application_user'
            self.MYSQL_PASSWORD = "abcd@1234"
            self.SAVE_FTP = False
            self.OPS_USER_TOKEN = 'cbbdea3cf9b1872855af2b777eba765a0f7721c598f82cb1d13dfe563d4629d89b0cff8a4e50df06b8c00135d1ed8932bb31e8d78a522cd8fafaaee5ac06d6d9'
            self.RM_QUEUE_SERVER = '20.0.0.110'
            self.RM_QUEUE_USER = 'admin_rabbit'
            self.RM_QUEUE_PASSWORD = 'abcd@1234'
            self.RM_QUEUE_PORT = 5672
            self.UHC_CLIENT_ID = 'hlth_recon_stg'
            self.UHC_CLIENT_SECRET = '8f405e28-4d84-43a3-aa0e-ae91c5ee54e8'
            self.UHC_OAUTH_URL = 'https://api-gateway-stage.linkhealth.com/oauth/token/'
            self.CSE_PROXY_USER = 'user1'
            self.CSE_PROXY_PASSWORD = 'Hrc@#123456*.'
            self.CSE_PROXY_SERVER = '34.238.59.233'
            self.CSE_PROXY_SERVER_PORT = '3128'
            self.CSE_CLIENT_ID = 'b8a75ed7-2bc6-466a-8cb1-97bac9b05d34'
            self.CSE_CLIENT_SECRET = 'gY2uW4cR4eJ2qO4nS1pX3gE3fV5rO4uO8cV5bY5jW2dE6hF4bU'
            self.SFTP_FILE_SERVER_ADDRESS = '//20.0.0.10/Other Operations/Automation/Billing Auto SFTP Testing/qa/'
            self.MSSQL_SERVER_ADDRESS = '20.0.0.110\SQLEXPRESS,1433'
            self.MSSQL_USERNAME = 'dev_user'
            self.MSSQL_PASSWORD = 'abcd@1234'
            self.REDIS_HOST = '20.0.0.110'
            self.REDIS_PORT = 6379
            self.REDIS_PASSWORD = 'abcd@1234'
            self.BLOB_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=hrclabs;AccountKey=oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q==;EndpointSuffix=core.windows.net'
            self.BLOB_ACCOUNT_NAME = 'hrclabs'
            self.BLOB_ACCOUNT_KEY = 'oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q=='
            self.FIREBASE_API_KEY = "AAAAP0P-qWQ:APA91bGu33JkuB3e09tqKv07hXhXf17VGc5rrI8xqRNWlNqX-a5-GVH6nxU72DHl8AlG6PeFxtRmFz45xWWsXvrKbEMQ4bRHqQquHsAkknOw7L3-Eq9P7FVkJoZG9WN_Xs5emL9URuDC"

        if mode == 'production':
            self.FTP_LOCATION = '119.235.4.18'
            self.FTP_PORT = '21'
            self.FTP_USERNAME = 'qatest'
            self.FTP_PASSWORD = '4\\\FT`SeeC5ggb6]'  # 4\\FT`SeeC5ggb6]
            self.DB_HOST_NAME = '20.0.2.95:3306'
            self.DB_HOST_NAME_DOCKER = '20.0.2.95:3306'
            # self.DB_HOST_NAME = 'new-automation-production.mysql.database.azure.com:3306'
            # self.DB_HOST_NAME_DOCKER = 'new-automation-production.mysql.database.azure.com:3306'
            self.DB_NAME = 'production_5162021'
            self.API_URL = 'http://20.0.2.93:8000'
            self.API_URL_DOCKER = 'http://host.docker.internal:8000'
            self.DOCKER_HOST = 'tcp://127.0.0.1:2375'
            self.DOCKER_DOCKER_HOST = 'tcp://host.docker.internal:2375'
            # self.MONGO_CON_STRING = 'mongodb://host.docker.internal:27017/admin'
            # mongodb: // admin: abcd % 401234 @ 20.0.0.192: 27017 / admin
            self.MONGO_CON_STRING = 'mongodb://20.0.0.192:27017/production'
            self.DOCKER_MONGO_CON_STRING = 'mongodb://20.0.0.192:27017/production'
            self.MYSQL_USER = 'integration_user'
            self.MYSQL_PASSWORD = "N3w3r@123"
            self.SAVE_FTP = True
            self.OPS_USER_TOKEN = 'cbbdea3cf9b1872855af2b777eba765a0f7721c598f82cb1d13dfe563d4629d89b0cff8a4e50df06b8c00135d1ed8932bb31e8d78a522cd8fafaaee5ac06d6d9'
            self.RM_QUEUE_SERVER = '20.0.2.95'
            self.RM_QUEUE_USER = 'admin_rabbit'
            self.RM_QUEUE_PASSWORD = 'abcd@1234'
            self.RM_QUEUE_PORT = 5672
            self.SFTP_FILE_SERVER_ADDRESS = '//20.0.0.10/Other Operations/Automation/SFTP Folders/'
            self.BLOB_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=hrclabs;AccountKey=oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q==;EndpointSuffix=core.windows.net'
            self.BLOB_ACCOUNT_NAME = 'hrclabs'
            self.BLOB_ACCOUNT_KEY = 'oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q=='
            self.FIREBASE_API_KEY = "AAAAG82QBOw:APA91bGEjoTXoFm2gwRWv7aFeBzKfDIhDskt88OmWCfA2vZHdog7ifLpWzZQRPlr75wP3LCaykrAgc_gaUknU3HU0QNIHy4B7bUoqNLJbVSdQoc9MdzA8gjb5IYTPMDfgBwiz-UU6NnG"

        if mode == 'developer':
            self.FTP_LOCATION = '119.235.4.18'
            self.FTP_PORT = '21'
            self.FTP_USERNAME = 'qatest'
            self.FTP_PASSWORD = '4\\\FT`SeeC5ggb6]'  # 4\\FT`SeeC5ggb6]

            self.DB_HOST_NAME = 'hrc-cloud-db-server.mysql.database.azure.com:3306'
            self.DB_HOST_NAME_DOCKER = 'host.docker.internal:3306'
            self.DB_NAME = 'dev'
            self.API_URL = 'http://127.0.0.1:8000'
            self.API_URL_DOCKER = 'http://host.docker.internal:8000'
            self.DOCKER_HOST = 'tcp://127.0.0.1:2375'
            self.DOCKER_DOCKER_HOST = 'tcp://host.docker.internal:2375'
            # self.MONGO_CON_STRING = 'mongodb://host.docker.internal:27017/admin'
            self.MONGO_CON_STRING = 'mongodb://admin:abcd%401234@127.0.0.1:27017/admin'
            self.DOCKER_MONGO_CON_STRING = 'mongodb://admin:abcd%401234@host.docker.internal:27017/admin'
            self.MYSQL_USER = 'integration_user'
            self.MYSQL_PASSWORD = "abcd@1234!"
            self.SAVE_FTP = True
            self.OPS_USER_TOKEN = 'cbbdea3cf9b1872855af2b777eba765a0f7721c598f82cb1d13dfe563d4629d89b0cff8a4e50df06b8c00135d1ed8932bb31e8d78a522cd8fafaaee5ac06d6d9'
            self.RM_QUEUE_SERVER = 'localhost'
            self.RM_QUEUE_USER = 'admin_rabbit'
            self.RM_QUEUE_PASSWORD = 'abcd@123'
            self.RM_QUEUE_PORT = 5672
            self.BLOB_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=hrclabs;AccountKey=oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q==;EndpointSuffix=core.windows.net'
            self.BLOB_ACCOUNT_NAME = 'hrclabs'
            self.BLOB_ACCOUNT_KEY = 'oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q=='
            self.FIREBASE_API_KEY = "AAAAG82QBOw:APA91bGEjoTXoFm2gwRWv7aFeBzKfDIhDskt88OmWCfA2vZHdog7ifLpWzZQRPlr75wP3LCaykrAgc_gaUknU3HU0QNIHy4B7bUoqNLJbVSdQoc9MdzA8gjb5IYTPMDfgBwiz-UU6NnG"

        if mode == 'dev':
            self.FTP_LOCATION = '119.235.4.18'
            self.FTP_PORT = '21'
            self.FTP_USERNAME = 'qatest'
            self.FTP_PASSWORD = '4\\\FT`SeeC5ggb6]'  # 4\\FT`SeeC5ggb6]
            self.DB_HOST_NAME = '20.0.2.95:3306'
            self.DB_HOST_NAME_DOCKER = '20.0.2.95:3306'
            self.DB_NAME = 'dev'
            self.API_URL = 'http://127.0.0.1:4000'
            self.API_URL_DOCKER = 'http://host.docker.internal:4000'
            self.DOCKER_HOST = 'tcp://127.0.0.1:2375'
            self.DOCKER_DOCKER_HOST = 'tcp://host.docker.internal:2375'
            # self.MONGO_CON_STRING = 'mongodb://host.docker.internal:27017/admin'
            self.MONGO_CON_STRING = 'mongodb://20.0.2.95:27017/'
            self.DOCKER_MONGO_CON_STRING = 'mongodb://20.0.2.95:27017/'
            self.MYSQL_USER = 'application_user'
            self.MYSQL_PASSWORD = "abcd@1234"
            self.SAVE_FTP = False
            self.OPS_USER_TOKEN = 'cbbdea3cf9b1872855af2b777eba765a0f7721c598f82cb1d13dfe563d4629d89b0cff8a4e50df06b8c00135d1ed8932bb31e8d78a522cd8fafaaee5ac06d6d9'
            self.RM_QUEUE_SERVER = '20.0.2.95'
            self.RM_QUEUE_USER = 'admin_rabbit'
            self.RM_QUEUE_PASSWORD = 'abcd@1234'
            self.RM_QUEUE_PORT = 5672
            self.UHC_CLIENT_ID = 'hlth_recon_stg'
            self.UHC_CLIENT_SECRET = '8f405e28-4d84-43a3-aa0e-ae91c5ee54e8'
            self.UHC_OAUTH_URL = 'https://api-gateway-stage.linkhealth.com/oauth/token/'
            self.CSE_PROXY_USER = 'user1'
            self.CSE_PROXY_PASSWORD = 'Hrc@#123456*.'
            self.CSE_PROXY_SERVER = '34.238.59.233'
            self.CSE_PROXY_SERVER_PORT = '3128'
            self.CSE_CLIENT_ID = 'b8a75ed7-2bc6-466a-8cb1-97bac9b05d34'
            self.CSE_CLIENT_SECRET = 'gY2uW4cR4eJ2qO4nS1pX3gE3fV5rO4uO8cV5bY5jW2dE6hF4bU'
            self.SFTP_FILE_SERVER_ADDRESS = '//20.0.0.10/Operations/Other Operations/Automation/'
            self.MSSQL_SERVER_ADDRESS = '20.0.0.110\SQLEXPRESS,1433'
            self.MSSQL_USERNAME = 'dev_user'
            self.MSSQL_PASSWORD = 'abcd@1234'
            self.REDIS_HOST = '20.0.2.95'
            self.REDIS_PORT = 6379
            self.REDIS_PASSWORD = 'abcd@1234'
            self.BLOB_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=hrclabs;AccountKey=oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q==;EndpointSuffix=core.windows.net'
            self.BLOB_ACCOUNT_NAME = 'hrclabs'
            self.BLOB_ACCOUNT_KEY = 'oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q=='
            self.FIREBASE_API_KEY = "AAAAG82QBOw:APA91bGEjoTXoFm2gwRWv7aFeBzKfDIhDskt88OmWCfA2vZHdog7ifLpWzZQRPlr75wP3LCaykrAgc_gaUknU3HU0QNIHy4B7bUoqNLJbVSdQoc9MdzA8gjb5IYTPMDfgBwiz-UU6NnG"

        if mode == 'cloud':
            self.FTP_LOCATION = '119.235.4.18'
            self.FTP_PORT = '21'
            self.FTP_USERNAME = 'qatest'
            self.FTP_PASSWORD = '4\\\FT`SeeC5ggb6]'  # 4\\FT`SeeC5ggb6]
            self.DB_HOST_NAME = 'automation-production.mysql.database.azure.com:3306'
            self.DB_HOST_NAME_DOCKER = 'automation-production.mysql.database.azure.com:3306'
            self.DB_NAME = 'production'
            self.API_URL = 'http://127.0.0.1:4000'
            self.API_URL_DOCKER = 'http://host.docker.internal:4000'
            self.DOCKER_HOST = 'tcp://127.0.0.1:2375'
            self.DOCKER_DOCKER_HOST = 'tcp://host.docker.internal:2375'
            self.MONGO_CON_STRING = 'mongodb://10.0.0.4:27017/'
            self.DOCKER_MONGO_CON_STRING = 'mongodb://10.0.0.4:27017/'
            self.MYSQL_USER = 'proddbuser@automation-production'
            self.MYSQL_PASSWORD = "Xvsdfs@123"
            self.SAVE_FTP = True
            self.OPS_USER_TOKEN = 'cbbdea3cf9b1872855af2b777eba765a0f7721c598f82cb1d13dfe563d4629d89b0cff8a4e50df06b8c00135d1ed8932bb31e8d78a522cd8fafaaee5ac06d6d9'
            self.RM_QUEUE_SERVER = '127.0.0.1'
            self.RM_QUEUE_USER = 'admin_rabbit'
            self.RM_QUEUE_PASSWORD = 'abcd@1234'
            self.RM_QUEUE_PORT = 5672
            self.UHC_CLIENT_ID = 'hlth_recon_stg'
            self.UHC_CLIENT_SECRET = '8f405e28-4d84-43a3-aa0e-ae91c5ee54e8'
            self.UHC_OAUTH_URL = 'https://api-gateway-stage.linkhealth.com/oauth/token/'
            self.CSE_PROXY_USER = 'user1'
            self.CSE_PROXY_PASSWORD = 'Hrc@#123456*.'
            self.CSE_PROXY_SERVER = '34.238.59.233'
            self.CSE_PROXY_SERVER_PORT = '3128'
            self.CSE_CLIENT_ID = 'b8a75ed7-2bc6-466a-8cb1-97bac9b05d34'
            self.CSE_CLIENT_SECRET = 'gY2uW4cR4eJ2qO4nS1pX3gE3fV5rO4uO8cV5bY5jW2dE6hF4bU'
            self.SFTP_FILE_SERVER_ADDRESS = '//20.0.0.10/Operations/Other Operations/Automation/'
            self.MSSQL_SERVER_ADDRESS = '127.0.0.1\SQLEXPRESS,1433'
            self.MSSQL_USERNAME = 'dev_user'
            self.MSSQL_PASSWORD = 'abcd@1234'
            self.REDIS_HOST = '10.0.0.4'
            self.REDIS_PORT = 6379
            self.REDIS_PASSWORD = 'abcd@1234'
            self.BLOB_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=hrclabs;AccountKey=oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q==;EndpointSuffix=core.windows.net'
            self.BLOB_ACCOUNT_NAME = 'hrclabs'
            self.BLOB_ACCOUNT_KEY = 'oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q=='
            self.FIREBASE_API_KEY = "AAAAOd30H1M:APA91bHXXcr-OtkzGWt0U8jzt9WNz6Q3q7lEjK7N2APJluEKZt8StAmnPT42ZkzXR4DI89h-RhbtkGy3EFlpZBVg0Jm1A38Kuhr__N83_LP8KoVFprhNIEVkfuKzxlJHOzFHbLYdEUTb"

        if mode == 'staging':
            self.FTP_LOCATION = '119.235.4.18'
            self.FTP_PORT = '21'
            self.FTP_USERNAME = 'qatest'
            self.FTP_PASSWORD = '4\\\FT`SeeC5ggb6]'  # 4\\FT`SeeC5ggb6]
            self.DB_HOST_NAME = '20.0.2.93:3306'
            self.DB_HOST_NAME_DOCKER = '20.0.2.93:3306'
            self.DB_NAME = 'staging'
            self.API_URL = 'http://127.0.0.1:4000'
            self.API_URL_DOCKER = 'http://host.docker.internal:4000'
            self.DOCKER_HOST = 'tcp://127.0.0.1:2375'
            self.DOCKER_DOCKER_HOST = 'tcp://host.docker.internal:2375'
            self.MONGO_CON_STRING = 'mongodb://20.0.2.93:27017/'
            self.DOCKER_MONGO_CON_STRING = 'mongodb://20.0.2.93:27017/'
            self.MYSQL_USER = 'application_user'
            self.MYSQL_PASSWORD = "abcd@1234"
            self.SAVE_FTP = True
            self.OPS_USER_TOKEN = 'cbbdea3cf9b1872855af2b777eba765a0f7721c598f82cb1d13dfe563d4629d89b0cff8a4e50df06b8c00135d1ed8932bb31e8d78a522cd8fafaaee5ac06d6d9'
            self.RM_QUEUE_SERVER = '127.0.0.1'
            self.RM_QUEUE_USER = 'admin_rabbit'
            self.RM_QUEUE_PASSWORD = 'abcd@1234'
            self.RM_QUEUE_PORT = 5672
            self.UHC_CLIENT_ID = 'hlth_recon_stg'
            self.UHC_CLIENT_SECRET = '8f405e28-4d84-43a3-aa0e-ae91c5ee54e8'
            self.UHC_OAUTH_URL = 'https://api-gateway-stage.linkhealth.com/oauth/token/'
            self.CSE_PROXY_USER = 'user1'
            self.CSE_PROXY_PASSWORD = 'Hrc@#123456*.'
            self.CSE_PROXY_SERVER = '34.238.59.233'
            self.CSE_PROXY_SERVER_PORT = '3128'
            self.CSE_CLIENT_ID = 'b8a75ed7-2bc6-466a-8cb1-97bac9b05d34'
            self.CSE_CLIENT_SECRET = 'gY2uW4cR4eJ2qO4nS1pX3gE3fV5rO4uO8cV5bY5jW2dE6hF4bU'
            self.SFTP_FILE_SERVER_ADDRESS = '//20.0.0.10/Operations/Other Operations/Automation/'
            self.MSSQL_SERVER_ADDRESS = '127.0.0.1\SQLEXPRESS,1433'
            self.MSSQL_USERNAME = 'dev_user'
            self.MSSQL_PASSWORD = 'abcd@1234'
            self.REDIS_HOST = '20.0.2.93'
            self.REDIS_PORT = 6379
            self.REDIS_PASSWORD = 'abcd@1234'
            self.BLOB_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=hrclabs;AccountKey=oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q==;EndpointSuffix=core.windows.net'
            self.BLOB_ACCOUNT_NAME = 'hrclabs'
            self.BLOB_ACCOUNT_KEY = 'oUxHreifKzHNE3dUmUts+DxOEmeEhH3kF8F8sI/fZkSEwVKYlrLBlvD+K6F5sBYcQKoZ127eDhj+/6OM9TeF7Q=='
            self.FIREBASE_API_KEY = "AAAAmjgAx5A:APA91bE8N_P3IyNTLKIiXSmVjyXaVfel7C0vlGt9RbT2P8bTSN1U5JR8ZUdKIsy6eRwgkNU2gkRETNmf7l5YxhE9eMRA337L3AhbkblFZGUp0b67wQEF_t07YUeE6dqfRLwAzgbd_3EO"

    def as_dict(self):
        # we return a deepcopy to avoid unexpected side-effects
        return copy.deepcopy(self.__dict__)


mode = os.environ['MODE']
CONFIGURATION = configuration(mode)
http_method_names = ['get', 'post', 'put', 'delete', 'head', 'options', 'trace']
