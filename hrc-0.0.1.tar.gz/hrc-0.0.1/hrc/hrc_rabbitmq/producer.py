#  =====================================================================
#  Package/Dependency     : HRCRabbitMQ/producer
#  Class name             : Producer
#  Required Dependencies  : pika
#  Author                 : Zuhry Fayesz (zuhryf@healthreconconnect.com)
#  Organization           : HealthReconConnect (Pvt) Ltd
#  =====================================================================

import pika
from hrc.settings import CONFIGURATION

class Producer:

    # Initialize the RabbitMQ connection and channel || constructor method
    def __init__(self, host):
        credentials = pika.PlainCredentials(CONFIGURATION.RM_QUEUE_USER,
                                            CONFIGURATION.RM_QUEUE_PASSWORD)


        parameters = pika.ConnectionParameters(CONFIGURATION.RM_QUEUE_SERVER,
                                               CONFIGURATION.RM_QUEUE_PORT,
                                               '/',
                                               credentials,
                                               heartbeat=600,
                                               blocked_connection_timeout=300
                                               )
        self.connection = pika.BlockingConnection(parameters=parameters)
        self.channel = self.connection.channel()

    # create user defined queue name
    def create_queue(self, queue):
        self.channel.queue_declare(queue)

    # message producer method params (exchange name, routing key, message body)
    def message_producer(self, exchange, routing_key, body):
        self.channel.basic_publish(exchange=exchange, routing_key=routing_key, body=body)
