from sqlalchemy import func
from sqlalchemy.orm import Session

from hrc.common.database import get_mysql_connection
from hrc.integration_db.models import IJob


def login(username, password):
    engine = get_mysql_connection()
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        initial_jobid = session.query(func.max(IJob.jobid)).scalar()

    session = Session(autocommit=True, bind=engine)
    with session.begin():
        max_jobid = session.query(func.max(IJob.jobid))
