from sqlalchemy.orm import Session

from hrc.integration_db.models import TemplateConfiguration, IClaim


def get_template(engine, template_id):
    template = dict()
    session = Session(bind=engine, autocommit=True, expire_on_commit=False)
    with session.begin():
        template_configurations = session.query(TemplateConfiguration).filter(
            TemplateConfiguration.template_id == template_id).all()
        for config in template_configurations:
            template[config.configuration_type] = config.value

    return template


def get_claim_template(engine, claim_id):
    template = dict()
    session = Session(bind=engine, autocommit=True, expire_on_commit=False)
    with session.begin():
        claim = session.query(IClaim).filter(
            IClaim.claimid == claim_id).order_by(IClaim.claimid.desc()).first()
        template = get_template(engine, claim.template_id)
        template['INSORDER'] = template['INSORDER'] if ('INSORDER' in template) else '1'
        template['PREAUTH'] = template['PREAUTH'] if ('PREAUTH' in template) else ''
        template['FACILITYCODE'] = template['FACILITYCODE'] if ('FACILITYCODE' in template) else None
        template['FCLASS'] = template['FCLASS'] if ('FCLASS' in template) else None
        template['DEFAULT_MACRO'] = template['DEFAULT_MACRO'] if ('DEFAULT_MACRO' in template) else None
        template['PROC'] = template['PROC'] if ('PROC' in template) else None
        template['MOD1'] = template['MOD1'] if ('MOD1' in template) else None
        template['ACCESSIONFIELDID'] = template['ACCESSIONFIELDID'] if ('ACCESSIONFIELDID' in template) else None
        template['RENDERINGPROVIDER'] = template['RENDERINGPROVIDER'] if ('RENDERINGPROVIDER' in template) else None

    return template