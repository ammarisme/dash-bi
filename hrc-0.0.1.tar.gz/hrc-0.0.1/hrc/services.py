import logging
from pyfcm import FCMNotification
from sqlalchemy.orm import Session
from datetime import datetime
from logging.handlers import RotatingFileHandler

from hrc.integration_db.models import Notification, NotificationUser
from hrc.settings import CONFIGURATION
from hrc.common.database import get_mysql_connection

loggers = {}


def logging_service(logger_name):
    """
    :param logger_name:
    :return: logger object with rotate file handler
    """
    global loggers

    if loggers.get(logger_name):
        return loggers.get(logger_name)
    else:
        log_format = '%(asctime)s [%(levelname)s] [hrc-core] %(message)s [(%(filename)s : %(lineno)d)]'
        log_level = logging.DEBUG

        logger = logging.getLogger(logger_name)
        logger.setLevel(log_level)
        logger.propagate = False

        # create file handler
        log_file_name = './logs/{}.log'.format(logger_name)
        file_handler = RotatingFileHandler(log_file_name, mode='a', maxBytes=30 * 1024 * 1024, backupCount=1)
        file_handler.setLevel(log_level)

        # create stream handler
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(log_level)

        # create formatter and add it to the handlers
        formatter = logging.Formatter(log_format)
        file_handler.setFormatter(formatter)
        stream_handler.setFormatter(formatter)

        # add the handlers to logger
        logger.addHandler(file_handler)
        logger.addHandler(stream_handler)
        return logger


def notification_service(license_key, message_title, message_body, username=None):
    log = logging_service('notifications')
    engine = get_mysql_connection()
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)

    try:
        try:
            with session.begin():
                notification = Notification(notification_title=message_title, created_by=username,
                                            notification_details=message_body, created_at=datetime.now(),
                                            license_key=license_key)
            session.add(notification)
            session.flush()

        except Exception as e:
            log.error('[{}][{}]'.format(license_key, e))

        results = engine.execute('SELECT ou.id, firebase_token from op_user ou inner join user_license ul on '
                                 'ou.id=ul.user_id inner join license_keys lk on ul.licensekey_id=lk.id '
                                 'where lk.license_key={};'.format(license_key))

        tokens = []
        for result in results:
            with session.begin():
                notification_sent = NotificationUser(notification_ID=notification.ID, user_ID=result[0], read_status=1,
                                                     created_at=datetime.now())
            session.add(notification_sent)
            session.flush()
            if result[1] is not None:
                tokens.append(result[1])

        push_service = FCMNotification(api_key=CONFIGURATION.FIREBASE_API_KEY)
        result = push_service.notify_multiple_devices(registration_ids=tokens, message_title=message_title,
                                                      message_body=message_body)

        log.debug('[{}][{}]'.format(license_key, result))
    except Exception as e:
        log.error('[{}][{}]'.format(license_key, e))
