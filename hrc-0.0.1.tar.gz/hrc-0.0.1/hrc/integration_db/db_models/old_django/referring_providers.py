from django.db import models

class ReferringProviders(models.Model):
    claimid = models.IntegerField(db_column='ClaimId')  # Field name made lowercase.
    id = models.CharField(db_column='Id', max_length=35, primary_key=True  )  # Field name made lowercase.
    licensekey = models.IntegerField(db_column='LicenseKey')  # Field name made lowercase.
    lastname = models.CharField(db_column='LastName', max_length=35)  # Field name made lowercase.
    firstname = models.CharField(db_column='FirstName', max_length=35)  # Field name made lowercase.
    middlename = models.CharField(db_column='MiddleName', max_length=35)  # Field name made lowercase.
    integration_status = models.IntegerField(db_column='IntegrationStatus', default=0)  # Field name made lowercase.
    npinumber = models.CharField(db_column='NPINumber', max_length=15, blank=True, null=True)  # Field name made lowercase.
    primaryamdcode = models.CharField(db_column='PrimaryAMDCode', max_length=15, blank=True,null=True)  # Field name made lowercase.
    # referringprovider_uid = models.IntegerField(db_column='ReferringProvider_UID')  # Field name made lowercase.
    # referringprovidercode = models.CharField(db_column='ReferringProviderCode',max_length=6)  # Field name made lowercase.
    # title = models.CharField(db_column='Title', max_length=10)  # Field name made lowercase.
    # aptste = models.CharField(db_column='AptSte', max_length=30)  # Field name made lowercase.
    # address = models.CharField(db_column='Address', max_length=30)  # Field name made lowercase.
    # zipcode = models.CharField(db_column='ZipCode', max_length=10)  # Field name made lowercase.
    # city = models.CharField(db_column='City', max_length=30)  # Field name made lowercase.
    # state = models.CharField(db_column='State', max_length=3, blank=True, null=True)  # Field name made lowercase.
    # areacode = models.CharField(db_column='AreaCode', max_length=3)  # Field name made lowercase.
    # countrycode = models.CharField(db_column='CountryCode', max_length=3)  # Field name made lowercase.
    # practicename = models.CharField(db_column='PracticeName', max_length=100)  # Field name made lowercase.
    # licensenumber = models.CharField(db_column='LicenseNumber', max_length=14)  # Field name made lowercase.
    # speciality = models.CharField(db_column='Speciality', max_length=50)  # Field name made lowercase.
    # taxonomy = models.CharField(db_column='Taxonomy', max_length=20)  # Field name made lowercase.
    # includeonhcfa = models.BooleanField(db_column='IncludeonHCFA')  # Field name made lowercase.
    # officephone = models.CharField(db_column='OfficePhone', max_length=25)  # Field name made lowercase.
    # fax = models.CharField(db_column='Fax', max_length=25)  # Field name made lowercase.
    # other = models.CharField(db_column='Other', max_length=25)  # Field name made lowercase.
    # phonetype = models.CharField(db_column='PhoneType', max_length=1)  # Field name made lowercase.
    # email = models.CharField(db_column='Email', max_length=50)  # Field name made lowercase.
    # userfilefid = models.IntegerField(db_column='UserFileFID')  # Field name made lowercase.
    # accountreceivablefid = models.IntegerField(db_column='AccountReceivableFID')  # Field name made lowercase.
    # financialsummaryfid = models.IntegerField(db_column='FinancialSummaryFID')  # Field name made lowercase.
    # display = models.BooleanField(db_column='Display')  # Field name made lowercase.
    # xrefidschangedat = models.DateTimeField(db_column='XRefIDsChangedAt', blank=True, null=True)  # Field name made lowercase.
    # createdby = models.CharField(db_column='CreatedBy', max_length=12)  # Field name made lowercase.
    # createdat = models.DateTimeField(db_column='CreatedAt')  # Field name made lowercase.
    # changedby = models.CharField(db_column='ChangedBy', max_length=12, blank=True, null=True)  # Field name made lowercase.
    # changedat = models.DateTimeField(db_column='ChangedAt', blank=True, null=True)  # Field name made lowercase.
    # fullname = models.CharField(db_column='FullName', max_length=107, blank=True, null=True)  # Field name made lowercase.
    # cbo_group = models.CharField(db_column='CBO_Group', max_length=10, blank=True, null=True)  # Field name made lowercase.
    # loadeddate = models.DateTimeField(db_column='LoadedDate', blank=True, null=True)  # Field name made lowercase.
    # lastupdateddate = models.DateTimeField(db_column='LastUpdatedDate', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        #managed = False
        db_table = 'mf_ReferringProviders'