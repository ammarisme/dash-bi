#this was taken from the data dictionary.
from django.db import models

class Carrier(models.Model): #
    licensekey = models.IntegerField(db_column='LicenseKey', blank=True, null=True)  # Field name made lowercase.
    carrier_uid = models.IntegerField(db_column='Carrier_UID', blank=True, null=True)  # Field name made lowercase.
    primaryamdcode = models.TextField(db_column='CarrierCode', blank=True, null=True)  # Field name made lowercase.
    carriername = models.TextField(db_column='CarrierName', blank=True, null=True)  # Field name made lowercase.
    createdby = models.TextField(db_column='CreatedBy', blank=True, null=True)  # Field name made lowercase.
    createdat = models.TextField(db_column='CreatedAt', blank=True, null=True)  # Field name made lowercase.
    aptste = models.TextField(db_column='AptSte', blank=True, null=True)  # Field name made lowercase.
    address = models.TextField(db_column='Address', blank=True, null=True)  # Field name made lowercase.
    zipcode = models.TextField(db_column='ZipCode', blank=True, null=True)  # Field name made lowercase.
    city = models.TextField(db_column='City', blank=True, null=True)  # Field name made lowercase.
    state = models.TextField(db_column='State', blank=True, null=True)  # Field name made lowercase.
    areacode = models.TextField(db_column='AreaCode', blank=True, null=True)  # Field name made lowercase.
    countrycode = models.TextField(db_column='CountryCode', blank=True, null=True)  # Field name made lowercase.
    contactname = models.TextField(db_column='ContactName', blank=True, null=True)  # Field name made lowercase.
    paperformfid = models.TextField(db_column='PaperFormFID', blank=True, null=True)  # Field name made lowercase.
    standardcopaydollaramt = models.IntegerField(db_column='StandardCopayDollarAmt', blank=True, null=True)  # Field name made lowercase.
    standardcopaypercent = models.IntegerField(db_column='StandardCoPayPercent', blank=True, null=True)  # Field name made lowercase.
    notefid = models.IntegerField(db_column='NoteFID', blank=True, null=True)  # Field name made lowercase.
    dme = models.IntegerField(db_column='DME', blank=True, null=True)  # Field name made lowercase.
    edicpidnumber = models.IntegerField(db_column='EDICPIDNumber', blank=True, null=True)  # Field name made lowercase.
    elecformfid = models.IntegerField(db_column='ElecFormFID', blank=True, null=True)  # Field name made lowercase.
    medigapnumber = models.TextField(db_column='MedigapNumber', blank=True, null=True)  # Field name made lowercase.
    typeofinsurance = models.TextField(db_column='TypeofInsurance', blank=True, null=True)  # Field name made lowercase.
    sourceofpayment = models.TextField(db_column='SourceofPayment', blank=True, null=True)  # Field name made lowercase.
    statecoveragecode = models.TextField(db_column='StateCoverageCode', blank=True, null=True)  # Field name made lowercase.
    elecclaimsbillprimaryonly = models.IntegerField(db_column='ElecClaimsBillPrimaryOnly', blank=True, null=True)  # Field name made lowercase.
    payorid = models.TextField(db_column='PayorID', blank=True, null=True)  # Field name made lowercase.
    payorsubid = models.TextField(db_column='PayorSubID', blank=True, null=True)  # Field name made lowercase.
    eligibilityphonenumber = models.TextField(db_column='EligibilityPhoneNumber', blank=True, null=True)  # Field name made lowercase.
    eligibilityphoneextension = models.TextField(db_column='EligibilityPhoneExtension', blank=True, null=True)  # Field name made lowercase.
    preauthphonenumber = models.TextField(db_column='PreAuthPhoneNumber', blank=True, null=True)  # Field name made lowercase.
    preauthphoneextension = models.TextField(db_column='PreAuthPhoneExtension', blank=True, null=True)  # Field name made lowercase.
    faxnumber = models.TextField(db_column='FaxNumber', blank=True, null=True)  # Field name made lowercase.
    providerrelationsphonenumber = models.TextField(db_column='ProviderRelationsPhoneNumber', blank=True, null=True)  # Field name made lowercase.
    providerrelationsphoneextension = models.TextField(db_column='ProviderRelationsPhoneExtension', blank=True, null=True)  # Field name made lowercase.
    emailaddress = models.TextField(db_column='EmailAddress', blank=True, null=True)  # Field name made lowercase.
    carriercategoryfid = models.IntegerField(db_column='CarrierCategoryFID', blank=True, null=True)  # Field name made lowercase.
    financialsummaryfid = models.IntegerField(db_column='FinancialSummaryFID', blank=True, null=True)  # Field name made lowercase.
    accountreceivablefid = models.IntegerField(db_column='AccountReceivableFID', blank=True, null=True)  # Field name made lowercase.
    display = models.IntegerField(db_column='Display', blank=True, null=True)  # Field name made lowercase.
    checkbox = models.IntegerField(db_column='Checkbox', blank=True, null=True)  # Field name made lowercase.
    requirereferral = models.IntegerField(db_column='RequireReferral', blank=True, null=True)  # Field name made lowercase.
    mtdclaims = models.IntegerField(db_column='MTDClaims', blank=True, null=True)  # Field name made lowercase.
    ytdclaims = models.IntegerField(db_column='YTDClaims', blank=True, null=True)  # Field name made lowercase.
    billzerodollarclaims = models.IntegerField(db_column='BillZeroDollarClaims', blank=True, null=True)  # Field name made lowercase.
    posaliaschangedat = models.TextField(db_column='POSAliasChangedAt', blank=True, null=True)  # Field name made lowercase.
    tosaliaschangedat = models.TextField(db_column='TOSAliasChangedAt', blank=True, null=True)  # Field name made lowercase.
    changedby = models.TextField(db_column='ChangedBy', blank=True, null=True)  # Field name made lowercase.
    changedat = models.TextField(db_column='ChangedAt', blank=True, null=True)  # Field name made lowercase.
    approvedat = models.TextField(db_column='ApprovedAt', blank=True, null=True)  # Field name made lowercase.
    approvedby = models.TextField(db_column='ApprovedBy', blank=True, null=True)  # Field name made lowercase.
    provideridrequired = models.IntegerField(db_column='ProviderIDRequired', blank=True, null=True)  # Field name made lowercase.
    ediagreementrequired = models.IntegerField(db_column='EDIAgreementRequired', blank=True, null=True)  # Field name made lowercase.
    ediagreementapproved = models.IntegerField(db_column='EDIAgreementApproved', blank=True, null=True)  # Field name made lowercase.
    wasimported = models.IntegerField(db_column='WasImported', blank=True, null=True)  # Field name made lowercase.
    importcode = models.TextField(db_column='ImportCode', blank=True, null=True)  # Field name made lowercase.
    usemastercarrierlist = models.IntegerField(db_column='UseMasterCarrierList', blank=True, null=True)  # Field name made lowercase.
    mergedtocarrierfid = models.TextField(db_column='MergedToCarrierFID', blank=True, null=True)  # Field name made lowercase.
    secondarypaperformfid = models.TextField(db_column='SecondaryPaperFormFID', blank=True, null=True)  # Field name made lowercase.
    grpprovidprefix = models.TextField(db_column='GrpProvIDPrefix', blank=True, null=True)  # Field name made lowercase.
    grpidsuffix = models.TextField(db_column='GrpIDSuffix', blank=True, null=True)  # Field name made lowercase.
    providsuffix = models.TextField(db_column='ProvIDSuffix', blank=True, null=True)  # Field name made lowercase.
    includesupervisingprovider = models.IntegerField(db_column='IncludeSupervisingProvider', blank=True, null=True)  # Field name made lowercase.
    includeorderingprovider = models.IntegerField(db_column='IncludeOrderingProvider', blank=True, null=True)  # Field name made lowercase.
    useprovidernpifid = models.IntegerField(db_column='UseProviderNPIFID', blank=True, null=True)  # Field name made lowercase.
    suppressrenderinginfo = models.IntegerField(db_column='SuppressRenderingInfo', blank=True, null=True)  # Field name made lowercase.
    instcontactname = models.TextField(db_column='InstContactName', blank=True, null=True)  # Field name made lowercase.
    instaddress1 = models.TextField(db_column='InstAddress1', blank=True, null=True)  # Field name made lowercase.
    instaddress2 = models.TextField(db_column='InstAddress2', blank=True, null=True)  # Field name made lowercase.
    instzipcode = models.TextField(db_column='InstZipCode', blank=True, null=True)  # Field name made lowercase.
    instcity = models.TextField(db_column='InstCity', blank=True, null=True)  # Field name made lowercase.
    inststate = models.TextField(db_column='InstState', blank=True, null=True)  # Field name made lowercase.
    instareacode = models.TextField(db_column='InstAreaCode', blank=True, null=True)  # Field name made lowercase.
    insteligibilityphonenumber = models.TextField(db_column='InstEligibilityPhoneNumber', blank=True, null=True)  # Field name made lowercase.
    insteligibilityphoneextension = models.TextField(db_column='InstEligibilityPhoneExtension', blank=True, null=True)  # Field name made lowercase.
    instpreauthphonenumber = models.TextField(db_column='InstPreAuthPhoneNumber', blank=True, null=True)  # Field name made lowercase.
    instpreauthphoneextension = models.TextField(db_column='InstPreAuthPhoneExtension', blank=True, null=True)  # Field name made lowercase.
    instproviderrelationsphonenumber = models.TextField(db_column='InstProviderRelationsPhoneNumber', blank=True, null=True)  # Field name made lowercase.
    instproviderrelationsphoneextension = models.TextField(db_column='InstProviderRelationsPhoneExtension', blank=True, null=True)  # Field name made lowercase.
    instfaxnumber = models.TextField(db_column='InstFaxNumber', blank=True, null=True)  # Field name made lowercase.
    instemailaddress = models.TextField(db_column='InstEmailAddress', blank=True, null=True)  # Field name made lowercase.
    instprovideridrequired = models.IntegerField(db_column='InstProviderIDRequired', blank=True, null=True)  # Field name made lowercase.
    instediagreementrequired = models.IntegerField(db_column='InstEDIAgreementRequired', blank=True, null=True)  # Field name made lowercase.
    instediagreementapproved = models.IntegerField(db_column='InstEDIAgreementApproved', blank=True, null=True)  # Field name made lowercase.
    instgrpprovidprefix = models.TextField(db_column='InstGrpProvIDPrefix', blank=True, null=True)  # Field name made lowercase.
    instpaperformfid = models.TextField(db_column='InstPaperFormFID', blank=True, null=True)  # Field name made lowercase.
    instelecformfid = models.TextField(db_column='InstElecFormFID', blank=True, null=True)  # Field name made lowercase.
    instedicpidnumber = models.TextField(db_column='InstEDICPIDNumber', blank=True, null=True)  # Field name made lowercase.
    instpayorid = models.TextField(db_column='InstPayorID', blank=True, null=True)  # Field name made lowercase.
    instpayorsubid = models.TextField(db_column='InstPayorSubID', blank=True, null=True)  # Field name made lowercase.
    instbillzerodollarclaims = models.IntegerField(db_column='InstBillZeroDollarClaims', blank=True, null=True)  # Field name made lowercase.
    primaryclaimtypefid = models.IntegerField(db_column='PrimaryClaimTypeFID', blank=True, null=True)  # Field name made lowercase.
    secondaryclaimtypefid = models.IntegerField(db_column='SecondaryClaimTypeFID', blank=True, null=True)  # Field name made lowercase.
    notes = models.TextField(db_column='Notes', blank=True, null=True)  # Field name made lowercase.
    noteschangedat = models.TextField(db_column='NotesChangedAt', blank=True, null=True)  # Field name made lowercase.
    instnotes = models.TextField(db_column='InstNotes', blank=True, null=True)  # Field name made lowercase.
    instnoteschangedat = models.TextField(db_column='InstNotesChangedAt', blank=True, null=True)  # Field name made lowercase.
    webaddress = models.TextField(db_column='WebAddress', blank=True, null=True)  # Field name made lowercase.
    instwebaddress = models.TextField(db_column='InstWebAddress', blank=True, null=True)  # Field name made lowercase.
    othercontact = models.TextField(db_column='OtherContact', blank=True, null=True)  # Field name made lowercase.
    instothercontact = models.TextField(db_column='InstOtherContact', blank=True, null=True)  # Field name made lowercase.
    instuseprovidernpifid = models.IntegerField(db_column='InstUseProviderNPIFID', blank=True, null=True)  # Field name made lowercase.
    renderingqualfid = models.IntegerField(db_column='RenderingQualFID', blank=True, null=True)  # Field name made lowercase.
    renderingsourcefid = models.IntegerField(db_column='RenderingSourceFID', blank=True, null=True)  # Field name made lowercase.
    billingqualfid = models.IntegerField(db_column='BillingQualFID', blank=True, null=True)  # Field name made lowercase.
    billingsourcefid = models.IntegerField(db_column='BillingSourceFID', blank=True, null=True)  # Field name made lowercase.
    referringqualfid = models.IntegerField(db_column='ReferringQualFID', blank=True, null=True)  # Field name made lowercase.
    referringsourcefid = models.IntegerField(db_column='ReferringSourceFID', blank=True, null=True)  # Field name made lowercase.
    billasfid = models.IntegerField(db_column='BillAsFID', blank=True, null=True)  # Field name made lowercase.
    enablemonthlybilling = models.IntegerField(db_column='EnableMonthlyBilling', blank=True, null=True)  # Field name made lowercase.
    icd9enddate = models.TextField(db_column='Icd9EndDate', blank=True, null=True)  # Field name made lowercase.
    icd10startdate = models.TextField(db_column='Icd10StartDate', blank=True, null=True)  # Field name made lowercase.
    followprimarycodeset = models.IntegerField(db_column='FollowPrimaryCodeSet', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        #managed = False
        db_table = 'mf_carriers'

# class Carrier(models.Model):
#     claimid = models.IntegerField(db_column='ClaimId')  # Field name made lowercase.
#     licensekey = models.IntegerField(db_column='LicenseKey')  # Field name made lowercase.
#     carriername = models.CharField(db_column='CarrierName', max_length=100)  # Field name made lowercase.
#     primaryamdcode = models.CharField(db_column='PrimaryAMDCode', max_length=15, blank=True,null=True)  # Field name made lowercase.
#     integration_status = models.IntegerField(db_column='IntegrationStatus' , default=0)  # Field name made lowercase.
#
#     class Meta:
#         #managed = False
#         db_table = 'mf_Carriers'
