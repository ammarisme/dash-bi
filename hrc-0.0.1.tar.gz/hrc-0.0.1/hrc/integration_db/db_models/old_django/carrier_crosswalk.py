from django.db import models
from .referring_providers import ReferringProviders


class CarrierCrosswalk(models.Model):
    insuranceprovider = models.CharField(db_column="InsuranceProvider", max_length=200, primary_key=True)
    amdcode = models.CharField(db_column="AMDCode", max_length=200)

    class Meta:
        db_table = 'i_CarrierCrosswalk'

#    cbo_group = models.CharField(db_column='CBO_Group', max_length=10, blank=True, null=True)  # Field name made lowercase.
#    lastupdateddate = models.DateTimeField(db_column='LastUpdatedDate', blank=True, null=True)  # Field name made lowercase.
