from django.db import models

class Facility(models.Model):
    claimid = models.IntegerField(db_column='ClaimId')  # Field name made lowercase.
    licensekey = models.IntegerField(db_column='LicenseKey')  # Field name made lowercase.
    integration_status = models.IntegerField(db_column='IntegrationStatus', default=0)  # Field name made lowercase.
    # facility_uid = models.IntegerField(db_column='Facility_UID')  # Field name made lowercase.
    # facilitycode = models.CharField(db_column='FacilityCode', max_length=5)  # Field name made lowercase.
    facilityname = models.CharField(db_column='FacilityName', max_length=50)  # Field name made lowercase.
    # aptste = models.CharField(db_column='AptSte', max_length=30, blank=True, null=True)  # Field name made lowercase.
    # address = models.CharField(db_column='Address', max_length=30, blank=True, null=True)  # Field name made lowercase.
    # zipcode = models.CharField(db_column='ZipCode', max_length=10)  # Field name made lowercase.
    # city = models.CharField(db_column='City', max_length=30, blank=True, null=True)  # Field name made lowercase.
    # state = models.CharField(db_column='State', max_length=3, blank=True, null=True)  # Field name made lowercase.
    # areacode = models.CharField(db_column='AreaCode', max_length=3, blank=True, null=True)  # Field name made lowercase.
    # countrycode = models.CharField(db_column='CountryCode', max_length=3, blank=True, null=True)  # Field name made lowercase.
    # contactname = models.CharField(db_column='ContactName', max_length=30, blank=True, null=True)  # Field name made lowercase.
    # email = models.CharField(db_column='Email', max_length=50, blank=True, null=True)  # Field name made lowercase.
    # facilitytype = models.SmallIntegerField(db_column='FacilityType')  # Field name made lowercase.
    # financialsummaryfid = models.IntegerField(db_column='FinancialSummaryFID')  # Field name made lowercase.
    # includeonclaims = models.BooleanField(db_column='IncludeOnClaims')  # Field name made lowercase.
    # display = models.BooleanField(db_column='Display')  # Field name made lowercase.
    # licensenumber = models.CharField(db_column='LicenseNumber', max_length=20, blank=True, null=True)  # Field name made lowercase.
    # userfacilityid = models.CharField(db_column='UserFacilityID', max_length=20, blank=True, null=True)  # Field name made lowercase.
    # facilitynpi = models.CharField(db_column='FacilityNPI', max_length=15)  # Field name made lowercase.
    # xrefidschangedat = models.DateTimeField(db_column='XRefIDsChangedAt', blank=True, null=True)  # Field name made lowercase.
    # facilitytypefid = models.IntegerField(db_column='FacilityTypeFID', blank=True, null=True)  # Field name made lowercase.
    # billclassfid = models.IntegerField(db_column='BillClassFID', blank=True, null=True)  # Field name made lowercase.
    # googleplaceid = models.CharField(db_column='GooglePlaceID', max_length=255, blank=True, null=True)  # Field name made lowercase.
    # createdby = models.CharField(db_column='CreatedBy', max_length=12)  # Field name made lowercase.
    # createdat = models.DateTimeField(db_column='CreatedAt')  # Field name made lowercase.
    # changedby = models.CharField(db_column='ChangedBy', max_length=12, blank=True, null=True)  # Field name made lowercase.
    # changedat = models.DateTimeField(db_column='ChangedAt', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        db_table = 'mf_Facilities'
