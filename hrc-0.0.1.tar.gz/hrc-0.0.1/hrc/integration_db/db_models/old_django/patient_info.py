from django.db import models

class PatientInfo(models.Model):
    integration_status = models.IntegerField(db_column='IntegrationStatus', default=0)  # Field name made lowercase.
    financialclass = models.CharField(db_column='FinancialClass', max_length=30, blank=True, null=True)  # Field name made lowercase.
    claimid = models.IntegerField(db_column='ClaimId')  # Field name made lowercase.
    licensekey = models.IntegerField(db_column='LicenseKey')  # Field name made lowercase.
    patient_uid = models.IntegerField(db_column='Patient_UID', blank=True, default=0)  # Field name made lowercase.
    patientid =  models.CharField(db_column='PatientID', max_length=30, blank=True)  # Field name made lowercase.
    visit_number = models.CharField(db_column='Accession', max_length=30, blank=True)  # Field name made lowercase.
    lastname = models.CharField(db_column='LastName', max_length=35)  # Field name made lowercase.
    firstname = models.CharField(db_column='FirstName', max_length=35)  # Field name made lowercase.
    middlename = models.CharField(db_column='MiddleName', max_length=35, blank=True)  # Field name made lowercase.
    chartnumber = models.CharField(db_column='ChartNumber', max_length=12)  # Field name made lowercase.
    title = models.CharField(db_column='Title', max_length=15, blank=True, null=True)  # Field name made lowercase.
    aptste = models.CharField(db_column='AptSte', max_length=30)  # Field name made lowercase.
    address1 = models.CharField(db_column='Address1', max_length=300, blank=True)  # Field name made lowercase.
    address2 = models.CharField(db_column='Address2', max_length=300, blank=True)  # Field name made lowercase.
    zipcode = models.CharField(db_column='ZipCode', max_length=10)  # Field name made lowercase.
    city = models.CharField(db_column='City', max_length=30, blank=True, null=True)  # Field name made lowercase.
    state = models.CharField(db_column='State', max_length=3, blank=True, null=True)  # Field name made lowercase.
    areacode = models.CharField(db_column='AreaCode', max_length=3, blank=True, null=True)  # Field name made lowercase.
    countrycode = models.CharField(db_column='CountryCode', max_length=3, blank=True, null=True)  # Field name made lowercase.
    officephone = models.CharField(db_column='OfficePhone', max_length=25, blank=True,default="",  null=True)  # Field name made lowercase.
    officeextension = models.CharField(db_column='OfficeExtension', max_length=6, blank=True, null=True)  # Field name made lowercase.
    homephone = models.CharField(db_column='HomePhone', max_length=25, blank=True, default="", null=True)  # Field name made lowercase.
    other = models.CharField(db_column='Other', max_length=25, blank=True, null=True)  # Field name made lowercase.
    phonetype = models.CharField(db_column='PhoneType', max_length=1, blank=True, null=True)  # Field name made lowercase.
    email = models.CharField(db_column='Email', max_length=50, blank=True, null=True)  # Field name made lowercase.
    maritalstatus = models.SmallIntegerField(db_column='MaritalStatus', blank=True, null=True)  # Field name made lowercase.
    dob = models.DateField(db_column='DOB', blank=True, null=True)  # Field name made lowercase.
    deceased = models.DateTimeField(db_column='Deceased', blank=True, null=True)  # Field name made lowercase.
    gender = models.CharField(db_column='Gender', max_length=1, blank=True, null=True)  # Field name made lowercase.
    primary_referring_provider = models.CharField(db_column='PrimaryReferringProvider', max_length=100, blank=True, null=True)  # Field name made lowercase.
    primary_rendering_provider = models.CharField(db_column='PrimaryRenderingProvider', max_length=100, blank=True, null=True)  # Field name made lowercase.
    insurance_provider1 = models.CharField(db_column='InsuranceProvider1', max_length=100, blank=True, null=True)  # Field name made lowercase.
    insurance_provider2 = models.CharField(db_column='InsuranceProvider2', max_length=100, blank=True,null=True)  # Field name made lowercase.
    insurance_provider3 = models.CharField(db_column='InsuranceProvider3', max_length=100, blank=True,null=True)  # Field name made lowercase.
    carrier_code1 = models.CharField(db_column='CarrierCode1', max_length=100, blank=True,
                                         null=True)  # Field name made lowercase.
    carrier_code2 = models.CharField(db_column='CarrierCode2', max_length=100, blank=True,
                                         null=True)  # Field name made lowercase.
    carrier_code3 = models.CharField(db_column='CarrierCode3', max_length=100, blank=True,
                                         null=True)  # Field name made lowercase.
    insurance_policy1 = models.CharField(db_column='InsurancePolicy1', max_length=100, blank=True,null=True)  # Field name made lowercase.
    ssn = models.CharField(db_column='SSN', max_length=12, blank=True, null=True)  # Field name made lowercase.
    relationship = models.SmallIntegerField(db_column='Relationship' ,blank=True, null=True)  # Field name made lowercase.
    # hipaarelationship = models.CharField(db_column='HIPAARelationship', max_length=2)  # Field name made lowercase.
    # responsiblepartyfid = models.IntegerField(db_column='ResponsiblePartyFID', blank=True, null=True)  # Field name made lowercase.
    # profilefid = models.IntegerField(db_column='ProfileFID', blank=True, default=1)  # Field name made lowercase.)  # Field name made lowercase.
    # financialclassfid = models.IntegerField(db_column='FinancialClassFID', blank=True, default=1)  # Field name made lowercase.)  # Field name made lowercase.
    employer = models.CharField(db_column='Employer', max_length=100, blank=True, null=True, default="")  # Field name made lowercase.
    serialnumber = models.CharField(db_column='SerialNumber', max_length=45, blank=True, null=True)  # Field name made lowercase.
    # employerfid = models.IntegerField(db_column='EmployerFID', blank=True, null=True)  # Field name made lowercase.
    # insuranceorder = models.CharField(db_column='InsuranceOrder', max_length=45)  # Field name made lowercase.
    # ar_patportionfid = models.IntegerField(db_column='AR_PatPortionFID', blank=True, default=1)  # Field name made lowercase.)  # Field name made lowercase.
    # ar_insportionfid = models.IntegerField(db_column='AR_InsPortionFID', blank=True, default=1)  # Field name made lowercase.)  # Field name made lowercase.
    #createdat = models.DateTimeField(db_column='CreatedAt')  # Field name made lowercase.
    # createdby = models.CharField(db_column='CreatedBy', max_length=12)  # Field name made lowercase.
    #display = models.BooleanField(db_column='Display')  # Field name made lowercase.
    # recalcbuckets = models.BooleanField(db_column='RecalcBuckets')  # Field name made lowercase.
    # fullname = models.CharField(db_column='FullName', max_length=107, blank=True, null=True)  # Field name made lowercase.
    #changedat = models.DateTimeField(db_column='ChangedAt')  # Field name made lowercase.
    # changedby = models.CharField(db_column='ChangedBy', max_length=12, blank=True, null=True)  # Field name made lowercase.
    #bucketsupdatedat = models.DateTimeField(db_column='BucketsUpdatedAt')  # Field name made lowercase.
    # birthmonth = models.IntegerField(db_column='BirthMonth', blank=True, null=True)  # Field name made lowercase.
    # isdeceased = models.IntegerField(db_column='IsDeceased')  # Field name made lowercase.
    # ethnicityfid = models.IntegerField(db_column='EthnicityFID', blank=True, null=True)  # Field name made lowercase.
    # languagefid = models.IntegerField(db_column='LanguageFID', blank=True, null=True)  # Field name made lowercase.
    # language = models.CharField(db_column='Language', max_length=50, blank=True, null=True)  # Field name made lowercase.
    # communicationnote = models.CharField(db_column='CommunicationNote', max_length=255)  # Field name made lowercase.
    # cbo_group = models.CharField(db_column='CBO_Group', max_length=10, blank=True, null=True)  # Field name made lowercase.
    #loadeddate = models.DateTimeField(db_column='LoadedDate', blank=True, null=True)  # Field name made lowercase.
    #lastupdateddate = models.DateTimeField(db_column='LastUpdatedDate', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'pt_PatientInfo_dummy'