# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from datetime import timezone

from django.db import models

class ChargeDetail(models.Model):
    claimid = models.IntegerField(db_column='ClaimId')  # Field name made lowercase.
    licensekey = models.IntegerField(db_column='LicenseKey')  # Field name made lowercase.
    diagnosiscodes = models.CharField(db_column='DiagnosisCodes', max_length=255, blank=True,null=True)  # Field name made lowercase.
    integration_status = models.IntegerField(db_column='IntegrationStatus', default=0)  # Field name made lowercase.
    modcode = models.CharField(db_column='ModCode', max_length=255, blank=True,null=True)  # Field name made lowercase.
    begindateofservice = models.DateTimeField(db_column='BeginDateOfService', blank=True, null=True)  # Field name made lowercase.
    enddateofservice = models.DateTimeField(db_column='EndDateOfService', blank=True, null=True)  # Field name made lowercase.

    # chargedetail_uid = models.IntegerField(db_column='ChargeDetail_UID')  # Field name made lowercase.
    # postingdate = models.DateTimeField(db_column='PostingDate', blank=True, null=True)  # Field name made lowercase.
    # visitfid = models.IntegerField(db_column='VisitFID')  # Field name made lowercase.
    # patientfid = models.IntegerField(db_column='PatientFID')  # Field name made lowercase.
    # responsiblepartyfid = models.IntegerField(db_column='ResponsiblePartyFID')  # Field name made lowercase.
    # begindateofservice = models.DateTimeField(db_column='BeginDateOfService')  # Field name made lowercase.
    # enddateofservice = models.DateTimeField(db_column='EndDateOfService')  # Field name made lowercase.
    # chargecodefid = models.IntegerField(db_column='ChargeCodeFID')  # Field name made lowercase.
    # placeofservicefid = models.IntegerField(db_column='PlaceOfServiceFID')  # Field name made lowercase.
    # typeofservicefid = models.IntegerField(db_column='TypeOfServiceFID')  # Field name made lowercase.
    # agingdate = models.DateTimeField(db_column='AgingDate')  # Field name made lowercase.
    # billinsurance = models.BooleanField(db_column='BillInsurance')  # Field name made lowercase.
    # insurancebilled = models.BooleanField(db_column='InsuranceBilled')  # Field name made lowercase.
    # fee = models.DecimalField(db_column='Fee', max_digits=19, decimal_places=4)  # Field name made lowercase.
    # units = models.DecimalField(db_column='Units', max_digits=14, decimal_places=1)  # Field name made lowercase.
    # dayclosed = models.BooleanField(db_column='DayClosed')  # Field name made lowercase.
    # posted = models.BooleanField(db_column='Posted')  # Field name made lowercase.
    # void = models.BooleanField(db_column='Void')  # Field name made lowercase.
    # voidedfid = models.IntegerField(db_column='VoidedFID', blank=True, null=True)  # Field name made lowercase.
    # lastbilledcarriersequencenumber = models.IntegerField(db_column='LastBilledCarrierSequenceNumber')  # Field name made lowercase.
    # paidoff = models.BooleanField(db_column='PaidOff')  # Field name made lowercase.
    # patientportion = models.DecimalField(db_column='PatientPortion', max_digits=19, decimal_places=4)  # Field name made lowercase.
    # insuranceportion = models.DecimalField(db_column='InsurancePortion', max_digits=19, decimal_places=4)  # Field name made lowercase.
    # financialclassfid = models.IntegerField(db_column='FinancialClassFID')  # Field name made lowercase.
    # batchinformationfid = models.IntegerField(db_column='BatchInformationFID', blank=True, null=True)  # Field name made lowercase.
    # allowedamount = models.DecimalField(db_column='AllowedAmount', max_digits=19, decimal_places=4)  # Field name made lowercase.
    # createdby = models.CharField(db_column='CreatedBy', max_length=12)  # Field name made lowercase.
    # display = models.BooleanField(db_column='Display')  # Field name made lowercase.
    # paymentplan = models.BooleanField(db_column='PaymentPlan')  # Field name made lowercase.
    # insurancebalance = models.DecimalField(db_column='InsuranceBalance', max_digits=19, decimal_places=4)  # Field name made lowercase.
    # patientbalance = models.DecimalField(db_column='PatientBalance', max_digits=19, decimal_places=4)  # Field name made lowercase.
    # carrierbillinghistoryfid = models.IntegerField(db_column='CarrierBillingHistoryFID', blank=True, null=True)  # Field name made lowercase.
    # asstproviderfid = models.IntegerField(db_column='AsstProviderFID')  # Field name made lowercase.
    # residentfid = models.IntegerField(db_column='ResidentFID')  # Field name made lowercase.
    # protected = models.BooleanField(db_column='Protected')  # Field name made lowercase.
    # notefid = models.IntegerField(db_column='NoteFID')  # Field name made lowercase.
    # netfee = models.BooleanField(db_column='NetFee')  # Field name made lowercase.
    # lineitemnote = models.CharField(db_column='LineItemNote', max_length=80)  # Field name made lowercase.
    # includeonstatement = models.BooleanField(db_column='IncludeOnStatement')  # Field name made lowercase.
    # duration = models.IntegerField(db_column='Duration', blank=True, null=True)  # Field name made lowercase.
    # cobcodefid = models.IntegerField(db_column='COBCodeFID', blank=True, null=True)  # Field name made lowercase.
    # createdat = models.DateTimeField(db_column='CreatedAt', blank=True, null=True)  # Field name made lowercase.
    # changedat = models.DateTimeField(db_column='ChangedAt', blank=True, null=True)  # Field name made lowercase.
    # changedby = models.CharField(db_column='ChangedBy', max_length=12, blank=True, null=True)  # Field name made lowercase.
    # modifiers = models.CharField(db_column='Modifiers', max_length=50, blank=True, null=True)  # Field name made lowercase.
    # assessmentdate = models.DateTimeField(db_column='AssessmentDate', blank=True, null=True)  # Field name made lowercase.
    # attendingprvprofilefid = models.IntegerField(db_column='AttendingPrvProfileFID', blank=True, null=True)  # Field name made lowercase.
    # noncoveredcharges = models.DecimalField(db_column='NonCoveredCharges', max_digits=19, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    # operatingprvprofilefid = models.IntegerField(db_column='OperatingPrvProfileFID', blank=True, null=True)  # Field name made lowercase.
    # otherproviderprofilefid = models.IntegerField(db_column='OtherProviderProfileFID', blank=True, null=True)  # Field name made lowercase.
    # facilitytaxamount = models.DecimalField(db_column='FacilityTaxAmount', max_digits=19, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    # servicetaxamount = models.DecimalField(db_column='ServiceTaxAmount', max_digits=19, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    # unitstypecode = models.CharField(db_column='UnitsTypeCode', max_length=2, blank=True, null=True)  # Field name made lowercase.
    # doswassystemgenerated = models.BooleanField(db_column='DOSWasSystemGenerated')  # Field name made lowercase.
    # totaldue = models.DecimalField(db_column='TotalDue', max_digits=19, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    # totalportion = models.DecimalField(db_column='TotalPortion', max_digits=19, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    # billstatusfid = models.IntegerField(db_column='BillStatusFID')  # Field name made lowercase.
    # firsttimeunbilled = models.DateTimeField(db_column='FirstTimeUnbilled', blank=True, null=True)  # Field name made lowercase.
    # periodfid = models.IntegerField(db_column='PeriodFID', blank=True, null=True)  # Field name made lowercase.
    # cbo_group = models.CharField(db_column='CBO_Group', max_length=10, blank=True, null=True)  # Field name made lowercase.
    # loadeddate = models.DateTimeField(db_column='LoadedDate', blank=True, null=True)  # Field name made lowercase.
    # lastupdateddate = models.DateTimeField(db_column='LastUpdatedDate', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        #managed = False
        db_table = 'actv_ChargeDetail'
