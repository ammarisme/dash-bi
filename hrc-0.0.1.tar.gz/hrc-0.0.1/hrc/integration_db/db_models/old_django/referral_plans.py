from django.db import models

class ReferralPlans(models.Model):
    claimid = models.IntegerField(db_column='ClaimId')  # Field name made lowercase.
    licensekey = models.IntegerField(db_column='LicenseKey')  # Field name made lowercase.
    diagnosiscodes = models.CharField(db_column='DiagnosisCodes', max_length=255, blank=True, null=True)  # Field name made lowercase.
    integration_status = models.IntegerField(db_column='IntegrationStatus', default=0)  # Field name made lowercase.


    #from here onward didn't exist in the staging db
    refprov = models.CharField(db_column='Refprov', max_length=100, blank=True, null=True)  # Field name made lowercase.
    reason = models.CharField(db_column='Reason', max_length=100, blank=True, null=True)  # Field name made lowercase.
    preauthreq = models.CharField(db_column='PreauthReq', max_length=100, blank=True, null=True)  # Field name made lowercase.
    usedvisits = models.CharField(db_column='UsedVisits', max_length=100, blank=True, null=True)  # Field name made lowercase.
    usedamount = models.CharField(db_column='UsedAmount', max_length=100, blank=True, null=True)  # Field name made lowercase.
    proccode = models.CharField(db_column='ProcCode', max_length=100, blank=True, null=True)  # Field name made lowercase.
    begindate = models.CharField(db_column='BeginDate', max_length=100, blank=True, null=True)  # Field name made lowercase.
    maxvisits = models.CharField(db_column='MaxVisits', max_length=100, blank=True, null=True)  # Field name made lowercase.
    maxamount = models.CharField(db_column='MaxAmount', max_length=100, blank=True, null=True)  # Field name made lowercase.
    enddate = models.DateTimeField(db_column='EndDate', blank=True, null=True)  # Field name made lowercase.
    preauth = models.CharField(db_column='PreAuth', max_length=100, blank=True, null=True)  # Field name made lowercase.
    refnum = models.CharField(db_column='RefNum', max_length=100, blank=True, null=True)  # Field name made lowercase.
    diagcodes = models.CharField(db_column='DiagCodes', max_length=100, blank=True, null=True)  # Field name made lowercase.
    status = models.CharField(db_column='Status', max_length=100, blank=True, null=True)  # Field name made lowercase.
    facility = models.CharField(db_column='Facility', max_length=100, blank=True, null=True)  # Field name made lowercase.
    # referralplan_uid = models.IntegerField(db_column='ReferralPlan_UID')  # Field name made lowercase.
    # patientfid = models.IntegerField(db_column='PatientFID')  # Field name made lowercase.
    # referraltype = models.CharField(db_column='ReferralType', max_length=1)  # Field name made lowercase.
    # defaultinchargeentry = models.BooleanField(db_column='DefaultinChargeEntry')  # Field name made lowercase.
    # byreferringproviderfid = models.IntegerField(db_column='ByReferringProviderFID')  # Field name made lowercase.
    # toreferringproviderfid = models.IntegerField(db_column='ToReferringProviderFID')  # Field name made lowercase.
    # reason = models.CharField(db_column='Reason', max_length=50, blank=True, null=True)  # Field name made lowercase.
    # preauthcode = models.CharField(db_column='PreAuthCode', max_length=50, blank=True, null=True)  # Field name made lowercase.
    # expirationdate = models.DateTimeField(db_column='ExpirationDate', blank=True, null=True)  # Field name made lowercase.
    # maxcharge = models.DecimalField(db_column='MaxCharge', max_digits=19, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    # usedcharge = models.DecimalField(db_column='UsedCharge', max_digits=19, decimal_places=4, blank=True, null=True)  # Field name made lowercase.
    # maxauthvisits = models.SmallIntegerField(db_column='MaxAuthVisits', blank=True, null=True)  # Field name made lowercase.
    # authvisitsused = models.SmallIntegerField(db_column='AuthVisitsUsed', blank=True, null=True)  # Field name made lowercase.
    # chargecodefid = models.IntegerField(db_column='ChargeCodeFID')  # Field name made lowercase.
    # statuscodefid = models.IntegerField(db_column='StatusCodeFID')  # Field name made lowercase.
    # referralplansourcefid = models.IntegerField(db_column='ReferralPlanSourceFID', blank=True, null=True)  # Field name made lowercase.
    # facilityfid = models.IntegerField(db_column='FacilityFID')  # Field name made lowercase.
    # display = models.BooleanField(db_column='Display')  # Field name made lowercase.
    # preauthorizationrequired = models.BooleanField(db_column='PreAuthorizationRequired')  # Field name made lowercase.
    # createdat = models.DateTimeField(db_column='CreatedAt')  # Field name made lowercase.
    # createdby = models.CharField(db_column='CreatedBy', max_length=12, blank=True, null=True)  # Field name made lowercase.
    # sequenceno = models.SmallIntegerField(db_column='SequenceNo', blank=True, null=True)  # Field name made lowercase.
    # changedat = models.DateTimeField(db_column='ChangedAt', blank=True, null=True)  # Field name made lowercase.
    # changedby = models.CharField(db_column='ChangedBy', max_length=12, blank=True, null=True)  # Field name made lowercase.
    # creationdate = models.DateTimeField(db_column='CreationDate')  # Field name made lowercase.
    # cbo_group = models.CharField(db_column='CBO_Group', max_length=10, blank=True, null=True)  # Field name made lowercase.
    # loadeddate = models.DateTimeField(db_column='LoadedDate', blank=True, null=True)  # Field name made lowercase.
    # lastupdateddate = models.DateTimeField(db_column='LastUpdatedDate', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        #managed = False
        db_table = 'pt_ReferralPlans'