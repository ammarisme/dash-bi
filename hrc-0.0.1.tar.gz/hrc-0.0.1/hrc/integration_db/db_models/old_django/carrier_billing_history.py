from django.db import models

class CarrierBillingHistory(models.Model):
    claimid = models.IntegerField(db_column='ClaimId')  # Field name made lowercase.
    licensekey = models.IntegerField(db_column='LicenseKey')  # Field name made lowercase.
    carriercode = models.CharField(db_column='CarrierCode', max_length=8)  # Field name made lowercase.
    integration_status = models.IntegerField(db_column='IntegrationStatus', default=0)  # Field name made lowercase.
    # carrierbillinghistory_uid = models.IntegerField(db_column='CarrierBillingHistory_UID')  # Field name made lowercase.
    # seqnumberlastbilled = models.IntegerField(db_column='SeqNumberLastBilled', blank=True, null=True)  # Field name made lowercase.
    # carrierbilleddate = models.DateTimeField(db_column='CarrierBilledDate', blank=True, null=True)  # Field name made lowercase.
    # chargedetailfid = models.IntegerField(db_column='ChargeDetailFID')  # Field name made lowercase.
    # visitfid = models.IntegerField(db_column='VisitFID')  # Field name made lowercase.
    # proxyvisitfid = models.IntegerField(db_column='ProxyVisitFID')  # Field name made lowercase.
    # claimidsuffix = models.CharField(db_column='ClaimIDSuffix', max_length=2)  # Field name made lowercase.
    # claimid = models.CharField(db_column='ClaimID', max_length=12, blank=True, null=True)  # Field name made lowercase.
    # paperedi = models.CharField(db_column='PaperEDI', max_length=1, blank=True, null=True)  # Field name made lowercase.
    # carrierfid = models.IntegerField(db_column='CarrierFID')  # Field name made lowercase.
    # previoussequencenumber = models.IntegerField(db_column='PreviousSequenceNumber', blank=True, null=True)  # Field name made lowercase.
    # billedamount = models.DecimalField(db_column='BilledAmount', max_digits=19, decimal_places=4)  # Field name made lowercase.
    # isdemand = models.BooleanField(db_column='IsDemand')  # Field name made lowercase.
    # cbo_group = models.CharField(db_column='CBO_Group', max_length=10, blank=True, null=True)  # Field name made lowercase.
    # loadeddate = models.DateTimeField(db_column='LoadedDate', blank=True, null=True)  # Field name made lowercase.
    # lastupdateddate = models.DateTimeField(db_column='LastUpdatedDate', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        #managed = False
        db_table = 'actv_CarrierBillingHistory'