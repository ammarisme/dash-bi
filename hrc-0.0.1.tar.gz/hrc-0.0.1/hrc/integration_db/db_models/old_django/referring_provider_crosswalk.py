from django.db import models
from .referring_providers import ReferringProviders
from .carrier import Carrier


class ReferringProviderCrosswalk(models.Model):  #
    physiciannpi = models.IntegerField(db_column='PhysicianNPI', primary_key=True)
    physicianfirstname = models.CharField(db_column="PhysicianFirstName", max_length=20)
    physicianmiddlename = models.CharField(db_column="PhysicianMiddleName", max_length=20)
    physicianlastname = models.CharField(db_column="PhysicianLastName", max_length=20)
    referringprovider = models.CharField(db_column="ReferringProvider", max_length=20)

    class Meta:
        db_table = 'i_ReferringProviderCrosswalk'

#    cbo_group = models.CharField(db_column='CBO_Group', max_length=10, blank=True, null=True)  # Field name made lowercase.
#    lastupdateddate = models.DateTimeField(db_column='LastUpdatedDate', blank=True, null=True)  # Field name made lowercase.
