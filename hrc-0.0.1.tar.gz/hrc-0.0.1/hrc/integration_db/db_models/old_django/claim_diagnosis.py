from django.db import models

class ClaimDiagnosis(models.Model):
    serialnumber = models.TextField(db_column='SerialNumber',  primary_key=True)  # Field name made lowercase.
    diagnosiscodes = models.TextField(db_column='DiagnosisCodes', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'claim_diagnosis'