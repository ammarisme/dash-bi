# coding: utf-8
from sqlalchemy import BigInteger, Column, DECIMAL, Date, DateTime, ForeignKey, Integer, SmallInteger, String, Table, \
    Time, text, Float, Text
from sqlalchemy.dialects.mysql import DATETIME, TINYINT
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
metadata = Base.metadata


class ClaimConfigurationType(Base):
    __tablename__ = 'claim_configuration_type'

    configuration_name = Column(String(45))
    configuration_code = Column(String(45), primary_key=True)


class ClaimTemplate(Base):
    __tablename__ = 'claim_template'

    id = Column(Integer, primary_key=True)
    template_name = Column(String(400))
    license_key = Column(String(45))
    status = Column(TINYINT)


class IJob(Base):
    __tablename__ = 'i_jobs'

    jobid = Column(Integer, primary_key=True)
    LicenseKey = Column(Integer)
    IntegrationStatus = Column(Integer, nullable=False)
    JobStatus = Column(Integer)
    ParentJob = Column(Integer)
    ProcessId = Column(Integer, server_default=text("'0'"))


class IProcessing(Base):
    __tablename__ = 'i_processing'

    Id = Column(Integer, primary_key=True)
    Status = Column(Integer, server_default=text("'0'"))
    CreatedAt = Column(DateTime)
    CreatedBy = Column(String(45))
    LicenseKey = Column(Integer, nullable=False, server_default=text("'0'"))
    FileName = Column(String(1000))
    Type = Column(Integer)
    TotalClaims = Column(Integer)
    CleanClaims = Column(Integer)
    ErrorClaims = Column(Integer)
    Duplicates = Column(Integer)
    FileStatus = Column(String(45))
    error_detail = Column(String(2000))
    exception_details = Column(String(2000))


class JobCpt(Base):
    __tablename__ = 'job_cpt'

    job_cpt_id = Column(Integer, primary_key=True)
    LicenseKey = Column(String(45))
    IntegrationStatus = Column(String(45))
    ParentJob = Column(Integer)
    ProcessId = Column(Integer)


class JobDemographic(Base):
    __tablename__ = 'job_demographics'

    id = Column(Integer, primary_key=True)
    LicenseKey = Column(String(45))
    IntegrationStatus = Column(String(45))
    ParentJob = Column(Integer)
    ProcessId = Column(Integer)


class JobEligibility(Base):
    __tablename__ = 'job_eligibility'

    job_eligibility_id = Column(Integer, primary_key=True)
    LicenseKey = Column(Integer)
    IntegrationStatus = Column(Integer)
    ParentJob = Column(Integer)
    ProcessId = Column(Integer)


class JobInsurance(Base):
    __tablename__ = 'job_insurance'

    job_insurance_id = Column(Integer, primary_key=True)
    LicenseKey = Column(String(45))
    IntegrationStatus = Column(String(45))
    ParentJob = Column(Integer)
    ProcessId = Column(Integer)


class JobPatient(Base):
    __tablename__ = 'job_patients'

    job_patient_id = Column(Integer, primary_key=True)
    LicenseKey = Column(String(45))
    IntegrationStatus = Column(String(45))
    ParentJob = Column(Integer)
    ProcessId = Column(Integer)


class JobVisit(Base):
    __tablename__ = 'job_visits'

    job_visit_id = Column(Integer, primary_key=True)
    LicenseKey = Column(String(45))
    IntegrationStatus = Column(String(45))
    ParentJob = Column(Integer)
    ProcessId = Column(Integer)


class LicenseKey(Base):
    __tablename__ = 'license_keys'

    id = Column(Integer, primary_key=True)
    license_key = Column(Integer)
    manager_id = Column(Integer)
    api_username = Column(String(45))
    api_password = Column(String(500))
    api_appname = Column(String(45))
    status = Column(Integer)
    client_name = Column(String(45))
    type = Column(Integer)
    api_token = Column(String(45))
    off_peak_multiplier = Column(Integer)
    peak_multiplier = Column(Integer)
    last_login = Column(DateTime)
    api_url = Column(String(45))
    sftp_host = Column(String(45))
    sftp_port = Column(String(45))
    sftp_user_name = Column(String(45))
    sftp_password = Column(String(45))
    hl7_status = Column(Integer)
    claim_limit = Column(Integer)
    default_hl7_config = Column(Integer)
    demo_hl7_config = Column(Integer)
    charge_hl7_config = Column(Integer)


class MacroProc(Base):
    __tablename__ = 'macro_proc'

    id = Column(Integer, primary_key=True)
    charge_schedule_id = Column(String(45))
    allow_schedule_id = Column(Integer)
    dos = Column(Date)
    proccode_id = Column(String(45))
    proccode_code = Column(String(45))
    proccode_name = Column(String(45))
    proccode_units = Column(DECIMAL(10, 0))
    proccode_pos = Column(String(45))
    proccode_tos = Column(String(45))


class ClaimInfoMacroProc(MacroProc):
    __tablename__ = 'claim_info_macro_proc'

    macro_proc_id = Column(ForeignKey('macro_proc.id'), primary_key=True)
    claim_id = Column(Integer)


class MfCarrier(Base):
    __tablename__ = 'mf_carriers'

    carrier_code = Column(String(45), primary_key=True)
    carrier_name = Column(String(45))
    state = Column(String(45))


class MfFacility(Base):
    __tablename__ = 'mf_facilities'

    id = Column(Integer, primary_key=True)
    ClaimId = Column(Integer, nullable=False)
    LicenseKey = Column(Integer)
    FacilityName = Column(String(50), nullable=False)
    IntegrationStatus = Column(Integer)


t_office_key_status_extended = Table(
    'office_key_status_extended', metadata,
    Column('LicenseKey', Integer),
    Column('Sent', BigInteger),
    Column('Deleted', BigInteger),
    Column('Rejected', BigInteger),
    Column('InQueue', BigInteger)
)

t_office_key_status_pivot = Table(
    'office_key_status_pivot', metadata,
    Column('LicenseKey', Integer),
    Column('Sent', DECIMAL(41, 0)),
    Column('Deleted', DECIMAL(41, 0)),
    Column('Rejected', DECIMAL(41, 0)),
    Column('InQueue', DECIMAL(41, 0))
)

t_office_key_status_pivot_pretty = Table(
    'office_key_status_pivot_pretty', metadata,
    Column('LicenseKey', Integer),
    Column('Sent', DECIMAL(41, 0), server_default=text("'0'")),
    Column('Deleted', DECIMAL(41, 0), server_default=text("'0'")),
    Column('Rejected', DECIMAL(41, 0), server_default=text("'0'")),
    Column('InQueue', DECIMAL(41, 0), server_default=text("'0'"))
)


class OpUser(Base):
    __tablename__ = 'op_user'

    id = Column(Integer, primary_key=True)
    username = Column(String(100))
    password_hash = Column(String(1000))
    access_token = Column(String(1000))
    status = Column(Integer)
    salt = Column(String(500))
    failed_attempts = Column(Integer)
    is_manager = Column(Integer, server_default=text("'0'"))
    user_role = Column(Integer, server_default=text("'0'"))
    first_name = Column(String(100))
    last_name = Column(String(100))
    email = Column(String(100))
    supervisor = Column(Integer, server_default=text("'0'"))
    # firebase_token = Column(String(1024))


t_pending_claim_demographics_by_jobs = Table(
    'pending_claim_demographics_by_jobs', metadata,
    Column('Job_id', Integer),
    Column('PendingClaims', BigInteger, server_default=text("'0'"))
)


class Proc(Base):
    __tablename__ = 'proc'

    id = Column(Integer, primary_key=True)
    proccode = Column(String(45))
    amount = Column(DECIMAL(10, 0))
    amd_id = Column(String(45))


class ProcedureCode(Base):
    __tablename__ = 'procedure_code'

    proc_code = Column(String(45), primary_key=True)
    description = Column(String(45))


class PtReferralplan(Base):
    __tablename__ = 'pt_referralplans'

    id = Column(Integer, primary_key=True)
    ClaimId = Column(Integer, nullable=False)
    LicenseKey = Column(Integer)
    DiagnosisCodes = Column(String(255))
    IntegrationStatus = Column(Integer, nullable=False)
    BeginDate = Column(String(100))
    DiagCodes = Column(String(100))
    EndDate = Column(DATETIME(fsp=6))
    Facility = Column(String(100))
    MaxAmount = Column(String(100))
    MaxVisits = Column(String(100))
    PreAuth = Column(String(100))
    PreauthReq = Column(String(100))
    ProcCode = Column(String(100))
    Reason = Column(String(100))
    RefNum = Column(String(100))
    Refprov = Column(String(100))
    Status = Column(String(100))
    UsedAmount = Column(String(100))
    UsedVisits = Column(String(100))
    dx_codes = Column(Text)


class VisitDt(Base):
    __tablename__ = 'visit_dt'

    id = Column(Integer, primary_key=True)
    visit_id = Column(String(45))
    visit_sequence = Column(String(45))
    visit_date = Column(Date)
    isappt = Column(String(45))
    amd_visitcol = Column(Integer)
    visit_profile = Column(String(45))
    visit_episode = Column(String(45))
    insorder = Column(String(45))
    note = Column(String(45))
    forcepaper = Column(Integer)
    facility = Column(String(45))
    visit_refplan = Column(String(45))
    copayid = Column(String(45))
    licensekey = Column(Integer)
    referenceid = Column(String(45))
    providercodeset = Column(Integer)
    billingnote = Column(String(45))
    preauth = Column(String(45))
    onhcfa = Column(Integer)
    acceptassign = Column(Integer)
    force = Column(Integer)
    claimid = Column(Integer)


class VisitJob(Base):
    __tablename__ = 'visit_jobs'

    job_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    type = Column(String(10))
    LicenseKey = Column(Integer)


class IClaim(Base):
    __tablename__ = 'i_claims'

    claimid = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer, nullable=False)
    Job_id = Column(ForeignKey('i_jobs.jobid'), nullable=False, index=True)
    SerialNumber = Column(String(100), nullable=False)
    Eligible = Column(TINYINT)
    ProcessId = Column(Integer, server_default=text("'0'"))
    LicenseKey = Column(String(45))
    template_id = Column(ForeignKey('claim_template.id'), index=True)
    financial_class_code = Column(String(45))
    insurance_created = Column(TINYINT)
    visitid = Column(String(45))
    batchid = Column(Integer)
    cpts_created = Column(TINYINT)
    created_dt = Column(DateTime)
    feeschedid = Column(String(45))
    ResponsibleFacilityAccountNumber = Column(String(500))
    rendering_provider_code = Column(String(45))
    facility_code = Column(String(45))
    cpts = Column(String(1000))
    mods = Column(String(1000))
    units = Column(String(1000))
    auto_approved = Column(TINYINT)
    approved_dt = Column(DateTime)
    deleted_at = Column(DateTime)
    primary_dx_code = Column(String(45))
    claim_type = Column(Integer)
    is_cip_claims = Column(TINYINT)
    dx_codes = Column(Text)
    sync_status = Column(Integer)

    Job = relationship('IJob')
    template = relationship('ClaimTemplate')


class ModcodeConfiguration(Base):
    __tablename__ = 'modcode_configurations'

    id = Column(Integer, primary_key=True)
    mod_type = Column(String(45))
    modifier_code = Column(String(45))
    template_id = Column(ForeignKey('claim_template.id'), index=True)
    carrier_code = Column(String(45))
    proc_code = Column(ForeignKey('procedure_code.proc_code'), index=True)
    sequence_no = Column(Integer)

    procedure_code = relationship('ProcedureCode')
    template = relationship('ClaimTemplate')


class TemplateConfiguration(Base):
    __tablename__ = 'template_configuration'

    id = Column(Integer, primary_key=True)
    configuration_type = Column(ForeignKey('claim_configuration_type.configuration_code'), index=True)
    value = Column(String(45))
    template_id = Column(ForeignKey('claim_template.id'), index=True)
    status = Column(TINYINT, server_default=text("'0'"))

    claim_configuration_type = relationship('ClaimConfigurationType')
    template = relationship('ClaimTemplate')


class ActvChargedetail(Base):
    __tablename__ = 'actv_chargedetail'

    id = Column(Integer, primary_key=True)
    ClaimId = Column(ForeignKey('i_claims.claimid'), nullable=False, index=True)
    LicenseKey = Column(Integer)
    DiagnosisCodes = Column(String(255))
    IntegrationStatus = Column(Integer, nullable=False)
    ModCode = Column(String(255))
    BeginDateOfService = Column(DATETIME(fsp=6))
    EndDateOfService = Column(DATETIME(fsp=6))
    DiagCodes = Column(String(45))
    Units = Column(DECIMAL(10, 0))
    FinancialClassCode = Column(String(45))
    Aging = Column(Date)
    ProcCode = Column(String(45))
    ProcValue = Column(String(45))
    Pos = Column(String(45))
    Tos = Column(String(45))
    Fee = Column(String(45))
    Allowed = Column(String(45))
    PatPortion = Column(String(45))
    dx_codes = Column(Text)

    i_claim = relationship('IClaim')


class ClaimCharge(Base):
    __tablename__ = 'claim_charge'

    claim_charge_id = Column(Integer, primary_key=True)
    nodeid = Column(Integer)
    respparty = Column(String(45))
    asstprovider = Column(String(45))
    begindate = Column(Date)
    enddate = Column(Date)
    iscustomfieldsedited = Column(Integer)
    begintime = Column(Time)
    duration = Column(Integer)
    endtime = Column(Time)
    diagcodes = Column(String(45))
    modcodes = Column(String(45))
    finclasscode = Column(String(45))
    aging = Column(Date)
    lineitemnote = Column(String(45))
    updateref = Column(Integer)
    billlab = Column(Integer)
    proccode = Column(String(45))
    procvalue = Column(String(45))
    cobcode = Column(String(45))
    claim_chargecol = Column(String(45))
    pos = Column(String(45))
    tos = Column(String(45))
    units = Column(DECIMAL(10, 4))
    ndcquantity = Column(Integer)
    ndcprice = Column(String(45))
    ndcmeasurefid = Column(String(45))
    ndcmeasurename = Column(String(45))
    includecmndata = Column(Integer)
    userfileformfid = Column(Integer)
    billins = Column(Integer)
    netfee = Column(Integer)
    fee = Column(DECIMAL(10, 4))
    allowed = Column(DECIMAL(10, 4))
    patportion = Column(DECIMAL(10, 4))
    insportion = Column(DECIMAL(10, 4))
    patbalance = Column(DECIMAL(10, 4))
    insbalance = Column(DECIMAL(10, 4))
    debitadj = Column(Integer)
    code = Column(String(45))
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    visit_id = Column(ForeignKey('visit_dt.id'), index=True)

    i_claim = relationship('IClaim')
    visit = relationship('VisitDt')


class ClaimCpt(Base):
    __tablename__ = 'claim_cpt'

    claim_cpt_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_cpt_id = Column(ForeignKey('job_cpt.job_cpt_id'), index=True)
    ProcessId = Column(Integer)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)

    i_claim = relationship('IClaim')
    job_cpt = relationship('JobCpt')


class ClaimDemographic(Base):
    __tablename__ = 'claim_demographics'

    claim_demo_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_demo_id = Column(ForeignKey('job_demographics.id'), index=True)
    Eligible = Column(TINYINT)
    ProcessId = Column(Integer)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    patientid = Column(Integer)

    i_claim = relationship('IClaim')
    job_demo = relationship('JobDemographic')


class ClaimEligibility(Base):
    __tablename__ = 'claim_eligibility'

    claim_eligibility_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    Eligibility = Column(TINYINT)
    ProcessId = Column(Integer)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    patientid = Column(String(45))
    job_eligibility_id = Column(ForeignKey('job_eligibility.job_eligibility_id'), index=True)

    i_claim = relationship('IClaim')
    job_eligibility = relationship('JobEligibility')


class ClaimInsurance(Base):
    __tablename__ = 'claim_insurance'

    claim_insurance_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_insurance_id = Column(ForeignKey('job_insurance.job_insurance_id'), index=True)
    ProcessId = Column(Integer)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)

    i_claim = relationship('IClaim')
    job_insurance = relationship('JobInsurance')


class ClaimPatient(Base):
    __tablename__ = 'claim_patients'

    claim_patient_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_patient_id = Column(ForeignKey('job_patients.job_patient_id'), index=True)
    ProcessId = Column(Integer)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)

    i_claim = relationship('IClaim')
    job_patient = relationship('JobPatient')


class ClaimVisit(Base):
    __tablename__ = 'claim_visits'

    claim_visit_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_visit_id = Column(ForeignKey('job_visits.job_visit_id'), index=True)
    ProcessId = Column(Integer)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)

    i_claim = relationship('IClaim')
    job_visit = relationship('JobVisit')


class PtPatientinfoDummy(Base):
    __tablename__ = 'pt_patientinfo_dummy'

    id = Column(Integer, primary_key=True)
    ClaimId = Column(ForeignKey('i_claims.claimid'), nullable=False, index=True)
    LicenseKey = Column(Integer)
    Patient_UID = Column(Integer)
    Accession = Column(String(30))
    LastName = Column(String(35), nullable=False)
    FirstName = Column(String(35), nullable=False)
    MiddleName = Column(String(35))
    ChartNumber = Column(String(12))
    Title = Column(String(15))
    AptSte = Column(String(30))
    Address1 = Column(String(300))
    Address2 = Column(String(300))
    ZipCode = Column(String(10))
    City = Column(String(30))
    State = Column(String(3))
    AreaCode = Column(String(3))
    CountryCode = Column(String(3))
    OfficePhone = Column(String(25))
    OfficeExtension = Column(String(6))
    HomePhone = Column(String(25))
    Other = Column(String(25))
    PhoneType = Column(String(1))
    Email = Column(String(50))
    MaritalStatus = Column(SmallInteger)
    DOB = Column(Date)
    Deceased = Column(DATETIME(fsp=6))
    Gender = Column(String(1))
    Relationship = Column(SmallInteger)
    Employer = Column(String(100))
    IntegrationStatus = Column(Integer, nullable=False)
    FinancialClass = Column(String(30))
    InsurancePolicy1 = Column(String(100))
    InsurancePolicy2 = Column(String(100))
    InsurancePolicy3 = Column(String(100))
    InsuranceProvider1 = Column(String(100))
    InsuranceProvider2 = Column(String(100))
    InsuranceProvider3 = Column(String(100))
    SSN = Column(String(12))
    PatientID = Column(String(30))
    PrimaryReferringProvider = Column(String(100))
    PrimaryRenderingProvider = Column(String(100))
    CarrierCode1 = Column(String(100))
    CarrierCode2 = Column(String(100))
    CarrierCode3 = Column(String(100))
    SerialNumber = Column(String(45))
    AMDPatientName = Column(String(100))
    referring_provider_npi = Column(String(45))
    patient_ethnicity = Column(String(45))
    patient_races = Column(String(45))
    patient_HIPPA_rel = Column(String(45))
    old_chart_no = Column(String(45))
    amd_patient_chart_no = Column(String(45))
    record_number = Column(Integer)
    status = Column(String(50))

    i_claim = relationship('IClaim')


class Visit(Base):
    __tablename__ = 'visits'

    accession = Column(String(100), nullable=False)
    IntegrationStatus = Column(Integer)
    visit_number = Column(Integer, primary_key=True)
    status = Column(Integer, nullable=False, server_default=text("'0'"))
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    LicenseKey = Column(Integer)

    i_claim = relationship('IClaim')


class VisitProces(Base):
    __tablename__ = 'visit_process'

    id = Column(Integer, primary_key=True)
    accession_visit_job = Column(ForeignKey('visit_jobs.job_id'), index=True)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    LicenseKey = Column(Integer)
    IntegrationStatus = Column(Integer, server_default=text("'0'"))
    visitnumber = Column(Integer, index=True)

    visit_job = relationship('VisitJob')
    i_claim = relationship('IClaim')


class MfPatient(Base):
    __tablename__ = 'mf_patients'

    id = Column(Integer, primary_key=True)
    amd_patientid = Column(String(45))
    insurance_eligible = Column(TINYINT)
    resppartyid = Column(String(45))
    first_name = Column(String(45))
    middle_name = Column(String(45))
    last_name = Column(String(45))
    dob = Column(Date)
    created = Column(TINYINT)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)

    i_claim = relationship('IClaim')


class InsurancePlan(Base):
    __tablename__ = 'insurance_plans'

    id = Column(Integer, primary_key=True)
    patient_id = Column(String(45))
    insurance_id = Column(String(45))
    eligible = Column(TINYINT)
    order = Column(Integer)
    amd_respartyid = Column(String(45))
    amd_carrierid = Column(String(45))
    insnotefid = Column(String(45))
    subscriber_number = Column(String(45))
    license_key = Column(Integer)
    claimid = Column(Integer)
    ins_plan_Id = Column(String(45))
    ins_plan_name = Column(String(100))
    ins_plan_addr1_1 = Column(String(50))
    ins_plan_addr2_1 = Column(String(50))
    ins_plan_city = Column(String(45))
    ins_plan_st1 = Column(String(45))
    ins_plan_zip1 = Column(String(45))
    ins_begin_date1 = Column(Date)
    ins_pol_hldr_HIPAA_rel1 = Column(String(45))
    ins_group_number1 = Column(String(45))
    ins_cert_num1 = Column(String(45))
    provider_name = Column(String(45))
    record_number = Column(Integer)
    status = Column(String(100))


class UpdatePatientInfo(Base):
    __tablename__ = 'update_patient_info'

    id = Column(Integer, primary_key=True)
    SerialNumber = Column(String(45))
    gender = Column(String(45))
    amd_patientid = Column(String(45))
    first_name = Column(String(45))
    last_name = Column(String(45))
    updated = Column(TINYINT, server_default=text("'0'"))
    LicenseKey = Column(String(45))
    IntegrationStatus = Column(Integer, server_default=text("'0'"))


class JobUpdatePatient(Base):
    __tablename__ = 'job_update_patient'

    id = Column(Integer, primary_key=True)
    job_id = Column(Integer)
    LicenseKey = Column(Integer)
    IntegrationStatus = Column(Integer)


class ClaimUpdatedPatient(Base):
    __tablename__ = 'claim_updated_patient'

    id = Column(Integer, primary_key=True)
    job_id = Column(ForeignKey('job_update_patient.id'), index=True)
    IntegrationStatus = Column(Integer)
    update_claim_info_id = Column(ForeignKey('update_patient_info.id'), index=True)

    job = relationship('JobUpdatePatient')
    update_claim_info = relationship('UpdatePatientInfo')


class ResponsibileParty(Base):
    __tablename__ = 'responsibile_party'

    id = Column(Integer, primary_key=True)
    claim_respparty = Column(String(45))
    license_key = Column(Integer)
    patient_id = Column(String(45))
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    default_resparty = Column(String(45))

    i_claim = relationship('IClaim')


class ProcessChain(Base):
    __tablename__ = 'process_chain'

    id = Column(Integer, primary_key=True)
    chain_name = Column(String(45))


class BillType(Base):
    __tablename__ = 'bill_type'

    id = Column(Integer, primary_key=True)
    bill_name = Column(String(100))
    status = Column(SmallInteger)


class ProcessChainDt(Base):
    __tablename__ = 'process_chain_dt'

    id = Column(Integer, primary_key=True)
    next = Column(Integer)
    next_runner_type = Column(String(45))
    current = Column(Integer)
    current_stage_type = Column(String(45))
    stage_multiplier = Column(Integer)
    chain_id = Column(ForeignKey('process_chain.id'), index=True)

    chain = relationship('ProcessChain')


class VoidVisits(Base):
    __tablename__ = 'void_visits'

    visit_id = Column(Integer, primary_key=True)
    visit_number = Column(Integer)
    CreatedAt = Column(DateTime)
    CreatedBy = Column(String(45))
    LicenseKey = Column(Integer, nullable=False, server_default=text("'0'"))
    SerialNumber = Column(String(45))
    status = Column(Integer, nullable=False, server_default=text("'0'"))
    VoidedAt = Column(DateTime)
    process_id = Column(Integer)


class VisitVoidJob(Base):
    __tablename__ = 'job_visit_void'

    job_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    LicenseKey = Column(Integer)


class SpltVisitVoid(Base):
    __tablename__ = 'visit_void_splt'

    id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_visit_id = Column(ForeignKey('job_visit_void.job_id'), index=True)
    LicenseKey = Column(Integer)
    visit_number_id = Column(ForeignKey('void_visits.visit_id'), index=True)

    v_visit = relationship('VoidVisits')
    job_visit = relationship('VisitVoidJob')


# Define the errors_dt table as ErrorsDt class model
class ErrorsDt(Base):
    __tablename__ = 'errors_dt'

    id = Column(Integer, primary_key=True)
    detail_description = Column(String(45))
    type_id = Column(ForeignKey('errors_type.id'), index=True)
    status = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    license_key = Column(Integer)


class CarrierMf(Base):
    __tablename__ = 'carrier_crosswalk_mf'

    id = Column(Integer, primary_key=True)
    file_name = Column(String(45))
    status = Column(Integer, nullable=False, server_default=text("'0'"))
    license_key = Column(Integer)


class CarrierDt(Base):
    __tablename__ = 'carrier_crosswalk_dt'

    id = Column(Integer, primary_key=True)
    carrier_name = Column(String(500))
    amd_code = Column(String(45))
    status = Column(Integer, nullable=False, server_default=text("'0'"))
    file_id = Column(ForeignKey('carrier_crosswalk_mf.id'), index=True)
    license_key = Column(Integer)

    carrier_mf = relationship('CarrierMf')


class HLSevenMf(Base):
    __tablename__ = 'hl_seven_mf'

    id = Column(Integer, primary_key=True)
    main_field = Column(String(45))
    segment = Column(String(45))
    is_mulitple = Column(Integer, nullable=False, server_default=text("'0'"))
    license_key = Column(Integer, nullable=False)


class HLSevenDt(Base):
    __tablename__ = 'hl_seven_config_dt'

    id = Column(Integer, primary_key=True)
    field_name = Column(String(45))
    segment_name = Column(String(45))
    segment_index = Column(Integer, nullable=False)
    segemnt_loc = Column(String(45))
    license_key = Column(Integer, nullable=False)
    segment_type = Column(Integer, nullable=False)


class RefProviderMf(Base):
    __tablename__ = 'reffering_prov_crosswalk_mf'

    id = Column(Integer, primary_key=True)
    file_name = Column(String(45))
    status = Column(Integer, nullable=False, server_default=text("'0'"))
    license_key = Column(Integer)


class RefProviderDt(Base):
    __tablename__ = 'reffering_prov_crosswalk_dt'

    id = Column(Integer, primary_key=True)
    provider_name = Column(String(500))
    provider_code = Column(String(45))
    status = Column(Integer, nullable=False, server_default=text("'0'"))
    file_id = Column(ForeignKey('reffering_prov_crosswalk_mf.id'), index=True)
    license_key = Column(Integer)

    carrier_mf = relationship('RefProviderMf')


class JobApproval(Base):
    __tablename__ = 'job_approvals'

    job_approval_id = Column(Integer, primary_key=True)
    LicenseKey = Column(String(45))
    IntegrationStatus = Column(String(45))


class ClaimApprovals(Base):
    __tablename__ = 'claim_approvals'

    claim_approval_id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_approval_id = Column(ForeignKey('job_approvals.job_approval_id'), index=True)
    LicenseKey = Column(Integer)
    claimid = Column(ForeignKey('i_claims.claimid'), index=True)
    visitid = Column(String(45))

    i_claim = relationship('IClaim')
    job_approval = relationship('JobApproval')


class AutomateCredentials(Base):
    __tablename__ = 'automation_crdentials'

    id = Column(Integer, primary_key=True)
    status = Column(Integer)
    client_name = Column(String(45))
    username = Column(String(45))
    password = Column(String(45))
    updated_by = Column(String(45))
    updated_at = Column(DateTime)


class UserLicense(Base):
    __tablename__ = 'user_license'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    licensekey_id = Column(Integer)
    created_by = Column(String(45))
    created_at = Column(DateTime)


class ErrorType(Base):
    __tablename__ = 'errors_type'

    id = Column(Integer, primary_key=True)
    type = Column(String(45))
    description = Column(String(45))
    status = Column(Integer)


class UploadClaims(Base):
    __tablename__ = 'upload_claims'

    id = Column(Integer, primary_key=True)
    filename = Column(String(300))
    license_key = Column(Integer)
    templateId = Column(Integer)
    CarrierCode1 = Column(String(45))
    CarrierCode2 = Column(String(45))
    CarrierCode3 = Column(String(45))
    DiagnosisCodes = Column(String(255))
    InsurancePolicy1 = Column(String(100))
    InsurancePolicy2 = Column(String(100))
    InsurancePolicy3 = Column(String(100))
    InsuranceProvider1 = Column(String(100))
    PatientAddress1 = Column(String(300))
    PatientAddress2 = Column(String(300))
    PatientBirthDate = Column(Date)
    PatientCity = Column(String(30))
    PatientEmail = Column(String(45))
    PatientFirstName = Column(String(45))
    PatientGender = Column(String(45))
    PatientLastName = Column(String(45))
    PatientMiddleName = Column(String(45))
    PatientPhone = Column(String(45))
    PatientState = Column(String(45))
    PatientZip = Column(String(45))
    PhysicianFirstName = Column(String(45))
    PhysicianLastName = Column(String(45))
    PhysicianMiddleName = Column(String(45))
    PhysicianNPI = Column(String(45))
    ReferringProviderCode = Column(String(45))
    SerialNumber = Column(String(45))
    ServiceDate = Column(Date)
    Status = Column(String(45))
    ResponsibleFacilityAccountNumber = Column(String(500))
    FinancialClassCode = Column(String(45))
    RenderingProviderCode = Column(String(45))
    BillingFacilityCode = Column(String(45))
    CPTs = Column(String(500))
    MODs = Column(String(500))
    UNITs = Column(String(500))
    Created_dt = Column(DateTime)
    AutoApproved = Column(TINYINT)
    primary_dx_code = Column(String(45))
    process_id = Column(ForeignKey('i_processing.Id'), index=True)
    claim_type = Column(Integer)
    is_cip_claims = Column(TINYINT)
    dx_codes = Column(Text)

    process = relationship('IProcessing')


class LicenseKeyStatus(Base):
    __tablename__ = 'office_key_status'

    id = Column(Integer, primary_key=True)
    license_key = Column(Integer)
    patients_pending = Column(Integer)
    patients_errors = Column(Integer)
    patients_completed = Column(Integer)
    patients_no_of_processes = Column(Integer)
    patients_status = Column(String(50))
    resp_pending = Column(Integer)
    resp_errors = Column(Integer)
    resp_completed = Column(Integer)
    resp_no_of_processes = Column(Integer)
    resp_status = Column(String(50))
    insurance_pending = Column(Integer)
    insurance_errors = Column(Integer)
    insurance_completed = Column(Integer)
    insurance_no_of_processes = Column(Integer)
    insurance_status = Column(String(50))
    eligibility_pending = Column(Integer)
    eligibility_errors = Column(Integer)
    eligibility_completed = Column(Integer)
    eligibility_no_of_processes = Column(Integer)
    eligibility_status = Column(String(50))
    cpt_pending = Column(Integer)
    cpt_errors = Column(Integer)
    cpt_completed = Column(Integer)
    cpt_no_of_processes = Column(Integer)
    cpt_status = Column(String(50))
    visit_pending = Column(Integer)
    visit_errors = Column(Integer)
    visit_completed = Column(Integer)
    visit_no_of_processes = Column(Integer)
    visit_status = Column(String(50))


class ClaimStatusMaster(Base):
    __tablename__ = 'claim_status_mf'

    id = Column(Integer, primary_key=True)
    file_name = Column(String(500))
    integration_status = Column(Integer)
    created_at = Column(DateTime)
    created_by = Column(String(45))
    license_key = Column(Integer)
    status_info = Column(String(500))
    error_detail = Column(String(500))


class ClaimOccurrence(Base):
    __tablename__ = 'claim_occurrence'

    id = Column(Integer, primary_key=True)
    claim_master_id = Column(Integer)
    license_key = Column(Integer)
    accession = Column(String(100))
    visit_number = Column(String(100))
    payer_id = Column(String(100))
    submitter_id = Column(String(100))
    submitter_name = Column(String(100))
    patient_first_name = Column(String(100))
    patient_last_name = Column(String(100))
    patient_dob = Column(Date)
    subscriber_member_id = Column(String(100))
    providers_npi = Column(String(100))
    rendering_provider = Column(String(100))
    from_date = Column(Date)
    to_date = Column(Date)
    carrier = Column(String(100))
    integration_status = Column(Integer)
    exception_details = Column(String(1000))
    exception_response = Column(String(1000))


class JobCse(Base):
    __tablename__ = 'job_cse'

    id = Column(Integer, primary_key=True)
    license_key = Column(Integer)
    status = Column(Integer)


class jobDtCse(Base):
    __tablename__ = 'job_dt_cse'

    id = Column(Integer, primary_key=True)
    job_cse_id = Column(Integer)
    claim_occurance_id = Column(Integer)
    status = Column(Integer)


class ClaimRules(Base):
    __tablename__ = 'rule_configuration_mf'

    rule_id = Column(Integer, primary_key=True)
    rule_type = Column(Integer)
    rule_name = Column(String(45))
    license_key = Column(Integer)
    IntegrationStatus = Column(Integer)
    template_id = Column(Integer)


class RuleConfigurations(Base):
    __tablename__ = 'rule_configuration_dt'

    id = Column(Integer, primary_key=True)
    rule_id = Column(Integer)
    configuration_code = Column(String(45))
    configuration_value = Column(String(500))
    condition_code = Column(Integer)
    remark = Column(String(500))
    IntegrationStatus = Column(Integer)


class RejectClaims(Base):
    __tablename__ = 'reject_claims'

    id = Column(Integer, primary_key=True)
    process_id = Column(Integer)
    rule_id = Column(Integer)
    upload_hl7_id = Column(Integer)
    accession = Column(String(45))
    license_key = Column(String(45))
    rejection_remark = Column(String(1000))
    IntegrationStatus = Column(Integer)


class RuleConfigurationType(Base):
    __tablename__ = 'rule_configuration_type'

    configuration_code = Column(String(100), primary_key=True)
    configuration_name = Column(String(500))


class RuleConditionType(Base):
    __tablename__ = 'rule_condition_type'

    condition_code = Column(String(100), primary_key=True)
    condition_name = Column(String(500))


class HLSevenClaimsMf(Base):
    __tablename__ = 'hl_seven_claims_mf'

    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    field_status = Column(Integer)
    config_id = Column(Integer)


class HLSevenClaimsConfig(Base):
    __tablename__ = 'hl_seven_claims_config'

    id = Column(Integer, primary_key=True)
    field_name = Column(String(100))
    segment_name = Column(String(45))
    segment_main_index = Column(Integer)
    segment_separator = Column(String(45))
    segment_sub_index = Column(Integer)
    configuration_id = Column(Integer)
    segment_type = Column(Integer)


class ErrorClearMf(Base):
    __tablename__ = 'error_clear_mf'

    id = Column(Integer, primary_key=True)
    file_name = Column(String(500))
    total_records = Column(Integer)
    license_key = Column(Integer)
    reason = Column(String(500))
    integration_status = Column(Integer)
    uploaded_by = Column(String(100))


class ErrorClearDt(Base):
    __tablename__ = 'error_clear_dt'

    id = Column(Integer, primary_key=True)
    license_key = Column(Integer)
    file_id = Column(Integer)
    accession = Column(String(500))


class SupportRequest(Base):
    __tablename__ = 'support_request'

    id = Column(Integer, primary_key=True)
    ticket_id = Column(String(45))
    subject = Column(String(100))
    description = Column(String(100))
    type = Column(String(45))
    client = Column(String(45))
    no_claims_effected = Column(Integer)
    afformentioned_blocked = Column(Integer)
    escalation_level = Column(String(45))
    remark = Column(String(100))
    is_open = Column(Integer)
    created_by = Column(String(100))
    modified_by = Column(String(100))
    created_date_time = Column(String(45))
    modified_date_time = Column(String(45))


class HLSevenConfigurationMf(Base):
    __tablename__ = 'hl_seven_configuration_mf'

    id = Column(Integer, primary_key=True)
    license_key = Column(Integer)
    configuration_id = Column(Integer)


class AmdDemoUpdate(Base):
    __tablename__ = 'amd_demo_update'

    record_no = Column(Integer, primary_key=True)
    process_date = Column(DateTime)
    message_date = Column(Date)
    source_file_name = Column(String(45))
    result = Column(String(45))
    error_id = Column(Integer)
    error_type = Column(String(45))
    error_info = Column(String(500))
    status = Column(Integer)


class HLSevenErrorTypes(Base):
    __tablename__ = 'hl_seven_error_types'

    error_id = Column(Integer, primary_key=True)
    error_type = Column(String(45))
    error_description = Column(String(100))


class WOMapping(Base):
    __tablename__ = 'wo_mapping'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    AMD_Group = Column(String(50), index=True)
    Office_Key = Column(String(50), index=True)
    TL_Email = Column(String(50))
    M_Email = Column(String(50))
    OM_Email = Column(String(50))
    SM_Email = Column(String(50))


class WOFileRecords(Base):
    __tablename__ = 'wo_file_records'

    ID = Column(BigInteger, primary_key=True, autoincrement=True)
    File_Name = Column(String(100), index=True)
    Office_Key = Column(String(50), index=True)
    Approved_By = Column(String(100), index=True)
    Source = Column(String(50), index=True)
    Uploaded_By = Column(ForeignKey('op_user.id'), index=True)
    Status = Column(String(50), index=True)
    Uploaded_Date_Time = Column(DateTime)
    Start_Date_Time = Column(DateTime)
    End_Date_Time = Column(DateTime)
    Total_Time_Taken = Column(String(50))
    Total_Records = Column(Integer)
    Processed_Records = Column(Integer)


class WOProcessRecords(Base):
    __tablename__ = 'wo_process_records'

    ID = Column(BigInteger, primary_key=True, autoincrement=True)
    file_record_id = Column(ForeignKey('wo_file_records.ID'), index=True)
    Row = Column(BigInteger)
    Visit_Number = Column(BigInteger, index=True)
    Code = Column(String(50), index=True)
    CPT = Column(String(10), index=True)
    Charge_Amount = Column(Float)
    Balance = Column(Float)
    WO_Amount = Column(Float)
    Reason = Column(String(255))
    Initiated_By = Column(String(100))
    Status = Column(String(50))
    Batch = Column(BigInteger, index=True)
    Date_Time = Column(DateTime)
    Flag = Column(String(50))
    is_process = Column(SmallInteger, index=True)


class Insurance_LicenseKey(Base):
    __tablename__ = 'insurance_licensekey_status'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    Insurance_Id = Column(Integer)
    Payer_Name = Column(String(255))
    Licence_Key_id = Column(Integer)
    Licence_Key = Column(Integer)
    Credentialing_Status = Column(String(255))
    IL_Status = Column(Integer)


class Notification(Base):
    __tablename__ = 'notification'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    notification_title = Column(String(255))
    created_by = Column(String(255))
    notification_details = Column(String(255))
    created_at = Column(DateTime)
    license_key = Column(Integer)


class NotificationUser(Base):
    __tablename__ = 'notification_user'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    notification_ID = Column(Integer)
    user_ID = Column(Integer)
    read_at = Column(DateTime)
    read_status = Column(Integer)
    created_at = Column(DateTime)


class RejectionCorrectionMapping(Base):
    __tablename__ = 'rejection_correction_mapping_dt'

    id = Column(Integer, primary_key=True)
    rejection_rule_id = Column(Integer)
    correction_rule_id = Column(Integer)
    rule_status = Column(Integer)


class CorrectionRuleConfigDt(Base):
    __tablename__ = 'correction_rule_config_dt'

    id = Column(Integer, primary_key=True)
    correction_rule_id = Column(Integer)
    if_payor = Column(Integer)
    if_cpt = Column(Integer)
    then_payor = Column(Integer)
    then_cpt = Column(Integer)
    rule_status = Column(Integer)


class CPTFees(Base):
    __tablename__ = 'cpt_fees'

    id = Column(Integer, primary_key=True)
    license_key = Column(Integer)
    insurance_company = Column(String(45))
    cpt_code = Column(String(45))
    cpt_rate = Column(Float)
    status = Column(Integer)
    payer_id = Column(String(45))


class HLSevenFieldsMf(Base):
    __tablename__ = 'hl_seven_fields_mf'

    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    status = Column(Integer)


class ApprovalVisits(Base):
    __tablename__ = 'approve_visits'

    approve_visits_id = Column(Integer, primary_key=True)
    visit_number = Column(Integer)
    CreatedAt = Column(DateTime)
    CreatedBy = Column(String(50))
    LicenseKey = Column(Integer, nullable=False, server_default=text("'0'"))
    SerialNumber = Column(String(45))
    status = Column(Integer, nullable=False, server_default=text("'0'"))
    ApprovedAt = Column(DateTime)
    ProcessId = Column(Integer)
    ApprovedBy = Column(String(50))


class VisitApproveJob(Base):
    __tablename__ = 'job_visit_approve'

    Job_Id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    LicenseKey = Column(Integer)


class SpltVisitApprove(Base):
    __tablename__ = 'visit_approve_split'

    id = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer)
    job_visit_approve_id = Column(ForeignKey('job_visit_approve.Job_Id'), index=True)
    LicenseKey = Column(Integer)
    visit_number_approve_id = Column(ForeignKey('approve_visits.approve_visits_id'), index=True)

    v_visit = relationship('ApprovalVisits')
    job_visit = relationship('VisitApproveJob')


class FacilityCodeIdMap(Base):
    __tablename__ = 'facility_code_mp'

    id = Column(Integer, primary_key=True)
    license_key = Column(Integer)
    facility_code = Column(String(50))
    facility_id = Column(String(50))


class StreamLineChat(Base):
    __tablename__ = 'streamline_chat'

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    sender = Column(ForeignKey('op_user.id'), index=True)
    license_key = Column(String(10), index=True)
    message = Column(Text)
    type = Column(String(20), index=True)
    created_at = Column(DateTime)


class InsurancePayer(Base):
    __tablename__ = 'insurance_payer'

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    payer_name = Column(String(150), index=True)
    career_code = Column(String(150), index=True)
    is_credentialed = Column(Integer, server_default=text("'0'"))
    is_era_activated = Column(Integer, server_default=text("'0'"))
    eta_to_get_paid = Column(Integer)


class InsuranceMaster(Base):
    __tablename__ = 'insurance_master'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    ChangeHealthcare_PayerID = Column(String(255))
    PayerAssigned_PayerID = Column(String(255))
    Payer_Name = Column(String(255))
    Connectivity_Type = Column(String(255))
    Authorization_Required = Column(String(255))
    Availity_PayorId = Column(String(255))


class Identifier(Base):
    __tablename__ = 'identifier'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(45))
    code = Column(String(45), primary_key=True)


class ProcessingRule(Base):
    __tablename__ = 'processing_rule'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(45))
    template_id = Column(Integer)
    logic_type_id = Column(Integer)
    license_key = Column(Integer)
    status = Column(Integer)
    rule_order = Column(Integer)


class LogicalGroup(Base):
    __tablename__ = 'logical_group'

    id = Column(Integer, primary_key=True, autoincrement=True)
    processing_rule_id = Column(Integer)
    name = Column(String(45))
    logic_type_id = Column(Integer)


class ComparisonOperator(Base):
    __tablename__ = 'comparison_operator'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(45))
    code = Column(String(45), primary_key=True)


class Comparison(Base):
    __tablename__ = 'comparison'

    id = Column(Integer, primary_key=True, autoincrement=True)
    logical_group_id = Column(Integer)
    identifier_id = Column(Integer)
    operation_id = Column(Integer)
    value = Column(String(100))
    message = Column(String(500))


class LogicType(Base):
    __tablename__ = 'logic_type'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(45))
    code = Column(String(45), primary_key=True)


class ServiceLineConfigurations(Base):
    __tablename__ = 'service_line_configurations'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    description = Column(String(500))
    is_macro = Column(TINYINT)
    macro = Column(String(45))
    line_id = Column(Integer)
    minimum_units = Column(Integer)
    maximum_units = Column(Integer)
    pos = Column(Integer)
    modifiers = Column(String(100))
    fee = Column(String(45))
    primary_dx_code = Column(String(45))
    is_mandatory = Column(TINYINT)
    do_not_bill = Column(TINYINT)
    allow_duplicates = Column(TINYINT)
    license_key = Column(Integer)
    status = Column(TINYINT)


class ServiceLinesTemplate(Base):
    __tablename__ = 'service_line_template_configurations'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    template_id = Column(Integer)
    service_line_id = Column(Integer)


class ReplacementServiceLines(Base):
    __tablename__ = 'replacement_service_lines'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    service_line_id = Column(Integer)
    is_macro = Column(TINYINT)
    replacement = Column(String(45))
    modifiers = Column(String(45))
    minimum_units = Column(Integer)
    maximum_units = Column(Integer)
    fee = Column(String(45))
    primary_dx_code = Column(String(45))
    pos = Column(Integer)
    macro = Column(String(45))
    is_mandatory = Column(TINYINT)
    allow_duplicates = Column(TINYINT)


class CarrierConfigurations(Base):
    __tablename__ = 'carrier_configurations'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    carrier_id = Column(Integer)
    carrier_description = Column(String(500))
    carrier_code = Column(String(45))
    replacement_carrier_code = Column(String(45))
    license_key = Column(Integer)
    status = Column(Integer)


class CarrierTemplateConfigurations(Base):
    __tablename__ = 'carrier_ template_configurations'

    ID = Column(Integer, primary_key=True, autoincrement=True)
    carrier_configuration_id = Column(Integer)
    template_id = Column(Integer)


class UploadHl7Claims(Base):
    __tablename__ = 'upload_hl7_claims'

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(300))
    license_key = Column(Integer)
    carrier_code1 = Column(String(45))
    dx_codes = Column(Text)
    insurance_policy1 = Column(String(100))
    insurance_provider1 = Column(String(100))
    patient_address1 = Column(String(300))
    patient_address2 = Column(String(300))
    patient_dob = Column(Date)
    patient_city = Column(String(30))
    patient_fname = Column(String(45))
    patient_gender = Column(String(45))
    patient_lname = Column(String(45))
    patient_phone = Column(String(45))
    patient_state = Column(String(45))
    patient_zip = Column(String(45))
    physician_fname = Column(String(45))
    physician_lname = Column(String(45))
    physician_npi = Column(String(45))
    referring_provider = Column(String(45))
    accession = Column(String(45))
    service_date = Column(Date)
    status = Column(String(45))
    cpts = Column(Text)
    mods = Column(Text)
    units = Column(Text)
    created_dt = Column(DateTime)
    process_id = Column(ForeignKey('i_processing.Id'), index=True)
    old_chart_number = Column(String(45))
    order_number = Column(Text)
    account_number = Column(String(45))
    guarantor_first_name = Column(String(45))
    guarantor_last_name = Column(String(45))
    template_id = Column(Integer)
    cpt_description = Column(Text)
    facility = Column(Text)
    msg_date = Column(String(45))
    msg_type = Column(String(45))
    patient_ssn = Column(String(45))
    sending_facility = Column(String(45))

    process = relationship('IProcessing')


class LineConfigurations(Base):
    __tablename__ = 'line_configurations'

    id = Column(Integer, primary_key=True, autoincrement=True)
    line_name = Column(String(300))
    is_macro = Column(TINYINT)
    standard_fee = Column(Integer)


class RuleProcessingHistory(Base):
    __tablename__ = 'rules_processing_history'

    id = Column(Integer, primary_key=True, autoincrement=True)
    created_dt = Column(DateTime)
    process_id = Column(Integer)
    license_key = Column(String(45))
    accession = Column(String(45))
    upload_hl7_id = Column(Integer)
    rule_action = Column(String(1000))
    applied_rule_ids = Column(Integer)


class GuarantorRelationship(Base):
    __tablename__ = 'guarantor_relationship'

    id = Column(Integer, primary_key=True, autoincrement=True)
    relationship_name = Column(String(128))


class OpUserRole(Base):
    __tablename__ = 'op_user_role'

    role_id = Column(Integer, primary_key=True)
    role_name = Column(String(100))
    role_slag = Column(String(100))


class OpPermissions(Base):
    __tablename__ = 'op_permissions'

    permission_id = Column(Integer, primary_key=True)
    permission_name = Column(String(200))
    permission_path = Column(String(500))


class OpRolePermissions(Base):
    __tablename__ = 'op_role_permission'

    id = Column(Integer, primary_key=True)
    permission_id = Column(ForeignKey('op_permissions.permission_id'), index=True)
    role_id = Column(ForeignKey('op_user_role.role_id'), index=True)


class Completed_mfPatients(Base):
    __tablename__ = 'completed_mf_patients'

    id = Column(Integer, primary_key=True)
    amd_patientid = Column(String(45))
    insurance_eligible = Column(TINYINT)
    resppartyid = Column(String(45))
    first_name = Column(String(45))
    middle_name = Column(String(45))
    last_name = Column(String(45))
    dob = Column(Date)
    created = Column(TINYINT)
    LicenseKey = Column(Integer)
    claimid = Column(Integer)


class CompletedClaims(Base):
    __tablename__ = 'completed_i_claims'

    claimid = Column(Integer, primary_key=True)
    IntegrationStatus = Column(Integer, nullable=False)
    Job_id = Column(Integer, nullable=False, index=True)
    SerialNumber = Column(String(100), nullable=False)
    Eligible = Column(TINYINT)
    ProcessId = Column(Integer, server_default=text("'0'"))
    LicenseKey = Column(String(45))
    template_id = Column(Integer, nullable=False, index=True)
    financial_class_code = Column(String(45))
    insurance_created = Column(TINYINT)
    visitid = Column(String(45))
    batchid = Column(Integer)
    cpts_created = Column(TINYINT)
    created_dt = Column(DateTime)
    feeschedid = Column(String(45))
    ResponsibleFacilityAccountNumber = Column(String(500))
    rendering_provider_code = Column(String(45))
    facility_code = Column(String(45))
    cpts = Column(String(1000))
    mods = Column(String(1000))
    units = Column(String(1000))
    auto_approved = Column(TINYINT)
    approved_dt = Column(DateTime)
    deleted_at = Column(DateTime)
    primary_dx_code = Column(String(45))
    claim_type = Column(Integer)
    is_cip_claims = Column(TINYINT)
    dx_codes = Column(Text)
    sync_status = Column(Integer)


class CompletedActvChargedetail(Base):
    __tablename__ = 'completed_actv_chargedetail'

    id = Column(Integer, primary_key=True)
    ClaimId = Column(Integer, nullable=False, index=True)
    LicenseKey = Column(Integer)
    DiagnosisCodes = Column(String(255))
    IntegrationStatus = Column(Integer, nullable=False)
    ModCode = Column(String(255))
    BeginDateOfService = Column(DATETIME(fsp=6))
    EndDateOfService = Column(DATETIME(fsp=6))
    DiagCodes = Column(String(45))
    Units = Column(DECIMAL(10, 0))
    FinancialClassCode = Column(String(45))
    Aging = Column(Date)
    ProcCode = Column(String(45))
    ProcValue = Column(String(45))
    Pos = Column(String(45))
    Tos = Column(String(45))
    Fee = Column(String(45))
    Allowed = Column(String(45))
    PatPortion = Column(String(45))
    dx_codes = Column(Text)


class CompletedPtPatientinfoDummy(Base):
    __tablename__ = 'completed_pt_patientinfo_dummy'

    id = Column(Integer, primary_key=True)
    ClaimId = Column(ForeignKey('i_claims.claimid'), nullable=False, index=True)
    LicenseKey = Column(Integer)
    Patient_UID = Column(Integer)
    Accession = Column(String(30))
    LastName = Column(String(35), nullable=False)
    FirstName = Column(String(35), nullable=False)
    MiddleName = Column(String(35))
    ChartNumber = Column(String(12))
    Title = Column(String(15))
    AptSte = Column(String(30))
    Address1 = Column(String(300))
    Address2 = Column(String(300))
    ZipCode = Column(String(10))
    City = Column(String(30))
    State = Column(String(3))
    AreaCode = Column(String(3))
    CountryCode = Column(String(3))
    OfficePhone = Column(String(25))
    OfficeExtension = Column(String(6))
    HomePhone = Column(String(25))
    Other = Column(String(25))
    PhoneType = Column(String(1))
    Email = Column(String(50))
    MaritalStatus = Column(SmallInteger)
    DOB = Column(Date)
    Deceased = Column(DATETIME(fsp=6))
    Gender = Column(String(1))
    Relationship = Column(SmallInteger)
    Employer = Column(String(100))
    IntegrationStatus = Column(Integer, nullable=False)
    FinancialClass = Column(String(30))
    InsurancePolicy1 = Column(String(100))
    InsurancePolicy2 = Column(String(100))
    InsurancePolicy3 = Column(String(100))
    InsuranceProvider1 = Column(String(100))
    InsuranceProvider2 = Column(String(100))
    InsuranceProvider3 = Column(String(100))
    SSN = Column(String(12))
    PatientID = Column(String(30))
    PrimaryReferringProvider = Column(String(100))
    PrimaryRenderingProvider = Column(String(100))
    CarrierCode1 = Column(String(100))
    CarrierCode2 = Column(String(100))
    CarrierCode3 = Column(String(100))
    SerialNumber = Column(String(45))
    AMDPatientName = Column(String(100))
    referring_provider_npi = Column(String(45))
    patient_ethnicity = Column(String(45))
    patient_races = Column(String(45))
    patient_HIPPA_rel = Column(String(45))
    old_chart_no = Column(String(45))
    amd_patient_chart_no = Column(String(45))
    record_number = Column(Integer)
    status = Column(String(50))


class CompletedPtReferralplan(Base):
    __tablename__ = 'completed_pt_referralplans'

    id = Column(Integer, primary_key=True)
    ClaimId = Column(Integer, nullable=False)
    LicenseKey = Column(Integer)
    DiagnosisCodes = Column(String(255))
    IntegrationStatus = Column(Integer, nullable=False)
    BeginDate = Column(String(100))
    DiagCodes = Column(String(100))
    EndDate = Column(DATETIME(fsp=6))
    Facility = Column(String(100))
    MaxAmount = Column(String(100))
    MaxVisits = Column(String(100))
    PreAuth = Column(String(100))
    PreauthReq = Column(String(100))
    ProcCode = Column(String(100))
    Reason = Column(String(100))
    RefNum = Column(String(100))
    Refprov = Column(String(100))
    Status = Column(String(100))
    UsedAmount = Column(String(100))
    UsedVisits = Column(String(100))
    dx_codes = Column(Text)


class SubmitterDetails(Base):
    __tablename__ = 'submitter_details'

    id = Column(Integer, primary_key=True)
    office_key = Column(Integer)
    name = Column(String(200))
    submitter_id = Column(String(45))