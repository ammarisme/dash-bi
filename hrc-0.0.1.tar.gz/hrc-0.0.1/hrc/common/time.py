import pytz
from datetime import datetime, time

def ispeak():
    u = datetime.utcnow()
    u = u.replace(tzinfo=pytz.utc)  # NO
    today = u.astimezone(pytz.timezone("America/Denver"))
    begin_time = datetime(today.year, today.month, today.day, 6, 0, 0, 0)
    end_time = datetime(today.year, today.month, today.day, 18, 0, 0, 0)
    begin_time = begin_time.replace(tzinfo=pytz.utc)  # NO
    end_time = end_time.replace(tzinfo=pytz.utc)  # NO
    print("System time: ", today)
    check_time = today
    return (check_time >= begin_time and check_time <= end_time) == False

def get_current_time():
    u = datetime.utcnow()
    u = u.replace(tzinfo=pytz.utc)  # NO
    today = u.astimezone(pytz.timezone("America/Denver"))
    return today

def add_hours(current_date_and_time, hours):
    hours_added = datetime.timedelta(hours=hours)
    future_date_and_time = current_date_and_time + hours_added
    return future_date_and_time

# def date_to_string(input_datetime):
#     datetime.datetime.strptime(input_datetime,'%m/%d/%Y').strftime('%Y-%m-%d')