from sqlalchemy.orm import Session

from hrc.common.database import get_mysql_connection
from hrc.integration_db.models import OpUser


def get_api_user():
    return "API"


def get_op_user(token, engine=None):
    token = 'cbbdea3cf9b1872855af2b777eba765a0f7721c598f82cb1d13dfe563d4629d89b0cff8a4e50df06b8c00135d1ed8932bb31e8d78a522cd8fafaaee5ac06d6d9'

    if engine is None:
        engine = get_mysql_connection()
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        op_user = session.query(OpUser).filter(OpUser.access_token == token).first()
        return op_user
