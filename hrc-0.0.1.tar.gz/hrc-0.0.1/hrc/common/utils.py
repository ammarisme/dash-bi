import os

from  hrc.settings import CONFIGURATION


def get_host_name():
    return CONFIGURATION.DB_HOST_NAME