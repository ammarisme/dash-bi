import os

from hrc.settings import CONFIGURATION


def get_api_url():
    IM_IN_DOCKER = os.environ.get('AM_I_IN_A_DOCKER_CONTAINER', False)
    if IM_IN_DOCKER:
        return CONFIGURATION.API_URL_DOCKER;
    else:
        return CONFIGURATION.API_URL;
