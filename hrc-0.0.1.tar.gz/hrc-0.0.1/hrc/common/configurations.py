import os

def get_application_mode():
    return os.environ['MODE'];