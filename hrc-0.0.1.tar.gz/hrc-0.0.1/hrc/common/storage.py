import io
import os
import sys
import traceback
from io import StringIO
from shareplum import Site
from shareplum import Office365
from shareplum.site import Version

from hrc.settings import CONFIGURATION

import ftplib
from ssl import SSLSocket


class ReusedSslSocket(SSLSocket):
    def unwrap(self):
        pass


class MyFTP_TLS(ftplib.FTP_TLS):
    """Explicit FTPS, with shared TLS session"""
    def ntransfercmd(self, cmd, rest=None):
        conn, size = ftplib.FTP.ntransfercmd(self, cmd, rest)
        if self._prot_p:
            conn = self.context.wrap_socket(conn,
                                            server_hostname=self.host,
                                            session=self.sock.session)  # reuses TLS session
            conn.__class__ = ReusedSslSocket  # we should not close reused ssl socket when file transfers finish
        return conn, size


def connect_ftp(working_directory="/"):
    print('connecting to ftp')
    try:
        ftp = MyFTP_TLS(CONFIGURATION.FTP_LOCATION, timeout=5)
        ftp.set_debuglevel(2)
        # ftp.set_pasv(False)
        ftp.login(CONFIGURATION.FTP_USERNAME, CONFIGURATION.FTP_PASSWORD)
        ftp.cwd(working_directory)
        print("connection successfull!")
        return ftp
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
    return None


def save_pd_to_ftp(your_pandas_df, filename,license_key):
    print('saving file to ftp: ', filename)
    try:
        ftp = connect_ftp(working_directory="/"+str(license_key))
        buffer = StringIO()
        your_pandas_df.to_csv(buffer)
        text = buffer.getvalue()
        bio = io.BytesIO(str.encode(text))
        ftp.prot_p()
        ftp.storbinary('STOR ' + filename, bio)
        ftp.close()
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        traceback.print_exc()


def save_pd_to_sharepoint(filedata, filename, license_key, process_id):
    print('saving file to sharepoint: ', filename)
    print('process id:', process_id)
    authcookie = Office365('https://healthxconnect.sharepoint.com',
                           username='thilinae@healthreconconnect.com',
                           password='1qaz2wsx@').GetCookies()
    site = Site('https://healthxconnect.sharepoint.com/sites/BillingAutomation/',
                version=Version.v365,
                authcookie=authcookie)

    folder = site.Folder('Shared Documents/' + str(license_key) + '/' + str(process_id))
    folder.upload_file(filedata.to_csv(index=False), filename)

def save_file_to_sharepoint(filedata, filename, license_key, process_id):
    print('saving file to sharepoint: ', filename)
    print('process id:', process_id)
    authcookie = Office365('https://healthxconnect.sharepoint.com',
                           username='thilinae@healthreconconnect.com',
                           password='1qaz2wsx@').GetCookies()
    site = Site('https://healthxconnect.sharepoint.com/sites/BillingAutomation/',
                version=Version.v365,
                authcookie=authcookie)

    folder = site.Folder('Shared Documents/' + str(license_key) + '/' + str(process_id))
    folder.upload_file(filedata, filename)

def read_file_from_sharepoint(filename, license_key, process_id):
    print('reading file from sharepoint: ', filename)
    print('process id:', process_id)
    authcookie = Office365('https://healthxconnect.sharepoint.com',
                           username='thilinae@healthreconconnect.com',
                           password='1qaz2wsx@').GetCookies()
    site = Site('https://healthxconnect.sharepoint.com/sites/BillingAutomation/',
                version=Version.v365,
                authcookie=authcookie)

    folder = site.Folder('Shared Documents/' + str(license_key) + '/' + str(process_id))
    file = folder.get_file(filename)
    return file


def get_ftp_file_list(ftp):
    files = []
    try:
        files = ftp.nlst()
    except resp:
        if str(resp) == "550 No files found":
            print("No files in this directory")
            return []
        else:
            raise
    return files
