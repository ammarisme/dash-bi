def log(message):
    print(message)
    print(message, file=open('output.txt', 'a'))