import os


def is_debug():
    return  'DEBUG' in os.environ and os.environ['DEBUG'] =='1'