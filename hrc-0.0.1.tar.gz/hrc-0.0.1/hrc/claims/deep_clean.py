import re
import numpy as np
import pandas as pd
from advancedmd.common.user import AMDUser
from luhn import verify as luhn_verify
from hrc.claims.clean import valid_template
from hrc.claims.validations import get_invalid_referring_provider_code, \
    validate_cpt_code, get_invalid_dx_codes_unique, check_invalid_dx_codes_in_df
from hrc.services import logging_service

logging = logging_service('claims')
amd_api_login_url = "https://provapi.advancedmd.com/processrequest/api-102/HEALTHRECON/xmlrpc/processrequest.asp"


def deep_clean(new_claim_data, token, template_id, claim_type, license_key):
    template = dict()
    template[template_id] = dict()

    # Convert to all the characters to uppercase and remove all the leading and trailing spaces in fields
    new_claim_data = new_claim_data.replace(np.nan, '', regex=True)
    new_claim_data = new_claim_data.apply(lambda x: x.astype(str).str.upper())
    new_claim_data = new_claim_data.apply(lambda x: x.astype(str).str.strip())
    new_claim_data.fillna('')

    # Create a column - "Remark" - use this column to write the claim record status
    new_claim_data["Remark"] = ''

    # Replace decimal points from the records
    new_claim_data['PhysicianNPI'] = new_claim_data['PhysicianNPI'].apply(lambda x: str(x).replace(".0", ""))
    new_claim_data['InsurancePolicy1'] = new_claim_data['InsurancePolicy1'].apply(lambda x: str(x).replace(".0", ""))
    new_claim_data['InsurancePolicy2'] = new_claim_data['InsurancePolicy2'].apply(lambda x: str(x).replace(".0", ""))
    new_claim_data['InsurancePolicy3'] = new_claim_data['InsurancePolicy3'].apply(lambda x: str(x).replace(".0", ""))
    new_claim_data['PatientZip'] = new_claim_data['PatientZip'].apply(lambda x: str(x).replace(".0", ""))
    new_claim_data['Accession'] = new_claim_data['Accession'].apply(lambda x: str(x).replace(".0", ""))

    # Remove all non ascii characters
    for col_name in new_claim_data.columns:
        new_claim_data[col_name] = new_claim_data[col_name].str.encode('ascii', 'ignore').str.decode('ascii')

    # Add a zero if patient zips' length==03
    new_claim_data['PatientZip'] = new_claim_data['PatientZip'].apply(lambda x: "0" + x if len(x) == 4 else x)

    # Claim details validations - PatientBirthDate -  validate a date string format
    new_claim_data['PatientBirthDate'] = pd.to_datetime(new_claim_data['PatientBirthDate'], format="%m/%d/%Y",
                                                        errors='coerce')
    new_claim_data['Remark'] = new_claim_data['PatientBirthDate'].apply(
        lambda x: 'Invalid DOB' if (pd.isnull(x)) else '')

    # Claim details validations - Service Date - validate a date string format
    new_claim_data['Service Date'] = pd.to_datetime(new_claim_data['Service Date'], format="%m/%d/%Y",
                                                    errors='coerce')
    new_claim_data['Remark'] = new_claim_data['Remark'] + new_claim_data['Service Date'].apply(
        lambda x: ' /Invalid Service Date' if (pd.isnull(x)) else '')

    # Claim details validations - Patient Gender - Only accept ["M","F","U"]
    new_claim_data.loc[(new_claim_data['PatientGender'] != 'M') & (new_claim_data['PatientGender'] != 'F')
                       & (new_claim_data['PatientGender'] != 'U'), 'Remark'] = new_claim_data[
                                                                                   'Remark'] + ' /Invalid Patient Gender '

    # Claim details validations - CarrierCode1/CarrierCode2/CarrierCode3 - check whether carrier code1,2,3 data are
    # alphanumeric or not

    new_claim_data['CarrierCode1_Isalnum'] = new_claim_data['CarrierCode1'].apply(
        lambda x: 'True' if ((pd.isnull(x)) | (x == "")) else 'False')
    new_claim_data.loc[(new_claim_data['CarrierCode1_Isalnum'] == 'True'), 'Remark'] = new_claim_data[
                                                                                           'Remark'] + ' /Carrier Code1 Required'
    new_claim_data.drop(["CarrierCode1_Isalnum"], inplace=True, axis=1)

    # Create custom function to check carrier codes are not null and alphanumeric
    def carrier_func(x):
        if x is not None and len(x) > 0:
            valid = re.match('^([a-zA-Z0-9-]+\s)*[a-zA-Z0-9-]+$', x) is not None
            if valid:
                return "Valid"

            elif valid is False:
                return "Invalid"

            if x is None or x == "":
                return 'X_None'

    # use above created custom function to check carrier codes are not null and alphanumeric
    new_claim_data['CarrierCode1_Isalnum'] = new_claim_data['CarrierCode1'].apply(carrier_func)
    new_claim_data.loc[(new_claim_data['CarrierCode1_Isalnum'] == 'Invalid'), 'Remark'] = new_claim_data[
                                                                                              'Remark'] + ' /Invalid Carrier Code1 '
    new_claim_data.drop(["CarrierCode1_Isalnum"], inplace=True, axis=1)

    new_claim_data['CarrierCode2_Isalnum'] = new_claim_data['CarrierCode2'].apply(carrier_func)
    new_claim_data.loc[(new_claim_data['CarrierCode2_Isalnum'] == 'Invalid'), 'Remark'] = new_claim_data[
                                                                                              'Remark'] + ' /Invalid Carrier Code2 '
    new_claim_data.drop(["CarrierCode2_Isalnum"], inplace=True, axis=1)

    new_claim_data['CarrierCode3_Isalnum'] = new_claim_data['CarrierCode3'].apply(carrier_func)
    new_claim_data.loc[(new_claim_data['CarrierCode3_Isalnum'] == 'Invalid'), 'Remark'] = new_claim_data[
                                                                                              'Remark'] + ' /Invalid Carrier Code3 '
    new_claim_data.drop(["CarrierCode3_Isalnum"], inplace=True, axis=1)

    # Claim details validations - ReferringProviderCode - check invalid code
    new_claim_data['ReferringProviderCode_Isalnum'] = new_claim_data['ReferringProviderCode'].apply(carrier_func)
    new_claim_data.loc[(new_claim_data['ReferringProviderCode_Isalnum'] == 'invalid'), 'Remark'] = new_claim_data[
                                                                                                       'Remark'] + '/Invalid Referring Provider Code '
    new_claim_data.drop(["ReferringProviderCode_Isalnum"], inplace=True, axis=1)

    # Claim details validations - ReferringProviderCode - check max length

    new_claim_data['ReferringProviderCode_Invalid'] = new_claim_data['ReferringProviderCode'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 100)) else 'False')
    new_claim_data.loc[(new_claim_data['ReferringProviderCode_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                    'Remark'] + ' /ReferringProviderCode max length :100 '

    # Claim details validations - ReferringProviderCode - check In Null or not
    new_claim_data.drop(["ReferringProviderCode_Invalid"], inplace=True, axis=1)
    new_claim_data['ReferringProviderCode_Invalid'] = new_claim_data['ReferringProviderCode'].apply(carrier_func)
    new_claim_data.loc[(new_claim_data['ReferringProviderCode_Invalid'] == 'X_is_Non'), 'Remark'] = new_claim_data[
                                                                                                        'Remark'] + ' /ReferringProviderCode is required '
    new_claim_data.drop(["ReferringProviderCode_Invalid"], inplace=True, axis=1)

    # Claim details validations - PhysicianNPI
    # Create custom function to check physician npi valid or invalid
    def phys_npi_func(x):
        if x is not None and len(x) > 0:
            if "E+" in x:
                return 'E_in_X'

            if x.isnumeric():
                if luhn_verify(str(x)):
                    return 'luhn_verify'
            else:
                return 'No_Numeric'

        if x is None or x == "":
            return 'X_None'

    # use above created custom function to check valid statuses of physician npi
    new_claim_data['PhysicianNPI_Invalid'] = new_claim_data['PhysicianNPI'].apply(phys_npi_func)
    new_claim_data.loc[(new_claim_data['PhysicianNPI_Invalid'] == 'E_in_X'), 'Remark'] = new_claim_data[
                                                                                             'Remark'] + ' /Invalid Physician NPI '
    new_claim_data.loc[(new_claim_data['PhysicianNPI_Invalid'] == 'luhn_verify'), 'Remark'] = new_claim_data[
                                                                                                  'Remark'] + ' /Invalid Physician NPI '
    new_claim_data.loc[(new_claim_data['PhysicianNPI_Invalid'] == 'X_None'), 'Remark'] = new_claim_data[
                                                                                             'Remark'] + ' /Physician NPI Required '
    new_claim_data.loc[(new_claim_data['PhysicianNPI_Invalid'] == 'No_Numeric'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /Invalid Physician NPI '
    new_claim_data.drop(["PhysicianNPI_Invalid"], inplace=True, axis=1)

    # Create custom function to check insurance policy validations
    def insurance_policy_func(x):
        if x is not None and len(x) > 0:
            valid = re.match('^[\w-]+$', x) is not None
            if "E+" in x:
                return 'E_in_X'

            elif len(x) > 100:
                return 'X_Length'

            elif valid is False:
                return "Invalid"

        if x is None or x == "":
            return 'X_None'

    # Use above created custom function to check valid statuses of InsurancePolicy1
    new_claim_data['InsurancePolicy1_Invalid'] = new_claim_data['InsurancePolicy1'].apply(insurance_policy_func)
    new_claim_data.loc[(new_claim_data['InsurancePolicy1_Invalid'] == 'E_in_X'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /Invalid InsurancePolicy1 '
    new_claim_data.loc[(new_claim_data['InsurancePolicy1_Invalid'] == 'X_None'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /InsurancePolicy1 Required'
    new_claim_data.loc[(new_claim_data['InsurancePolicy1_Invalid'] == 'X_Length'), 'Remark'] = new_claim_data[
                                                                                                   'Remark'] + ' /InsurancePolicy1 max length : 100'
    new_claim_data.loc[(new_claim_data['InsurancePolicy1_Invalid'] == 'Invalid'), 'Remark'] = new_claim_data[
                                                                                                  'Remark'] + ' /Invalid InsurancePolicy1'
    new_claim_data.drop(["InsurancePolicy1_Invalid"], inplace=True, axis=1)

    # Use above created custom function to check valid statuses of InsurancePolicy2
    new_claim_data['InsurancePolicy2_Invalid'] = new_claim_data['InsurancePolicy2'].apply(insurance_policy_func)
    new_claim_data.loc[(new_claim_data['InsurancePolicy2_Invalid'] == 'E_in_X'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /Invalid InsurancePolicy2 '
    new_claim_data.drop(["InsurancePolicy2_Invalid"], inplace=True, axis=1)

    # Use above created custom function to check valid statuses of InsurancePolicy3
    new_claim_data['InsurancePolicy3_Invalid'] = new_claim_data['InsurancePolicy3'].apply(insurance_policy_func)
    new_claim_data.loc[(new_claim_data['InsurancePolicy3_Invalid'] == 'E_in_X'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /Invalid InsurancePolicy3 '
    new_claim_data.drop(["InsurancePolicy3_Invalid"], inplace=True, axis=1)

    # Claim details validations - DiagnosisCodes - check whether diagnosis code is none or not and length of diagnose
    # code

    dx_codes_data = []
    for index, claim_data in new_claim_data.iterrows():

        dx_codes = [claim_data[col] for col in sorted(
            [column for column in new_claim_data.columns if 'DX_CODE' in column],
            key=lambda x: int(x.split('DX_CODE')[1]))]

        cpts = [claim_data[col] for col in sorted(
            [column for column in new_claim_data.columns if 'CPT' in column],
            key=lambda x: int(x.split('CPT')[1]))]

        cpts = [n for n in cpts if n != '']
        dx_codes = [n for n in dx_codes if n != '']

        dx_code_join_data = "|".join(dx_codes)
        dx_codes_data.append(dx_code_join_data)

        if ',' in dx_code_join_data:
            new_claim_data.at[index, 'Remark'] = new_claim_data.at[
                                                     index, 'Remark'] + ' /Invalid separator ",", only allowed "|"'

        if len(cpts) != len(dx_codes):
            new_claim_data.at[index, 'Remark'] = new_claim_data.at[index, 'Remark'] + ' /DxCodes and CPTs are mismatch'

    # Claim details validations - InsuranceProvider1 - check whether InsuranceProvider1 is none or not and length of
    # InsuranceProvider1
    new_claim_data['InsuranceProvider1_Invalid'] = new_claim_data['InsuranceProvider1'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 100)) else 'False')
    new_claim_data.loc[(new_claim_data['InsuranceProvider1_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /InsuranceProvider1 max length : 100 '
    new_claim_data.drop(["InsuranceProvider1_Invalid"], inplace=True, axis=1)

    new_claim_data['InsuranceProvider1_Invalid'] = new_claim_data['InsuranceProvider1'].apply(
        lambda x: 'True' if ((pd.isnull(x)) | (x == "")) else 'False')
    new_claim_data.loc[(new_claim_data['InsuranceProvider1_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /InsuranceProvider1 required '
    new_claim_data.drop(["InsuranceProvider1_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientAddress1
    new_claim_data['PatientAddress1_Invalid'] = new_claim_data['PatientAddress1'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 300)) else 'False')
    new_claim_data.loc[(new_claim_data['PatientAddress1_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                              'Remark'] + ' /PatientAddress1 max length : 300 '
    new_claim_data.drop(["PatientAddress1_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientAddress2
    new_claim_data['PatientAddress2_Invalid'] = new_claim_data['PatientAddress2'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 300)) else 'False')
    new_claim_data.loc[(new_claim_data['PatientAddress2_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                              'Remark'] + ' /PatientAddress2 max length : 300 '
    new_claim_data.drop(["PatientAddress2_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientCity
    new_claim_data['PatientCity_Invalid'] = new_claim_data['PatientCity'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 300)) else 'False')
    new_claim_data.loc[(new_claim_data['PatientCity_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                          'Remark'] + ' /PatientCity max length : 300 '
    new_claim_data.drop(["PatientCity_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientFirstName
    new_claim_data['PatientFirstName_Invalid'] = new_claim_data['PatientFirstName'].apply(
        lambda x: "True" if ((pd.isnull(x)) | (x == "")) else "False")
    new_claim_data.loc[(new_claim_data['PatientFirstName_Invalid'] == "True"), 'Remark'] = new_claim_data[
                                                                                               'Remark'] + ' /PatientFirstName is required '
    new_claim_data.drop(["PatientFirstName_Invalid"], inplace=True, axis=1)

    new_claim_data['PatientFirstName_Invalid'] = new_claim_data['PatientFirstName'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 35)) else 'False')
    new_claim_data.loc[(new_claim_data['PatientFirstName_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                               'Remark'] + ' /PatientFirstName max length : 35 '
    new_claim_data.drop(["PatientFirstName_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientLastName
    new_claim_data['PatientLastName_Invalid'] = new_claim_data['PatientLastName'].apply(
        lambda x: "True" if ((pd.isnull(x)) | (x == "")) else "False")
    new_claim_data.loc[(new_claim_data['PatientLastName_Invalid'] == "True"), 'Remark'] = new_claim_data[
                                                                                              'Remark'] + ' /PatientLastName is required '
    new_claim_data.drop(["PatientLastName_Invalid"], inplace=True, axis=1)

    new_claim_data['PatientLastName_Invalid'] = new_claim_data['PatientLastName'].apply(
        lambda x: "True" if (pd.notnull(x) & len(x) > 35) else "False")
    new_claim_data.loc[(new_claim_data['PatientLastName_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                              'Remark'] + ' /PatientLastName max length : 35 '
    new_claim_data.drop(["PatientLastName_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientMiddleName
    new_claim_data['PatientMiddleName_Invalid'] = new_claim_data['PatientMiddleName'].apply(
        lambda x: "True" if ((pd.notnull(x)) & (len(x) > 35)) else "False")
    new_claim_data.loc[(new_claim_data['PatientMiddleName_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                'Remark'] + ' /PatientMiddleName max length : 35 '
    new_claim_data.drop(["PatientMiddleName_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientState
    new_claim_data['PatientState_Invalid'] = new_claim_data['PatientState'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 3)) else 'False')
    new_claim_data.loc[(new_claim_data['PatientState_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                           'Remark'] + ' /PatientState max length : 3 '
    new_claim_data.drop(["PatientState_Invalid"], inplace=True, axis=1)

    new_claim_data['PatientState_Invalid'] = new_claim_data['PatientState'].apply(
        lambda x: 'True' if ((pd.isnull(x)) | (x == '')) else 'False')
    new_claim_data.loc[(new_claim_data['PatientState_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                           'Remark'] + ' /PatientState is required '
    new_claim_data.drop(["PatientState_Invalid"], inplace=True, axis=1)

    # Claim details validations - PatientZip
    new_claim_data['PatientZip_Invalid'] = new_claim_data['PatientZip'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 10)) else 'False')
    new_claim_data.loc[(new_claim_data['PatientZip_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                         'Remark'] + ' /PatientZip max length : 10 '
    new_claim_data.drop(["PatientZip_Invalid"], inplace=True, axis=1)

    new_claim_data['PatientZip_Invalid'] = new_claim_data['PatientZip'].apply(
        lambda x: 'True' if ((pd.isnull(x)) | (x == '')) else 'False')
    new_claim_data.loc[(new_claim_data['PatientZip_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                         'Remark'] + ' /PatientZip is required '
    new_claim_data.drop(["PatientZip_Invalid"], inplace=True, axis=1)

    # Claim details validations - PhysicianFirstName
    new_claim_data['PhysicianFirstName_Invalid'] = new_claim_data['PhysicianFirstName'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 35)) else 'False')
    new_claim_data.loc[(new_claim_data['PhysicianFirstName_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /PhysicianFirstName max length :35 '
    new_claim_data.drop(["PhysicianFirstName_Invalid"], inplace=True, axis=1)

    new_claim_data['PhysicianFirstName_Invalid'] = new_claim_data['PhysicianFirstName'].apply(
        lambda x: 'True' if ((pd.isnull(x)) | (x == '')) else 'False')
    new_claim_data.loc[(new_claim_data['PhysicianFirstName_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /PhysicianFirstName is required '
    new_claim_data.drop(["PhysicianFirstName_Invalid"], inplace=True, axis=1)

    # Claim details validations - PhysicianLastName
    new_claim_data['PhysicianLastName_Invalid'] = new_claim_data['PhysicianLastName'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 35)) else 'False')
    new_claim_data.loc[(new_claim_data['PhysicianLastName_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                'Remark'] + ' /PhysicianLastName max length : 35 '
    new_claim_data.drop(["PhysicianLastName_Invalid"], inplace=True, axis=1)

    new_claim_data['PhysicianLastName_Invalid'] = new_claim_data['PhysicianLastName'].apply(
        lambda x: 'True' if ((pd.isnull(x)) | (x == '')) else 'False')
    new_claim_data.loc[(new_claim_data['PhysicianLastName_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                'Remark'] + ' /PhysicianLastName is required '
    new_claim_data.drop(["PhysicianLastName_Invalid"], inplace=True, axis=1)

    # Claim details validations - Accession

    def accession_alphanum_func(x):
        if x is not None and len(x) > 0:
            valid = re.match('^([a-zA-Z0-9-]+\s)*[a-zA-Z0-9-]+$', x) is not None
            if valid:
                return "Valid"

            elif valid is False:
                return "Invalid"

        if x is None or x == "":
            return 'X_None'

    new_claim_data['Accession_Isalnum'] = new_claim_data['Accession'].apply(accession_alphanum_func)
    new_claim_data.loc[(new_claim_data['Accession_Isalnum'] == 'Invalid'), 'Remark'] = new_claim_data[
                                                                                           'Remark'] + '/Invalid Accession '
    new_claim_data.loc[(new_claim_data['Accession_Isalnum'] == 'X_None'), 'Remark'] = new_claim_data[
                                                                                          'Remark'] + '/Accession No Required '
    new_claim_data.drop(["Accession_Isalnum"], inplace=True, axis=1)

    new_claim_data['Accession_Invalid'] = new_claim_data['Accession'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 45)) else 'False')
    new_claim_data.loc[(new_claim_data['Accession_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                        'Remark'] + ' /Accession max length : 45 '
    new_claim_data.drop(["Accession_Invalid"], inplace=True, axis=1)

    new_claim_data['Accession_Invalid'] = new_claim_data['Accession'].apply(
        lambda x: 'True' if ((pd.isnull(x)) | (x == 0)) else 'False')
    new_claim_data.loc[(new_claim_data['Accession_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                        'Remark'] + ' /Accession is required '
    new_claim_data.drop(["Accession_Invalid"], inplace=True, axis=1)

    # Claim details validations - Financial Class Code
    new_claim_data['FinancialClassCode_Invalid'] = new_claim_data['FinancialClassCode'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 45)) else 'False')
    new_claim_data.loc[(new_claim_data['FinancialClassCode_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                 'Remark'] + ' /FinancialClassCode max length : 45 '
    new_claim_data.drop(["FinancialClassCode_Invalid"], inplace=True, axis=1)

    # Claim details validations - ResponsibleFacilityAccountNumber
    new_claim_data['ResponsibleFacilityAccountNumber_Invalid'] = new_claim_data[
        'ResponsibleFacilityAccountNumber'].apply(lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 500)) else 'False')
    new_claim_data.loc[(new_claim_data['ResponsibleFacilityAccountNumber_Invalid'] == 'True'), 'Remark'] = \
        new_claim_data['Remark'] + ' /ResponsibleFacilityAccountNumber max length : 500'

    new_claim_data.drop(["ResponsibleFacilityAccountNumber_Invalid"], inplace=True, axis=1)

    # Claim details validations - RenderingProviderCode
    new_claim_data['RenderingProviderCode_Invalid'] = new_claim_data['RenderingProviderCode'].apply(
        lambda x: 'True' if ((pd.notnull(x)) & (len(x) > 500)) else 'False')
    new_claim_data.loc[(new_claim_data['RenderingProviderCode_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                    'Remark'] + ' /RenderingProviderCode max length : 500 '
    new_claim_data.drop(["RenderingProviderCode_Invalid"], inplace=True, axis=1)

    # Check insurance policy 2 using regex expression
    # This condition checks if only the carrier code2 is not none
    def InsurancePolicy2_validate_func(row):
        if row['CarrierCode2'] is not None and len(row['CarrierCode2']) > 0:
            if row['InsurancePolicy2'] is None or row['InsurancePolicy2'] == '':
                return "policy_None"
            elif row['InsurancePolicy2'] is not None and row['InsurancePolicy2'] != '':
                valid_ins_policy = re.match('^[\w-]+$', row['InsurancePolicy2']) is not None
                if valid_ins_policy is False:
                    return "valid_ins_policy"

    new_claim_data['InsurancePolicy2_Invalid'] = new_claim_data.apply(InsurancePolicy2_validate_func, axis=1)
    new_claim_data.loc[(new_claim_data['InsurancePolicy2_Invalid'] == 'policy_None'), 'Remark'] = new_claim_data[
                                                                                                      'Remark'] + ' /InsurancePolicy2 required. '
    new_claim_data.drop(["InsurancePolicy2_Invalid"], inplace=True, axis=1)

    new_claim_data['InsurancePolicy2_Invalid'] = new_claim_data.apply(InsurancePolicy2_validate_func, axis=1)
    new_claim_data.loc[(new_claim_data['InsurancePolicy2_Invalid'] == 'valid_ins_policy'), 'Remark'] = new_claim_data[
                                                                                                           'Remark'] + ' /Invalid insurancepolicy2. '
    new_claim_data.drop(["InsurancePolicy2_Invalid"], inplace=True, axis=1)

    # Check insurance policy3 using regex expression
    # This condition checks if only the carrier code3 is not none
    def InsurancePolicy3_validate_func(row):
        if row['CarrierCode3'] is not None and len(row['CarrierCode3']) > 0:
            if row['InsurancePolicy3'] is None or row['InsurancePolicy3'] == '':
                return "policy_None"
            elif row['InsurancePolicy3'] is not None and row['InsurancePolicy3'] != '':
                valid_ins_policy = re.match('^[\w-]+$', row['InsurancePolicy3']) is not None
                if valid_ins_policy is False:
                    return "valid_ins_policy"

    new_claim_data['InsurancePolicy3_Invalid'] = new_claim_data.apply(InsurancePolicy3_validate_func, axis=1)
    new_claim_data.loc[(new_claim_data['InsurancePolicy3_Invalid'] == 'policy_None'), 'Remark'] = new_claim_data[
                                                                                                      'Remark'] + ' /InsurancePolicy3 required. '
    new_claim_data.drop(["InsurancePolicy3_Invalid"], inplace=True, axis=1)

    new_claim_data['InsurancePolicy3_Invalid'] = new_claim_data.apply(InsurancePolicy3_validate_func, axis=1)
    new_claim_data.loc[(new_claim_data['InsurancePolicy3_Invalid'] == 'valid_ins_policy'), 'Remark'] = new_claim_data[
                                                                                                           'Remark'] + ' /Invalid insurancePolicy3. '
    new_claim_data.drop(["InsurancePolicy3_Invalid"], inplace=True, axis=1)

    # AMD authorization
    authorization = AMDUser()
    authorization.token = token
    authorization.url = amd_api_login_url

    # Diagnosis code validation
    invalid_dx_codes = get_invalid_dx_codes_unique(data_frame=dx_codes_data, authorization=authorization,
                                                   license_key=license_key)

    # check and remark invalid dx codes in dataframe
    check_invalid_dx_codes_in_df(invalid_dx_codes=invalid_dx_codes, new_claim_data=new_claim_data)

    # Referringprovider code validation
    invalid_ref_codes = get_invalid_referring_provider_code(data_frame=new_claim_data, authorization=authorization)

    new_claim_data['Referringprovider_Invalid'] = new_claim_data['ReferringProviderCode'].apply(
        lambda x: 'True' if (x in invalid_ref_codes) else 'False')
    new_claim_data.loc[(new_claim_data['Referringprovider_Invalid'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                'Remark'] + '/Invalid ' \
                                                                                                            'ReferringProviderCode '
    new_claim_data.drop(['Referringprovider_Invalid'], inplace=True, axis=1)

    if claim_type == "UBO4":
        new_claim_data['PrimaryDXCode_Isalnum'] = new_claim_data['PrimaryDXCode'].apply(
            lambda x: 'True' if ((pd.isnull(x)) | (x == "")) else 'False')
        new_claim_data.loc[(new_claim_data['PrimaryDXCode_Isalnum'] == 'True'), 'Remark'] = new_claim_data[
                                                                                                'Remark'] + ' /PrimaryDXCode Required for UBO4'
        new_claim_data.drop(["PrimaryDXCode_Isalnum"], inplace=True, axis=1)

    # CPT code validation
    for col_name in new_claim_data.columns:
        if 'CPT' in col_name:
            new_claim_data[col_name] = new_claim_data[col_name].apply(lambda x: str(x).replace(".0", ""))
            new_claim_data[col_name] = new_claim_data[col_name].apply(
                lambda x: str(x).replace("-", "") if x == '-' else x)

    invalid_cpt_codes = validate_cpt_code(new_claim_data, authorization)
    invalid_cpt_codes = [cpt for cpt in invalid_cpt_codes if cpt != ""]

    for col in new_claim_data.columns:
        if 'CPT' in col:
            new_claim_data['invalid_cpt'] = new_claim_data[col].apply(
                lambda x: 'True' if (x in invalid_cpt_codes) else 'False')
            new_claim_data.loc[(new_claim_data['invalid_cpt'] == 'True'), 'Remark'] = new_claim_data[
                                                                                          'Remark'] + '/Invalid CPT found : ' + str(
                col)
            new_claim_data.drop(['invalid_cpt'], inplace=True, axis=1)

    # create clean and dirty data frames using remark column
    clean_data = new_claim_data[(new_claim_data['Remark'] == "") | (pd.isnull(new_claim_data['Remark']))]
    dirty_data = new_claim_data[(new_claim_data['Remark'] != "") & (pd.notnull(new_claim_data['Remark']))]

    return clean_data, dirty_data


def deep_clean_file(new_claim_data, token, template_id, license_key, claim_type):
    clean_data, dirty_data = None, None
    is_valid, error = valid_template(new_claim_data)
    if is_valid:
        print('Template Valid')
        logging.info('[{}][Template Valid]'.format(license_key))
        clean_data, dirty_data = deep_clean(new_claim_data, token, template_id, claim_type, license_key)
        return clean_data, dirty_data, None
    else:
        logging.info('[{}][Invalid template found - {}]'.format(license_key, error))
        return clean_data, dirty_data, 'Invalid template found - ' + error
