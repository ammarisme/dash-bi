import os
import sys

from advancedmd.common.api_models.lookup.lookup_diagcode import LookupDiagCode
from advancedmd.common.api_models.lookup.lookup_procode import LookupProcCode
from advancedmd.common.api_models.lookup.lookup_refprovider import LookupRefProvider
import numpy as np
from hrc.common.database import get_redis_connection
from hrc.redis_jobs import AMDUser

from hrc.redis_jobs.common import redis_get_license_key


def validate_dx_code(diagnosis_code, authorization):
    is_None = False
    diag_code = []

    if "|" in diagnosis_code or "," in diagnosis_code:
        if "|" in diagnosis_code:
            arr_diagnosis_code = diagnosis_code.split('|')
        elif "," in diagnosis_code:
            arr_diagnosis_code = diagnosis_code.split(',')

        for dg_code in arr_diagnosis_code:

            try:
                diagcode = dg_code.replace(' ', '')
                req, response, _, diagcodeid = LookupDiagCode.get_lookupid(authorization,
                                                                           LookupDiagCode.get_lookup_payload(
                                                                               code=diagcode), lookup_type="diagcode")

                if diagcodeid is None:
                    is_None = True
                    diag_code.append(diagnosis_code)
                    break
            except:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print(exc_type, fname, exc_tb.tb_lineno)
                print(sys.exc_info())

    else:
        req, response, _, diagcodeid = LookupDiagCode.get_lookupid(authorization,
                                                                   # TODO put this db_charge_detail.diagnosiscides
                                                                   LookupDiagCode.get_lookup_payload(
                                                                       code=diagnosis_code), lookup_type="diagcode")

        if diagcodeid is None:
            is_None = True
            diag_code = [diagnosis_code]

    final_dx_codes = ",".join(diag_code)

    return is_None, final_dx_codes


def get_invalid_dx_codes(data_frame, authorization):
    unique_dx_code = data_frame['DiagnosisCodes'].unique().tolist()

    invalid_dx_code = []
    for dx_code in unique_dx_code:
        is_None, final_dx_codes = validate_dx_code(diagnosis_code=dx_code, authorization=authorization)
        invalid_dx_code.append(final_dx_codes)

    return invalid_dx_code


def validate_referring_provider_code(authorization, referring_provider_code):
    try:
        req, response, _, refprovid = LookupRefProvider.get_lookupid(authorization,
                                                                     LookupRefProvider.get_lookup_payload(
                                                                         code=referring_provider_code),
                                                                     lookup_type="refprovider")
        return refprovid
    except Exception as e:
        return None


def get_invalid_referring_provider_code(data_frame, authorization):
    unique_referringprovider_code = data_frame['ReferringProviderCode'].unique().tolist()

    invalid_referringprovider_code = []
    for ref_code in unique_referringprovider_code:
        final_referringprovider_code = validate_referring_provider_code(authorization=authorization,
                                                                        referring_provider_code=ref_code)

        if final_referringprovider_code is None:
            invalid_referringprovider_code.append(ref_code)

    return invalid_referringprovider_code


def get_unique_cpt_codes(new_claim_data):
    all_cpt_values = []
    for col_name in new_claim_data.columns:
        if 'CPT' in col_name:
            cloumn_values = new_claim_data[col_name].values
            all_cpt_values.extend(cloumn_values)

    unique_cpt_values = np.unique(all_cpt_values)

    return unique_cpt_values


def validate_cpt_code(new_claim_data, authorization):
    uniqe_cpt_codes = get_unique_cpt_codes(new_claim_data)

    invalid_cpt_codes = []
    for uniqe_cpt in uniqe_cpt_codes:
        if uniqe_cpt is not None:
            _, proccode_response, _, proccodeid = LookupProcCode.get_lookupid(authorization,
                                                                              LookupProcCode.get_lookup_payload(
                                                                                  code=uniqe_cpt),
                                                                              lookup_type="proccode")
            if proccodeid is None:
                invalid_cpt_codes.append(uniqe_cpt)

    return invalid_cpt_codes


def get_invalid_dx_codes_unique(data_frame, authorization, license_key):
    unique_dx_code_list = []
    arr_code = []
    invalid_dx_code = []
    try:
        # get unique dx codes from the dataframe
        unique_dx_codes = data_frame

        unique_dx_list = []

        # add dx codes to a list
        for code in unique_dx_codes:
            if "|" in str(code):
                arr_code = str(code).split('|')

                for arr_code_item in arr_code:
                    unique_dx_list.append(str(arr_code_item).strip())

            else:
                unique_dx_list.append(str(code).strip())

        # convert to set and get unique dx codes
        dx_code_set = set(unique_dx_list)
        unique_dx_code_list = list(dx_code_set)
    except:
        print(str(sys.exc_info()))

    # get invalid dx codes using amd api - if dx_code_id is None ==> invalid dx code
    for dx_code in unique_dx_code_list:
        try:
            req, response, _, dx_code_id = LookupDiagCode.get_lookupid(authorization, LookupDiagCode.get_lookup_payload(
                code=dx_code), lookup_type="diagcode")

            if "Error" in response['PPMDResults']['Results']:
                try:
                    re_authorization = re_authorization_amd_login(license_key)
                    req, response, _, dx_code_id = LookupDiagCode.get_lookupid(re_authorization,
                                                                               LookupDiagCode.get_lookup_payload(
                                                                                   code=dx_code),
                                                                               lookup_type="diagcode")
                except:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print(exc_type, fname, exc_tb.tb_lineno)
                    print(sys.exc_info())

            if dx_code_id is None:
                invalid_dx_code.append(dx_code)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            print(sys.exc_info())

    return invalid_dx_code


def check_invalid_dx_codes_in_df(invalid_dx_codes, new_claim_data):
    try:
        # check invalid dx code count
        if len(invalid_dx_codes) > 0 and invalid_dx_codes is not None:

            for index, claim_data in new_claim_data.iterrows():

                dx_codes = [claim_data[col] for col in sorted(
                    [column for column in new_claim_data.columns if 'DX_CODE' in column],
                    key=lambda x: int(x.split('DX_CODE')[1]))]

                dx_codes = [n for n in dx_codes if n != '']
                claim_dx_code = '|'.join(dx_codes)

                if claim_dx_code is None or claim_dx_code == '':
                    continue

                # get claim dx codes if there are more than one
                dx_code_list = []

                if "|" in str(claim_dx_code):
                    dx_code_list = str(claim_dx_code).split('|')

                    # check common values between row dx values and invalid dx codes
                    invalid_dx_codes_as_set = set(invalid_dx_codes)
                    intersection_dx_codes = invalid_dx_codes_as_set.intersection(dx_code_list)

                    if len(intersection_dx_codes) == 0 or intersection_dx_codes is None:
                        continue

                    invalid_dx_codes_str = '|'.join(intersection_dx_codes)
                    new_claim_data.at[index, 'Remark'] = new_claim_data.at[
                                                             index, 'Remark'] + '/Invalid DiagnosisCodes -' + invalid_dx_codes_str
                else:
                    if claim_dx_code in invalid_dx_codes:
                        new_claim_data.at[index, 'Remark'] = new_claim_data.at[
                                                                 index, 'Remark'] + '/Invalid DiagnosisCodes -' + claim_dx_code
    except:
        print(str(sys.exc_info()))


def re_authorization_amd_login(license_key):
    redis_connection = get_redis_connection()
    license_key_dt = redis_get_license_key(connection=redis_connection, license_key=license_key)
    api_username = license_key_dt.api_username
    api_password = license_key_dt.api_password
    api_appname = license_key_dt.api_appname

    authorization = AMDUser()
    authorization.login_to_amd_api(license_key_dt=license_key_dt, api_user=api_username,
                                   api_password=api_password, api_appname=api_appname, force=False,
                                   connection=redis_connection, retry_count=2)

    return authorization
