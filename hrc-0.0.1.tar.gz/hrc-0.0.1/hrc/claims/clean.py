import datetime
import os
import sys
import chardet
import numpy as np
import pandas as pd
from IPython.display import clear_output
from luhn import verify as luhn_verify
from hrc.services import logging_service

logging = logging_service('claims')


def clean(new_claim_data):
    total_count = len(new_claim_data)

    # Removing leading and trailing spaces in fields
    for col in new_claim_data.columns:
        data_type = new_claim_data.dtypes[col]
        if data_type == object:
            new_claim_data[col] = new_claim_data[col].astype(str).str.strip()

        elif col == 'InsurancePolicy1':
            new_claim_data[col] = new_claim_data['InsurancePolicy1'].apply(str)

        elif col == 'InsurancePolicy2':
            new_claim_data[col] = new_claim_data['InsurancePolicy2'].apply(str)

        elif col == 'InsurancePolicy3':
            new_claim_data[col] = new_claim_data['InsurancePolicy3'].apply(str)

    dirty_data_remarks = []
    dirty_data = pd.DataFrame()
    clean_data = pd.DataFrame()

    new_claim_data = new_claim_data.replace(np.nan, '', regex=True)
    for column in new_claim_data.columns:
        if 'date' not in str.lower(column):
            new_claim_data[column] = new_claim_data[column].astype(str)
        else:
            print('Skipping ', column)
            logging.info('[Skipping: {}]'.format(column))

    new_claim_data = new_claim_data.fillna("")
    new_claim_data['PatientGender'] = new_claim_data['PatientGender'].str.upper()
    new_claim_data['PatientGender'] = new_claim_data['PatientGender'].str.strip()
    new_claim_data['PhysicianNPI'] = new_claim_data['PhysicianNPI'].str.upper()
    new_claim_data['PatientFirstName'] = new_claim_data['PatientFirstName'].str.upper()
    new_claim_data['PatientLastName'] = new_claim_data['PatientLastName'].str.upper()
    new_claim_data['PatientMiddleName'] = new_claim_data['PatientMiddleName'].str.upper()
    new_claim_data['PhysicianFirstName'] = new_claim_data['PhysicianFirstName'].str.upper()
    new_claim_data['PhysicianMiddleName'] = new_claim_data['PhysicianMiddleName'].str.upper()
    new_claim_data['PhysicianLastName'] = new_claim_data['PhysicianLastName'].str.upper()
    new_claim_data['DiagnosisCodes'] = new_claim_data['DiagnosisCodes'].str.upper()
    new_claim_data['ReferringProviderCode'] = new_claim_data['ReferringProviderCode'].str.upper()

    new_claim_data.loc[new_claim_data['PatientGender'] == 'FEMALE', 'PatientGender'] = 'F'
    new_claim_data.loc[new_claim_data['PatientGender'] == 'MALE', 'PatientGender'] = 'M'
    # new_claim_data.loc[new_claim_data['PatientGender'].isin(['MALE', 'FEMALE']) == False, 'PatientGender'] = 'U'
    new_claim_data.fillna('')

    for key, claim_data in new_claim_data.iterrows():
        try:
            clear_output(wait=True)
            print(str(round(key * 100 / total_count)) + "%")
            remarks = []
            try:
                dob = datetime.datetime.strptime(claim_data['PatientBirthDate'], '%m/%d/%Y')
                claim_data['PatientBirthDate'] = dob.strftime("%m/%d/%Y")
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                exception = str(exc_type) + ' / ' + str(fname) + ' / ' + str(exc_tb.tb_lineno)
                logging.warning('[Invalid DOB - (Additional info : {})][{}]'.format(exception, e))
                remarks.append("Invalid DOB - (Additional info : " + exception + ' )')

            try:
                service_date = datetime.datetime.strptime(claim_data['Service Date'], '%m/%d/%Y')
                claim_data['Service Date'] = service_date.strftime("%m/%d/%Y")
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                exception = str(exc_type) + ' / ' + str(fname) + ' / ' + str(exc_tb.tb_lineno)
                logging.warning('[Invalid Service Date  - (Additional info : {})][{}]'.format(exception, e))
                remarks.append("Invalid Service Date - (Additional info : " + exception + ' )')

            if claim_data['PatientGender'] not in ["M", "F", "U"]:
                remarks.append("Invalid Patient Gender")

            if not claim_data['CarrierCode1'].replace(' ', '').isalnum():
                remarks.append("Invalid Carrier Code1")

            if len(claim_data['CarrierCode2'].replace(' ', '')) > 0 and \
                    claim_data['CarrierCode2'].replace(' ', '').isalnum() == False:
                remarks.append("Invalid Carrier Code2")

            if len(claim_data['CarrierCode3'].replace(' ', '')) > 0 and \
                    claim_data['CarrierCode3'].replace(' ', '').isalnum() == False:
                remarks.append("Invalid Carrier Code3")

            if claim_data['ReferringProviderCode'].replace(' ', '').isalnum() == False:
                remarks.append("Invalid Referring Provider Code")

            if claim_data['Accession'].isalnum() == False:
                remarks.append("Invalid Serial Number")

            claim_data['PhysicianNPI'] = claim_data['PhysicianNPI'].replace('.0', '')
            if ("E+" in claim_data['ReferringProviderCode'].upper()) or \
                    luhn_verify(str(claim_data['PhysicianNPI'])):
                remarks.append("Invalid Physician NPI")

            if ("E+" in claim_data['InsurancePolicy1'].upper()):
                remarks.append("Invalid InsurancePolicy1")

            if ("E+" in claim_data['InsurancePolicy2'].upper()):
                remarks.append("Invalid InsurancePolicy2")

            if ("E+" in claim_data['InsurancePolicy3'].upper()):
                remarks.append("Invalid InsurancePolicy3")

            if claim_data['CarrierCode1'] is None or len(claim_data['CarrierCode1']) == 0:
                remarks.append('Check the Carrier Code1')

            if claim_data['InsurancePolicy1'] is None or len(claim_data['InsurancePolicy1']) == 0:
                remarks.append('Check the InsurancePolicy1')

            if len(claim_data['PatientZip']) == 4:
                claim_data['PatientZip'] = '0' + claim_data['PatientZip']

            if claim_data['DiagnosisCodes'] is None or len(claim_data['DiagnosisCodes']) > 255:
                remarks.append('Check diagnosis code length')

            if len(claim_data['DiagnosisCodes']) == 0:
                remarks.append('diagnosis code is required')

            if claim_data['InsurancePolicy1'] is None or len(claim_data['InsurancePolicy1']) > 100:
                remarks.append('InsurancePolicy1 max length : 100')

            if claim_data['InsuranceProvider1'] is None or len(claim_data['InsuranceProvider1']) > 100:
                remarks.append('InsuranceProvider1 max length : 100')

            if claim_data['PatientAddress1'] is not None and len(claim_data['PatientAddress1']) > 300:
                remarks.append('PatientAddress1 max length : 300')

            if claim_data['PatientAddress2'] is not None and len(claim_data['PatientAddress2']) > 300:
                remarks.append('PatientAddress2 max length : 300')

            if claim_data['PatientCity'] is not None and len(claim_data['PatientCity']) > 30:
                remarks.append('PatientCity max length : 300')

            if claim_data['PatientFirstName'] is None or len(claim_data['PatientFirstName']) == 0:
                remarks.append('PatientFirstName is required')

            if claim_data['PatientFirstName'] is not None and len(claim_data['PatientFirstName']) > 35:
                remarks.append('PatientFirstName max length : 35')

            if claim_data['PatientLastName'] is None or len(claim_data['PatientLastName']) == 0:
                remarks.append('PatientLastName is required')

            if claim_data['PatientLastName'] is not None and len(claim_data['PatientLastName']) > 35:
                remarks.append('PatientLastName max length : 35')

            if claim_data['PatientMiddleName'] is not None and len(claim_data['PatientMiddleName']) > 35:
                remarks.append('PatientMiddleName max length : 35')

            if claim_data['PatientState'] is not None and len(claim_data['PatientState']) > 3:
                remarks.append('PatientState max length : 3')

            if claim_data['PatientState'] is None or claim_data['PatientState'] == '':
                remarks.append('PatientState is required')

            if claim_data['PatientZip'] is None or claim_data['PatientZip'] == '':
                remarks.append('PatientZip is required')

            if claim_data['PatientZip'] is not None and len(claim_data['PatientZip']) > 10:
                remarks.append('PatientZip max length : 10')

            if claim_data['PhysicianFirstName'] is None or claim_data['PhysicianFirstName'] == '':
                remarks.append('PhysicianFirstName is required')

            if claim_data['PhysicianFirstName'] is not None and len(claim_data['PhysicianFirstName']) > 35:
                remarks.append('PhysicianFirstName max length : 35')

            if claim_data['PhysicianLastName'] is None or claim_data['PhysicianLastName'] == '':
                remarks.append('PhysicianLastName is required')

            if claim_data['PhysicianLastName'] is not None and len(claim_data['PhysicianLastName']) > 35:
                remarks.append('PhysicianFirstName max length : 35')

            if claim_data['ReferringProviderCode'] is not None and len(claim_data['ReferringProviderCode']) > 100:
                remarks.append('ReferringProviderCode max length : 100')

            if claim_data['ReferringProviderCode'] is None or claim_data['PhysicianLastName'] == '':
                remarks.append('ReferringProviderCode is required')

            if claim_data['Accession'] is None or len(claim_data['Accession']) == 0:
                remarks.append('Accession is required')

            if claim_data['Accession'] is not None and len(claim_data['Accession']) > 45:
                remarks.append('Accession max length : 45')

            if claim_data['FinancialClassCode'] is not None and len(claim_data['FinancialClassCode']) > 45:
                remarks.append('FinancialClassCode max length : 45')

            if claim_data['ResponsibleFacilityAccountNumber'] is not None \
                    and len(claim_data['ResponsibleFacilityAccountNumber']) > 500:
                remarks.append('ResponsibleFacilityAccountNumber max length : 500')

            if claim_data['RenderingProviderCode'] is not None \
                    and len(claim_data['RenderingProviderCode']) > 500:
                remarks.append('RenderingProviderCode max length : 500')

            if claim_data['CarrierCode2'] is not None or len(claim_data['CarrierCode2']) > 0:
                if claim_data['InsurancePolicy2'] is None:
                    remarks.append('InsurancePolicy2 required')

            if claim_data['CarrierCode3'] is not None or len(claim_data['CarrierCode3']) > 0:
                if claim_data['InsurancePolicy3'] is None:
                    remarks.append('InsurancePolicy3 required')

            if len(remarks) > 0:
                dirty_data_remarks.append("/".join(remarks))
                dirty_data = dirty_data.append(claim_data)
                continue
            else:
                clean_data = clean_data.append(claim_data)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            error = "Unknown Error : " + str(e) + " - " + str(exc_type) + " - " + str(
                fname) + " - " + 'line :' + " - " + str(exc_tb.tb_lineno)
            logging.error('[Invalid Service Date  - (Additional info : {})]'.format(error))
            dirty_data_remarks.append(error)
            dirty_data = dirty_data.append(claim_data)
    dirty_data = dirty_data.assign(Remarks=dirty_data_remarks)
    dirty_data.fillna("")
    clean_data.fillna("")
    return clean_data, dirty_data


def clean_patient_info(new_claim_data):
    i = 0
    total_count = len(new_claim_data)

    # Removing leading and trailing spaces in fields
    for col in new_claim_data.columns:
        data_type = new_claim_data.dtypes[col]
        if data_type == object:
            new_claim_data[col] = new_claim_data[col].str.strip()
    dirty_data_remarks = []
    dirty_data = pd.DataFrame()
    clean_data = pd.DataFrame()

    new_claim_data = new_claim_data.replace(np.nan, '', regex=True)
    for column in new_claim_data.columns:
        if 'date' not in str.lower(column):
            new_claim_data[column] = new_claim_data[column].astype(str)
        else:
            logging.warning('[Skipping : {}]'.format(column))
            print('Skipping ', column)

    new_claim_data = new_claim_data.fillna("")
    new_claim_data['PatientGender'] = new_claim_data['PatientGender'].str.upper()
    new_claim_data['PatientFirstName'] = new_claim_data['PatientFirstName'].str.upper()
    new_claim_data['PatientLastName'] = new_claim_data['PatientLastName'].str.upper()
    new_claim_data['PatientMiddleName'] = new_claim_data['PatientMiddleName'].str.upper()
    new_claim_data.loc[new_claim_data['PatientGender'] == 'FEMALE', 'PatientGender'] = 'F'
    new_claim_data.loc[new_claim_data['PatientGender'] == 'MALE', 'PatientGender'] = 'M'
    new_claim_data.loc[new_claim_data['PatientGender'] == 'Unknown', 'PatientGender'] = 'U'
    new_claim_data.fillna('')

    for key, claim_data in new_claim_data.iterrows():
        try:
            clear_output(wait=True)
            print(str(round(key * 100 / total_count)) + "%")
            remarks = []
            try:
                dob = datetime.datetime.strptime(claim_data['PatientBirthDate'], '%m/%d/%Y')
                claim_data['PatientBirthDate'] = dob.strftime("%m/%d/%Y")
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                exception = str(exc_type) + ' / ' + str(fname) + ' / ' + str(exc_tb.tb_lineno)
                logging.warning('[Invalid DOB - (Additional info :  {})][{}]'.format(exception, e))
                remarks.append("Invalid DOB - (Additional info : " + exception + ' )')

            if not claim_data['Accession'].isalnum():
                remarks.append("Invalid Serial Number")

            if claim_data['PatientAddress1'] is not None and len(claim_data['PatientAddress1']) > 300:
                remarks.append('PatientAddress1 max length : 300')

            if claim_data['PatientAddress2'] is not None and len(claim_data['PatientAddress2']) > 300:
                remarks.append('PatientAddress2 max length : 300')

            if claim_data['PatientCity'] is not None and len(claim_data['PatientCity']) > 30:
                remarks.append('PatientCity max length : 300')

            if claim_data['PatientFirstName'] is not None and len(claim_data['PatientFirstName']) > 35:
                remarks.append('PatientFirstName max length : 35')

            if claim_data['PatientLastName'] is not None and len(claim_data['PatientLastName']) > 35:
                remarks.append('PatientLastName max length : 35')

            if claim_data['PatientMiddleName'] is not None and len(claim_data['PatientMiddleName']) > 35:
                remarks.append('PatientMiddleName max length : 35')

            if claim_data['PatientState'] is not None and len(claim_data['PatientState']) > 3:
                remarks.append('PatientState max length : 3')

            if claim_data['PatientState'] is None or claim_data['PatientState'] == '':
                remarks.append('PatientState is required')

            if claim_data['PatientZip'] is None or claim_data['PatientZip'] == '':
                remarks.append('PatientZip is required')

            if claim_data['PatientZip'] is not None and len(claim_data['PatientZip']) > 10:
                remarks.append('PatientZip max length : 10')

            if claim_data['Accession'] is not None and len(claim_data['Accession']) > 45:
                remarks.append('Accession max length : 45')

            if len(remarks) > 0:
                dirty_data_remarks.append("/".join(remarks))
                dirty_data = dirty_data.append(claim_data)
                continue
            else:
                clean_data = clean_data.append(claim_data)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            error = "Unknown Error : " + str(e) + " - " + str(exc_type) + " - " + str(
                fname) + " - " + 'line :' + " - " + str(exc_tb.tb_lineno)
            logging.warning('[Invalid DOB - (Additional info :  {})]'.format(error))
            dirty_data_remarks.append(error)
            dirty_data = dirty_data.append(claim_data)
    dirty_data = dirty_data.assign(Remarks=dirty_data_remarks)
    dirty_data.fillna("")
    clean_data.fillna("")
    return clean_data, dirty_data


def predict_encoding(file_path, n_lines=20):
    '''Predict a file's encoding using chardet'''

    # Open the file as binary data
    with open(file_path, 'rb') as f:
        # Join binary lines for specified number of lines
        rawdata = b''.join([f.readline() for _ in range(n_lines)])
    encoding = chardet.detect(rawdata)['encoding']
    print(encoding)
    return encoding


def valid_template(new_claim_data):
    template_file = './template_23_07.csv'

    old_claim_data = pd.read_csv(template_file)
    new_fields = [n for n in new_claim_data if n not in old_claim_data.columns]
    missing_fields = [o for o in old_claim_data if o not in new_claim_data.columns]
    print("New fields : ", new_fields)
    print("Missing fields : ", missing_fields)
    print("Total new records : ", len(new_claim_data))

    return len(new_fields) == 0 and len(missing_fields) == 0, 'Unknown columns : ' + ' , '.join(new_fields) + \
           ' / Missing columns : ' + ' , '.join(missing_fields)


def clean_file(new_claim_data):
    clean_data, dirty_data = None, None
    is_valid, error = valid_template(new_claim_data)
    if is_valid:
        print('Template Valid')
        logging.info('[Template Valid]')
        clean_data, dirty_data = clean(new_claim_data)
        return clean_data, dirty_data, None
    else:
        logging.info('[Invalid template found - {}]'.format(error))
        return clean_data, dirty_data, 'Invalid template found - ' + error
