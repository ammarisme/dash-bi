import datetime
import os
import sys

from hrc.common.time import get_current_time
from sqlalchemy import and_
from sqlalchemy.orm import Session
from sqlalchemy.sql.expression import func

from advancedmd.charge.api_models.charge_entry.updvisitwithnewcharges import CustomClaimField
from advancedmd.charge.controllers.charge_entry.charge_entry import addvisit, update_visit_with_new_charges, \
    update_extra_ins_info
from advancedmd.common.api_models.lookup.lookup_carrier import LookupCarrier
from advancedmd.common.api_models.lookup.lookup_diagcode import LookupDiagCode
from advancedmd.common.api_models.lookup.lookup_facility import LookupFacility
from advancedmd.common.api_models.lookup.lookup_finclass import LookupFinClass
from advancedmd.common.api_models.lookup.lookup_modcode import LookupModcode
from advancedmd.common.api_models.lookup.lookup_patient import LookupPatient
from advancedmd.common.api_models.lookup.lookup_procode import LookupProcCode
from advancedmd.common.api_models.lookup.lookup_profile import LookupProfile
from advancedmd.common.api_models.lookup.lookup_refprovider import LookupRefProvider
from advancedmd.common.user import AMDUser
from advancedmd.demographics.api_models.add_insurance import InsPlan
from advancedmd.demographics.controllers.demographics.demorgaphic import get_demographic, get_chargeentry_data_icd10
from advancedmd.demographics.controllers.insurance import add_insurance_plan, submit_demand_request, check_eligibility
from advancedmd.demographics.controllers.patient import add_patient
from advancedmd.demographics.controllers.referral_plan import add_referral_plan
from advancedmd.license_key import get_license_key_dt
from hrc.common.database import get_mysql_connection, get_mongo_connection
from hrc.common.user import get_api_user
from hrc.integration_db.models import ActvChargedetail, IClaim, \
    IJob, PtPatientinfoDummy, PtReferralplan, MfFacility, IProcessing
from hrc.template import get_template

http_method_names = ['get', 'post', 'put', 'delete', 'head', 'options', 'trace']

defaults = {
    'ssn': 'XXX-XXX-999'
}

ERROR_CODES = {
    'AMD': {
        'GENERAL': 20,
        'NO_CARRIER': 201,
        'PECOS': 202
    },
    'PLATFORM': {
        'GENERAL': 30,
        'STRFTIME': 100,
        'NONETYPE': 101,
        'ATTRIBUTE_ERROR': 102
    }
}


def create_claim(input_claim, jobid, claimid, process_id, license_key,
                 template_id, fclass_code, status=0, cpts_created=None):
    current_time = get_current_time()
    claim = IClaim(
        claimid=claimid,
        Job_id=jobid,
        IntegrationStatus=status,
        SerialNumber=input_claim['SerialNumber'],
        ProcessId=process_id,
        LicenseKey=license_key,
        template_id=template_id,
        financial_class_code=fclass_code,
        created_dt=current_time,
        cpts_created=cpts_created
    )

    return claim


def create_cpt(input_claim, jobid, claimid, process_id, license_key, template_id, fclass_code, status=0,
               cpts_created=None):
    current_time = get_current_time()
    claim = IClaim(
        claimid=claimid,
        Job_id=jobid,
        IntegrationStatus=status,
        SerialNumber=input_claim['SerialNumber'],
        ProcessId=process_id,
        LicenseKey=license_key,
        template_id=template_id,
        financial_class_code=fclass_code,
        created_dt=current_time,
        cpts_created=cpts_created
    )

    return claim


def create_patient_info(input_claim, claim, license_key):
    print(input_claim['PatientBirthDate'])
    dob = datetime.datetime.strptime(input_claim['PatientBirthDate'],
                                     '%m/%d/%Y').strftime('%Y-%m-%d')
    ref_providercode = input_claim['ReferringProviderCode']
    ref_provider_npi = input_claim['PhysicianNPI']
    rendering_providercode = 'ADPRV'  # resolve_provider_code('ADPRV')

    patient = PtPatientinfoDummy(
        LicenseKey=license_key,
        ClaimId=claim.claimid,
        SerialNumber=input_claim['SerialNumber'],
        FirstName=input_claim['PatientFirstName'],
        MiddleName=input_claim['PatientMiddleName'],
        LastName=input_claim['PatientLastName'],
        DOB=dob,
        SSN=defaults['ssn'],
        Gender=input_claim['PatientGender'],
        Address1=input_claim['PatientAddress1'],
        Address2=input_claim['PatientAddress2'],
        City=input_claim['PatientCity'],
        State=input_claim['PatientState'],
        ZipCode=input_claim['PatientZip'],
        HomePhone=input_claim['PatientPhone'],
        Email=input_claim['PatientEmail'],
        InsuranceProvider1=input_claim['InsuranceProvider1'],
        InsurancePolicy1=input_claim['InsurancePolicy1'],
        PrimaryReferringProvider=ref_providercode,
        PrimaryRenderingProvider=rendering_providercode,
        referring_provider_npi=ref_provider_npi,
        CarrierCode1=input_claim['CarrierCode'],
        IntegrationStatus=0
    )
    return patient


def create_facility(input_claim, claim, license_key):
    facility = MfFacility(
        LicenseKey=license_key,
        ClaimId=claim.claimid,
        FacilityName=input_claim['FacilityName'],
        IntegrationStatus=0
    )
    return facility


def create_referral_plan(input_claim, claim, license_key):
    referral_plan = PtReferralplan(
        LicenseKey=license_key,
        ClaimId=claim.claimid,
        DiagnosisCodes=input_claim['DiagnosisCodes'],
        Refprov=input_claim['ReferringProviderCode'],
        IntegrationStatus=0
    )
    return referral_plan


def create_charge_detail(input_claim, claim, license_key):
    if input_claim['Service Date'] != '':
        begin_dt = datetime.datetime.strptime(input_claim['Service Date'], '%m/%d/%Y').strftime('%Y-%m-%d')
        charge = ActvChargedetail(
            LicenseKey=license_key,
            ClaimId=claim.claimid,
            DiagnosisCodes=input_claim['DiagnosisCodes'],
            BeginDateOfService=begin_dt,
            IntegrationStatus=0
        )
    else:
        print("Service data doesn't exist")
        raise Exception("Service date doesn't exist")

    return charge


def upload_claims_csv(license_key, template_id, process_id, token, input_claims_df, engine):
    # Insert all claims to database
    patient_infos = []
    facilities = []
    charge_details = []
    referral_plans = []
    all_claims_df = input_claims_df.fillna('')

    template = get_template(engine, template_id=template_id)
    fclass_code = template['FCLASS'] if ('FCLASS' in template) else None

    if fclass_code is None:
        print('Financial class not configured for the template.')
        return False

    serials = tuple(list(all_claims_df['SerialNumber']))
    try:
        session = Session(autocommit=True, bind=engine)
        with session.begin():
            existing_claims = session.query(IClaim).filter(
                and_(
                    IClaim.SerialNumber.in_(serials),
                    IClaim.LicenseKey == license_key,
                    IClaim.IntegrationStatus.between(0, 3999))).all()
    except:
        unlock_tables(engine)
        print(str(sys.exc_info()))
        return 1

    existing_serial_numbes = [c.SerialNumber for c in existing_claims]
    old_claims_df = all_claims_df[input_claims_df['SerialNumber'].isin(existing_serial_numbes)]
    input_claims_df = all_claims_df[input_claims_df['SerialNumber'].isin(existing_serial_numbes) == False]

    print('all claims :', len(all_claims_df), 'new claims :', len(input_claims_df), 'old claims :',
          len(old_claims_df))

    if len(input_claims_df) == 0:
        return 1

    try:
        session = Session(autocommit=True, bind=engine)
        with session.begin():
            maxjobid = session.query(func.max(IJob.jobid)).scalar()
            maxjobid = maxjobid + 1
    except:
        print(str(sys.exc_info()))
        return 1

    job = IJob(
        LicenseKey=license_key,
        jobid=maxjobid,
        IntegrationStatus=0,
        ProcessId=process_id,
        ParentJob=0
    )

    errors = []
    lock_tables(engine)
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        claimid = session.query(func.max(IClaim.claimid)).scalar()

    iclaims = []
    for index, input_claim in input_claims_df.iterrows():
        claimid += 1
        print('Creating ', input_claim['Accession'], " Claim id : ", claimid)
        claim = create_claim(
            input_claim=input_claim, jobid=job.jobid,
            claimid=claimid, process_id=process_id, license_key=license_key,
            template_id=template_id,
            fclass_code=fclass_code,

        )
        iclaims.append(claim)
        try:
            patient = create_patient_info(input_claim, claim, license_key=license_key)
            facility = create_facility(input_claim, claim, license_key=license_key)
            referral_plan = create_referral_plan(input_claim, claim, license_key=license_key)
            charge_detail = create_charge_detail(input_claim, claim, license_key=license_key)

            if patient is not None:
                patient_infos.append(patient)
                facilities.append(facility)
                referral_plans.append(referral_plan)
                charge_details.append(charge_detail)
            else:
                errors.append((input_claim['Accession'], "Didn't create patient"))
        except:
            pass

            errors.append((input_claim['Accession'], sys.exc_info()))
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)

    # insert to all tables in bulk
    try:
        if len(patient_infos) > 0:
            claim_data = []
            claim_data.append(patient_infos)
            claim_data.append(facilities)
            claim_data.append(referral_plans)
            claim_data.append(charge_details)

            session = Session(bind=engine, autocommit=True)
            with session.begin(subtransactions=True):
                session.add(job)
                session.add_all(iclaims)
                session.add_all(patient_infos)
                session.add_all(facilities)
                session.add_all(referral_plans)
                session.add_all(charge_details)
                print('============================================')
                print('Claims Created')
            unlock_tables(engine)
            return 0
        else:
            unlock_tables(engine)
        print('Errors : ', errors)
    except:
        print("Unexpected error:", sys.exc_info())
        unlock_tables(engine)
        return 1


def get_charges(authorization,
                chargeschedid, allowschedid, dos,
                proccode_id, proccode_code, proccode_name, proccode_units, proccode_pos, proccode_tos
                ):
    pass
    #
    # fees = get_fees(authorization,
    #          chargeschedid, allowschedid, dos,
    #          proccode_id, proccode_code, proccode_name, proccode_units, proccode_pos, proccode_tos
    #          ):
    # code = "COV"
    # name = "COVID-19"
    # units = "1.0"
    # ndccode = ""
    # ndcquantity = ""
    # ndcmeasure = ""
    # ndcmeasurefid = ""
    # ndcprice = ""
    # pos = "11"
    # tos = "01"


def process_uniform_job(license_key, authorization, job_id, facility_name=None, fclass_code=None, modcode=None,
                        proccode=None):
    engine = get_mysql_connection()
    db = get_mongo_connection()
    http_req_res_mongo = db.http_req_res

    statuses = {30: 'rerun', 20: 'amd-rejected', 0: 'unprocessed', 10: 'reprocess'}
    current_status = 0
    print("Job running on ", statuses[current_status], ' Mode')
    print("Job id :  ", job_id)
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        db_job = session.query(IJob).filter(IJob.jobid == job_id).first()
        if db_job is None:
            print('Response : No jobs found')
            return 1
        db_claims = session.query(IClaim).filter(IClaim.Job_id == job_id).filter(and_(
            IClaim.IntegrationStatus.notin_((40, 10)), IClaim.LicenseKey == license_key
        )).all()

    # excluding alerady sent, deleted and sent back to accounts claims
    # db_claims = IClaim.objects.filter(Job=db_job).exclude(integration_status__in=[10, 40, 50])

    if db_claims is None or len(db_claims) == 0:
        print('Response : No claims found')
        return 1

    claim_ids = tuple([claim.claimid for claim in db_claims])
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        db_patients = session.query(PtPatientinfoDummy).filter(
            and_(
                PtPatientinfoDummy.ClaimId.in_(claim_ids),
                PtPatientinfoDummy.LicenseKey == license_key
            )).all()
        db_charge_details = session.query(ActvChargedetail).filter(
            and_(
                ActvChargedetail.ClaimId.in_(claim_ids),
                ActvChargedetail.LicenseKey == license_key
            )
        ).all()
        db_facilities = session.query(MfFacility).filter(
            and_(
                MfFacility.ClaimId.in_(claim_ids),
                MfFacility.LicenseKey == license_key
            )).all()
        db_refplans = session.query(PtReferralplan).filter(
            and_(
                PtReferralplan.ClaimId.in_(claim_ids),
                PtReferralplan.LicenseKey == license_key
            )
        ).all()

    if facility_name is None:
        return False, 'facility_name is none'

    if fclass_code is None:
        return False, 'fclass_code is none'

    if modcode is None:
        return False, 'modcode is none'

    if proccode is None:
        return False, 'proccode is none'

    _, _, _, proccodeid = LookupProcCode.get_lookupid(authorization,
                                                      LookupProcCode.get_lookup_payload(
                                                          code=proccode),
                                                      lookup_type="proccode")
    _, _, _, modcodeid = LookupModcode.get_lookupid(authorization,  # TODO db_charge_detail.modcode
                                                    LookupModcode.get_lookup_payload(
                                                        code=modcode), lookup_type="modcode")
    _, _, _, facilityid = LookupFacility.get_lookupid(authorization,
                                                      LookupFacility.get_lookup_payload(
                                                          name=facility_name
                                                      ), lookup_type="facility")
    _, _, _, fclassid = LookupFinClass.get_lookupid(authorization,
                                                    LookupFinClass.get_lookup_payload(code=fclass_code),
                                                    lookup_type="finclass")

    if proccodeid is None:
        print('Procedure code provider missing in AMD')
        return False

    if modcodeid is None:
        print('Mod code doesnt exist in AMD')
        return False

    if facilityid is None:
        print('Faciltiy doesnt exist in AMD ', facility_name)
        return False

    if fclassid is None:
        print("Financial class doesn't exist")
        return None

    for db_claim in db_claims:
        try:
            db_patient = [p for p in db_patients if p.ClaimId == db_claim.claimid][0]
            db_charge_detail = [c for c in db_charge_details if c.ClaimId == db_claim.claimid][0]
            db_facility = [f for f in db_facilities if f.ClaimId == db_claim.claimid][0]
            db_refplan = [r for r in db_refplans if r.ClaimId == db_claim.claimid][0]

            # if ("|" in db_charge_detail.diagnosiscodes):
            #     print("Multiple diag codes")
            #     continue
            processed, error = process_claim(authorization=authorization,
                                             db_claim=db_claim, db_patient=db_patient,
                                             db_charge_detail=db_charge_detail,
                                             db_facility=db_facility, db_refplan=db_refplan,
                                             proccodeid=proccodeid, modcodeid=modcodeid, facilityid=facilityid,
                                             fclassid=fclassid,
                                             http_req_res_mongo=http_req_res_mongo
                                             )
            if processed:
                session = Session(autocommit=True, bind=engine)
                with session.begin():
                    claim = session.query(IClaim).filter(IClaim.claimid == db_claim.claimid).first()
                    claim.IntegrationStatus = 1000
                    # session.commit()
                print('Claim in AMD', db_claim.SerialNumber)
            else:
                session = Session(autocommit=True, bind=engine)
                with session.begin():
                    claim = session.query(IClaim).filter(IClaim.claimid == db_claim.claimid).first()
                    if 'carrier 1, 2 and 3 are None' in error:
                        claim.IntegrationStatus = ERROR_CODES['AMD']['NO_CARRIER']
                    elif 'PECOS' in error:
                        claim.IntegrationStatus = ERROR_CODES['AMD']['PECOS']
                    else:
                        claim.IntegrationStatus = ERROR_CODES['AMD']['GENERAL']
                print(error)
                print('Claim insertion failed :', claim.SerialNumber)
            # break
        except:
            error = str(sys.exc_info())
            print('Claim insertion failed :', db_claim.SerialNumber)


def process_claim(authorization, db_claim, db_patient, db_charge_detail, db_facility, db_refplan, http_req_res_mongo,
                  proccodeid=None, modcodeid=None, facilityid=None, fclassid=None, patientid=None, refprovid=None,
                  diagcodeid=None, charges=[]):
    print('processing claim :', db_claim.claimid)
    claim_log = {}
    count = 0

    icd_10_code = db_charge_detail.DiagnosisCodes  # TODO take from db
    begindate = db_charge_detail.BeginDateOfService.strftime(
        "%m/%d/%Y")  # "07/11/2020"  # TODO db_charge_detail.begindateofservice
    insurance_plan_begin_date = "01/01/2020"
    enddate = begindate  # TODO db_charge_detail.begindateofservice
    visitdate = begindate  # TODO db_charge_detail.begindateofservice
    referral_reason = ""

    if db_patient is None:
        print('Response : No patient found found, claim : ', db_claim.claimid)
        return False, 'No Patient in localdb'
    if db_charge_detail is None:
        print('Response : No charge detail found, claim : ', db_claim.claimid)
        return False, 'No charge detail in localdb'
    if db_facility is None:
        print('Response : No facility found found, claim : ', db_claim.claimid)
        return False, 'No facility in localdb'
    if db_refplan is None:
        print('Response : No refplan found found, claim : ', db_claim.claimid)
        return False, 'No refplan in localdb'

    if db_patient.PrimaryReferringProvider == 'PECOS NOT ENTROLLED':
        return False, 'PECOS NOT ENTROLLED'

    if refprovid is None:
        req, response, _, refprovid = LookupRefProvider.get_lookupid(authorization,
                                                                     LookupRefProvider.get_lookup_payload(
                                                                         code=db_patient.PrimaryReferringProvider),
                                                                     lookup_type="refprovider")
        count += 1
        claim_log[str(count)] = {'request': req, 'response': response}

    diagcodeids = None
    if "|" in icd_10_code:
        print("multiple diag codes")
        diagcodes = icd_10_code.split('|')
        diagcodeids = []
        for diagcode in diagcodes:
            try:
                req, response, _, diagcodeid = LookupDiagCode.get_lookupid(authorization,
                                                                           # TODO put this db_charge_detail.diagnosiscides
                                                                           LookupDiagCode.get_lookup_payload(
                                                                               code=diagcode), lookup_type="diagcode")
                diagcodeids.append(diagcodeid)
            except:
                pass
            count += 1
            claim_log[str(count)] = {'request': req, 'response': response}
        if len(diagcodeids) == 0:
            print("Couldn't lookup any diagnosis code. Check if they exist", db_claim.claimid)
            return False, ("Couldn't lookup any diagnosis code. Check if they exist" + str(db_claim.claimid))
        diagcodeids = " ".join(diagcodeids)
    else:
        print("only one diag code")
        req, response, _, diagcodeid = LookupDiagCode.get_lookupid(authorization,
                                                                   # TODO put this db_charge_detail.diagnosiscides
                                                                   LookupDiagCode.get_lookup_payload(
                                                                       code=icd_10_code), lookup_type="diagcode")
        diagcodeids = diagcodeid

    if refprovid is None:
        print('Referring provider missing in AMD')
        return False, "Refprov missing AMD"

    if diagcodeids is None:
        print('Diagnosis code doesnt exist in AMD', icd_10_code)
        return False, "Digcode missing AMD"

    req, response, _, patientid = LookupPatient.get_lookupid(authorization,
                                                             LookupPatient.get_lookup_payload(
                                                                 dob=db_patient.DOB.strftime("%m/%d/%Y"),
                                                                 exact="1",
                                                                 name=db_patient.LastName + ',' + db_patient.FirstName),
                                                             lookup_type="patient")
    count += 1
    claim_log[str(count)] = {'request': req, 'response': response}

    if patientid is None:
        address2 = db_patient.Address1 if (
                db_patient.Address2 == None or db_patient.Address2 == '') else db_patient.Address2
        address1 = '' if (
                address2 == db_patient.Address1) else db_patient.Address1

        print('Adding the patient to AMD')

        lookupprofile = LookupProfile()
        request, response, profileid = lookupprofile.get_lookupid(authorization, lookupprofile.get_lookup_payload(
            dob=db_patient.DOB.strftime("%m/%d/%Y"), exactmatch="1",
            name=db_patient.LastName + ',' + db_patient.FirstName), lookup_type="profile")

        count += 1
        claim_log[str(count)] = {'request': req, 'response': response}

        if profileid is None:
            print("Profile doesn't exist")
            return request, None, None

        request, response, patientid = add_patient(
            authorization, name=db_patient.LastName + ',' + db_patient.FirstName,
            dob=db_patient.DOB.strftime("%m/%d/%Y"),
            gender=db_patient.Gender, relationship="1",
            chart="AUTO", hipaarelationship="18", city=db_patient.City,
            state=db_patient.State, zip=db_patient.ZipCode, address1=address1,
            address2=address2, homephone=db_patient.HomePhone, officephone=db_patient.OfficePhone,
            email=db_patient.Email, insorder="", employer="",
            maritalstatus="1", ssn="", fclassid=fclassid, profileid=profileid
        )
        count += 1
        claim_log[str(count)] = {'request': request, 'response': response}
        if patientid is None:
            print('Unable to create the patient')
            return False, "Patient creation failed"

    # eligibility start
    req, response, demographic_infomation = get_demographic(patientid=patientid, authorization=authorization)
    count += 1
    claim_log[str(count)] = {'request': req, 'response': response}

    patientid_num = patientid.replace("pat", "")
    coverage = "1"
    current_insplan = None
    insuranceid = None
    default_carrier = None
    default_insuranceid = None
    already_eligible = False

    if type(demographic_infomation["patientlist"]["patient"]["insplanlist"]) == dict:
        if type(demographic_infomation["patientlist"]["patient"]["insplanlist"]["insplan"]) != list:
            print("there exist one insurance plan already")
            current_insplan = demographic_infomation["patientlist"]["patient"]["insplanlist"]["insplan"]
            insuranceid = current_insplan["@id"].replace("ins", "")
            already_eligible, demoreq, demores, elgibilityreq, eligibilityres = check_insurance_eligibility(
                authorization=authorization,
                insuranceid=insuranceid,
                patientid_num=patientid_num)
            if already_eligible:
                default_carrier = current_insplan["@carrier"]
                default_insuranceid = insuranceid
                print("the insurance plan is eligible")
            else:
                print("the insurance plan is not elgibile, will check the new ones")
        else:
            for current_insplan in demographic_infomation["patientlist"]["patient"]["insplanlist"]["insplan"]:
                print("there exist more than one insurance plans already")
                insuranceid = current_insplan["@id"].replace("ins", "")
                already_eligible, demoreq, demores, elgibilityreq, eligibilityres = check_insurance_eligibility(
                    authorization=authorization,
                    insuranceid=insuranceid,
                    patientid_num=patientid_num)
                if already_eligible:
                    default_carrier = current_insplan["@carrier"]
                    default_insuranceid = insuranceid
                    print("the insurance plan is eligible")
                    break
                else:
                    print("the insurance plan is not elgibile, checking if there are more")

            if already_eligible == False:
                print("No plan is eligible. We have to check with the new one given")
    # eligibility over

    if 'patientlist' not in demographic_infomation:
        print('Responsible party not in demographics', db_claim.SerialNumber)
        return False, "Resp party not in demographics"

    responsible_party = demographic_infomation['patientlist']['patient']['@respparty']

    # transaction_info = add_responsible_party(transaction_info) #TODO Not for SELF

    respparty1, respparty2, respparty3 = responsible_party, responsible_party, responsible_party
    insplans = []
    carriercode1 = "" if db_patient.CarrierCode1 == None else db_patient.CarrierCode1
    subnum1 = "" if db_patient.InsurancePolicy1 == None else db_patient.InsurancePolicy1
    carrierid1 = None
    if carriercode1 != "" and subnum1 != "":
        insplan, claim_log, carrierid1 = add_insurance(count, claim_log, authorization, carriercode1, subnum1,
                                                       respparty1,
                                                       insurance_plan_begin_date, already_eligible=already_eligible)
        insplans.append(insplan)

    if default_carrier is None and carrierid1 is None:
        error = "Existing plan is inelgible / New carrier doesn't exist :" + db_patient.CarrierCode1
        print(error)
        return False, error

    request, response_add_insurance_plan = add_insurance_plan(authorization=authorization,
                                                              patientid=patientid,
                                                              insplans=insplans)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response_add_insurance_plan}

    # run eligibility anyway to the new one
    insuranceid = response_add_insurance_plan["PPMDResults"]["Results"]["patient"]["@id"].replace("ins", "")
    new_eligible, demoreq, demores, elgibilityreq, eligibilityres = check_insurance_eligibility(
        authorization, patientid_num, insuranceid)
    if already_eligible == False and new_eligible == False:
        print("Both old and new insurance plans are ineligible. But continueing to create the visit.")
    elif already_eligible:
        print("Using the old eligible insurance.")
    else:
        print("Using the new eligible insurance.")

    request, response, demographic_infomation = get_demographic(patientid=patientid, authorization=authorization)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    request, response, chargeentry_data_icd10 = get_chargeentry_data_icd10(patientid=patientid,
                                                                           authorization=authorization)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    responsible_party = demographic_infomation['patientlist']['patient']['@respparty']
    profile = demographic_infomation['patientlist']['patient']['@profile']

    request, response, response_addvisit = addvisit(authorization, patientid, profile, begindate)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    visitid = response_addvisit["visit"]["@id"]
    visitsequence = visitid.replace("vst", "000")

    if type(chargeentry_data_icd10['patientlist']['patient']['episodelist']['episode']) is list:
        episode = chargeentry_data_icd10['patientlist']['patient']['episodelist']['episode'][0]['@id']
    else:
        episode = chargeentry_data_icd10['patientlist']['patient']['episodelist']['episode']['@id']

    req, response, refplan = add_referral_plan(authorization=authorization,
                                               proccode=proccodeid, refprov=refprovid,
                                               facility=facilityid, patientid=patientid,
                                               begindate=begindate, reason=referral_reason,
                                               diagcodes=diagcodeids
                                               )
    count += 1
    claim_log[str(count)] = {'request': req, 'response': response}

    request, response, extins_id = update_extra_ins_info(visitid, authorization)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    custom_claim_fields = []
    accession_field = CustomClaimField("4188", db_claim.SerialNumber)
    # eligibility_field = CustomClaimField("4366", "PASS")

    custom_claim_fields.append(accession_field)
    # custom_claim_fields.append(eligibility_field)

    request, response, success, batchid, charge_id = update_visit_with_new_charges(
        authorization=authorization,
        patientid=patientid,
        charge_begindate=begindate,
        charge_enddate=enddate,
        charge_aging=begindate,
        visit_profile=profile,
        visit_date=visitdate,
        visit_refplan=refplan,
        visit_episode=episode,
        charge_proccode=proccodeid,
        charge_respparty=responsible_party,
        episodeid=episode,
        charge_diagcodes=diagcodeids,
        charge_modcodes=modcodeid,
        extins_id=extins_id,
        visit_id=visitid,
        visit_sequence=visitsequence,
        custom_claim_fields=custom_claim_fields,
        note=db_claim.SerialNumber,
        batchid="",
        charge_id="",
        approval="1" if (already_eligible or new_eligible) else "0"
    )
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    # Eligibility trigger
    count += 1
    claim_log[str(count)] = {'request': demoreq, 'response': demores}
    count += 1
    claim_log[str(count)] = {'request': elgibilityreq, 'response': eligibilityres}

    claim_log['ClaimId'] = db_claim.claimid
    claim_log['SerialNumber'] = db_claim.SerialNumber
    claim_log['VisitSeq'] = visitsequence
    claim_log['Old_plan_Eligible'] = already_eligible
    claim_log['New_plan_Eligible'] = new_eligible
    result_object = http_req_res_mongo.insert_one(claim_log)
    return success, str(response)

    # transaction_info = update_visit_with_new_charges(transaction_info)
    # transaction_info = save_charges(transaction_info)


def add_insurance(count, claim_log, authorization, carriercode, subnum1, respparty1, insurance_plan_begin_date,
                  already_eligible=False):
    req, response, _, carrierid1 = LookupCarrier.get_lookupid(authorization=authorization,
                                                              lookuppayload=LookupCarrier.get_lookup_payload(
                                                                  code=carriercode, exactmatch="1"
                                                              ),
                                                              lookup_type="carrier")
    count += 1
    claim_log[str(count)] = {'request': req, 'response': response}
    coverage = "2" if already_eligible else "1"
    mspcode = "47" if (coverage == "2" and carriercode == 'TEX03') else ""
    if mspcode == "47":
        print("MSP code changed")
    insplan = InsPlan(
        carrierid=carrierid1,
        subscribernum=subnum1,
        subscriber=respparty1,
        begindate=insurance_plan_begin_date,
        enddate="",
        coverage=coverage,
        hipaarelationship="18", relationship="1",
        mspcode=mspcode
    )
    return insplan, claim_log, carrierid1


def lock_tables(engine):
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        print('locking table')
        session.execute("LOCK TABLES i_claims WRITE")
        print('tables locked')


def check_insurance_eligibility(authorization, patientid_num, insuranceid):
    demoreq, demores = submit_demand_request(authorization=authorization,
                                             patientid=patientid_num,
                                             insurancecoverageid=insuranceid)

    eligibilityid = demores["PPMDResults"]["Results"]["@eligibilityid"]
    elgibilityreq, eligibilityres = check_eligibility(authorization, eligibilityid)
    eligible = eligibilityres["PPMDResults"]["Results"]["@eligibilitystatusid"] == "0"
    return eligible, demoreq, demores, elgibilityreq, eligibilityres


def unlock_tables(engine):
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        print('unlocking tables')
        session.execute("UNLOCK TABLES")
        print('tables unlocked')


def create_process(license_key, file_name):
    engine = get_mysql_connection()
    session = Session(autocommit=True, bind=engine)
    maxprocessingid = 0

    with session.begin():
        maxprocessingid = session.query(func.max(IProcessing.Id)).scalar()
        process = IProcessing(
            Status=0,
            CreatedAt=datetime.datetime.utcnow(),
            CreatedBy=get_api_user(),
            LicenseKey=license_key,
            FileName=file_name

        )
        session.add(process)

    return maxprocessingid + 1


def update_process(process_id, status, engine):
    session = Session(autocommit=True, bind=engine)

    try:
        with session.begin():
            process = session.query(IProcessing).filter(IProcessing.Id == process_id).first()
            process.Status = status
        return True
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        return False


def send_macro_claim(authorization, db_claim, db_patient, db_charge_detail, db_facility, db_refplan,
                     http_req_res_mongo,
                     proccodeid=None, modcodeid=None, facilityid=None, fclassid=None, patientid=None, refprovid=None,
                     diagcodeid=None):
    print('processing claim :', db_claim.claimid)
    claim_log = {}
    count = 0

    icd_10_code = db_charge_detail.DiagnosisCodes  # TODO take from db
    begindate = db_charge_detail.BeginDateOfService.strftime(
        "%m/%d/%Y")  # "07/11/2020"  # TODO db_charge_detail.begindateofservice
    insurance_plan_begin_date = "01/01/2020"
    enddate = begindate  # TODO db_charge_detail.begindateofservice
    visitdate = begindate  # TODO db_charge_detail.begindateofservice
    referral_reason = ""

    if db_patient is None:
        print('Response : No patient found found, claim : ', db_claim.claimid)
        return False, 'No Patient in localdb'
    if db_charge_detail is None:
        print('Response : No charge detail found, claim : ', db_claim.claimid)
        return False, 'No charge detail in localdb'
    if db_facility is None:
        print('Response : No facility found found, claim : ', db_claim.claimid)
        return False, 'No facility in localdb'
    if db_refplan is None:
        print('Response : No refplan found found, claim : ', db_claim.claimid)
        return False, 'No refplan in localdb'

    if db_patient.PrimaryReferringProvider == 'PECOS NOT ENTROLLED':
        return False, 'PECOS NOT ENTROLLED'

    if refprovid is None:
        req, response, _, refprovid = LookupRefProvider.get_lookupid(authorization,
                                                                     LookupRefProvider.get_lookup_payload(
                                                                         code=db_patient.PrimaryReferringProvider),
                                                                     lookup_type="refprovider")
        count += 1
        claim_log[str(count)] = {'request': req, 'response': response}

    diagcodeids = None
    if "|" in icd_10_code:
        print("multiple diag codes")
        diagcodes = icd_10_code.split('|')
        diagcodeids = []
        for diagcode in diagcodes:
            try:
                req, response, _, diagcodeid = LookupDiagCode.get_lookupid(authorization,
                                                                           # TODO put this db_charge_detail.diagnosiscides
                                                                           LookupDiagCode.get_lookup_payload(
                                                                               code=diagcode), lookup_type="diagcode")
                diagcodeids.append(diagcodeid)
            except:
                pass
            count += 1
            claim_log[str(count)] = {'request': req, 'response': response}
        if len(diagcodeids) == 0:
            print("Couldn't lookup any diagnosis code. Check if they exist", db_claim.claimid)
            return False, ("Couldn't lookup any diagnosis code. Check if they exist" + str(db_claim.claimid))
        diagcodeids = " ".join(diagcodeids)
    else:
        print("only one diag code")
        req, response, _, diagcodeid = LookupDiagCode.get_lookupid(authorization,
                                                                   # TODO put this db_charge_detail.diagnosiscides
                                                                   LookupDiagCode.get_lookup_payload(
                                                                       code=icd_10_code), lookup_type="diagcode")
        diagcodeids = diagcodeid

    if refprovid is None:
        print('Referring provider missing in AMD')
        return False, "Refprov missing AMD"

    if diagcodeids is None:
        print('Diagnosis code doesnt exist in AMD', icd_10_code)
        return False, "Digcode missing AMD"

    req, response, _, patientid = LookupPatient.get_lookupid(authorization,
                                                             LookupPatient.get_lookup_payload(
                                                                 dob=db_patient.DOB.strftime("%m/%d/%Y"),
                                                                 exact="1",
                                                                 name=db_patient.LastName + ',' + db_patient.FirstName),
                                                             lookup_type="patient")
    count += 1
    claim_log[str(count)] = {'request': req, 'response': response}

    if patientid is None:
        address2 = db_patient.Address1 if (
                db_patient.Address2 == None or db_patient.Address2 == '') else db_patient.Address2
        address1 = '' if (
                address2 == db_patient.Address1) else db_patient.Address1

        print('Adding the patient to AMD')

        lookupprofile = LookupProfile()
        request, response, profileid = lookupprofile.get_lookupid(authorization, lookupprofile.get_lookup_payload(
            dob=db_patient.DOB.strftime("%m/%d/%Y"), exactmatch="1",
            name=db_patient.LastName + ',' + db_patient.FirstName), lookup_type="profile")

        count += 1
        claim_log[str(count)] = {'request': req, 'response': response}

        if profileid is None:
            print("Profile doesn't exist")
            return request, None, None

        request, response, patientid = add_patient(
            authorization, name=db_patient.LastName + ',' + db_patient.FirstName,
            dob=db_patient.DOB.strftime("%m/%d/%Y"),
            gender=db_patient.Gender, relationship="1",
            chart="AUTO", hipaarelationship="18", city=db_patient.City,
            state=db_patient.State, zip=db_patient.ZipCode, address1=address1,
            address2=address2, homephone=db_patient.HomePhone, officephone=db_patient.OfficePhone,
            email=db_patient.Email, insorder="", employer="",
            maritalstatus="1", ssn="", fclassid=fclassid, profileid=profileid
        )
        count += 1
        claim_log[str(count)] = {'request': request, 'response': response}
        if patientid is None:
            print('Unable to create the patient')
            return False, "Patient creation failed"

    req, response, demographic_infomation = get_demographic(patientid=patientid, authorization=authorization)
    count += 1
    claim_log[str(count)] = {'request': req, 'response': response}

    patientid_num = patientid.replace("pat", "")
    coverage = "1"
    current_insplan = None
    insuranceid = None
    default_carrier = None
    default_insuranceid = None
    already_eligible = False

    if type(demographic_infomation["patientlist"]["patient"]["insplanlist"]) == dict:
        if type(demographic_infomation["patientlist"]["patient"]["insplanlist"]["insplan"]) != list:
            print("there exist one insurance plan already")
            current_insplan = demographic_infomation["patientlist"]["patient"]["insplanlist"]["insplan"]
            insuranceid = current_insplan["@id"].replace("ins", "")
            already_eligible, demoreq, demores, elgibilityreq, eligibilityres = check_insurance_eligibility(
                authorization=authorization,
                insuranceid=insuranceid,
                patientid_num=patientid_num)
            if already_eligible:
                default_carrier = current_insplan["@carrier"]
                default_insuranceid = insuranceid
                print("the insurance plan is eligible")
            else:
                print("the insurance plan is not elgibile, will check the new ones")
        else:
            for current_insplan in demographic_infomation["patientlist"]["patient"]["insplanlist"]["insplan"]:
                print("there exist more than one insurance plans already")
                insuranceid = current_insplan["@id"].replace("ins", "")
                already_eligible, demoreq, demores, elgibilityreq, eligibilityres = check_insurance_eligibility(
                    authorization=authorization,
                    insuranceid=insuranceid,
                    patientid_num=patientid_num)
                if already_eligible:
                    default_carrier = current_insplan["@carrier"]
                    default_insuranceid = insuranceid
                    print("the insurance plan is eligible")
                    break
                else:
                    print("the insurance plan is not elgibile, checking if there are more")

            if already_eligible == False:
                print("No plan is eligible. We have to check with the new one given")

    if 'patientlist' not in demographic_infomation:
        print('Responsible party not in demographics', db_claim.SerialNumber)
        return False, "Resp party not in demographics"

    responsible_party = demographic_infomation['patientlist']['patient']['@respparty']

    # transaction_info = add_responsible_party(transaction_info) #TODO Not for SELF

    respparty1, respparty2, respparty3 = responsible_party, responsible_party, responsible_party
    insplans = []
    carriercode1 = "" if db_patient.CarrierCode1 == None else db_patient.CarrierCode1
    subnum1 = "" if db_patient.InsurancePolicy1 == None else db_patient.InsurancePolicy1
    carrierid1 = None
    if carriercode1 != "" and subnum1 != "":
        insplan, claim_log, carrierid1 = add_insurance(count, claim_log, authorization, carriercode1, subnum1,
                                                       respparty1,
                                                       insurance_plan_begin_date, already_eligible=already_eligible)
        insplans.append(insplan)

    if default_carrier is None and carrierid1 is None:
        error = "Existing plan is inelgible / New carrier doesn't exist :" + db_patient.CarrierCode1
        print(error)
        return False, error

    request, response_add_insurance_plan = add_insurance_plan(authorization=authorization,
                                                              patientid=patientid,
                                                              insplans=insplans)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response_add_insurance_plan}

    # run eligibility anyway to the new one
    insuranceid = response_add_insurance_plan["PPMDResults"]["Results"]["patient"]["@id"].replace("ins", "")
    new_eligible, demoreq, demores, elgibilityreq, eligibilityres = check_insurance_eligibility(
        authorization, patientid_num, insuranceid)
    if already_eligible == False and new_eligible == False:
        print("Both old and new insurance plans are ineligible. But continueing to create the visit.")
    elif already_eligible:
        print("Using the old eligible insurance.")
    else:
        print("Using the new eligible insurance.")

    request, response, demographic_infomation = get_demographic(patientid=patientid, authorization=authorization)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    request, response, chargeentry_data_icd10 = get_chargeentry_data_icd10(patientid=patientid,
                                                                           authorization=authorization)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    responsible_party = demographic_infomation['patientlist']['patient']['@respparty']
    profile = demographic_infomation['patientlist']['patient']['@profile']

    request, response, response_addvisit = addvisit(authorization, patientid, profile, begindate)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    visitid = response_addvisit["visit"]["@id"]
    visitsequence = visitid.replace("vst", "000")

    if type(chargeentry_data_icd10['patientlist']['patient']['episodelist']['episode']) is list:
        episode = chargeentry_data_icd10['patientlist']['patient']['episodelist']['episode'][0]['@id']
    else:
        episode = chargeentry_data_icd10['patientlist']['patient']['episodelist']['episode']['@id']

    req, response, refplan = add_referral_plan(authorization=authorization,
                                               proccode=proccodeid, refprov=refprovid,
                                               facility=facilityid, patientid=patientid,
                                               begindate=begindate, reason=referral_reason,
                                               diagcodes=diagcodeids
                                               )
    count += 1
    claim_log[str(count)] = {'request': req, 'response': response}

    request, response, extins_id = update_extra_ins_info(visitid, authorization)
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    custom_claim_fields = []
    accession_field = CustomClaimField("4188", db_claim.SerialNumber)
    # eligibility_field = CustomClaimField("4366", "PASS")

    custom_claim_fields.append(accession_field)
    # custom_claim_fields.append(eligibility_field)

    request, response, success, batchid, charge_id = update_visit_with_new_charges(
        authorization=authorization,
        patientid=patientid,
        charge_begindate=begindate,
        charge_enddate=enddate,
        charge_aging=begindate,
        visit_profile=profile,
        visit_date=visitdate,
        visit_refplan=refplan,
        visit_episode=episode,
        charge_proccode=proccodeid,
        charge_respparty=responsible_party,
        episodeid=episode,
        charge_diagcodes=diagcodeids,
        charge_modcodes=modcodeid,
        extins_id=extins_id,
        visit_id=visitid,
        visit_sequence=visitsequence,
        custom_claim_fields=custom_claim_fields,
        note=db_claim.SerialNumber,
        batchid="",
        charge_id="",
        approval="1" if (already_eligible or new_eligible) else "0"
    )
    count += 1
    claim_log[str(count)] = {'request': request, 'response': response}

    # Eligibility trigger
    count += 1
    claim_log[str(count)] = {'request': demoreq, 'response': demores}
    count += 1
    claim_log[str(count)] = {'request': elgibilityreq, 'response': eligibilityres}

    claim_log['ClaimId'] = db_claim.claimid
    claim_log['SerialNumber'] = db_claim.SerialNumber
    claim_log['VisitSeq'] = visitsequence
    claim_log['Old_plan_Eligible'] = already_eligible
    claim_log['New_plan_Eligible'] = new_eligible
    result_object = http_req_res_mongo.insert_one(claim_log)
    return success, str(response)

    # transaction_info = update_visit_with_new_charges(transaction_info)
    # transaction_info = save_charges(transaction_info)


def get_auxiliary_claim_info(engine, claim_ids, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        db_patients = session.query(PtPatientinfoDummy).filter(
            and_(
                PtPatientinfoDummy.ClaimId.in_(claim_ids),
                PtPatientinfoDummy.LicenseKey == license_key
            )).all()
        db_charge_details = session.query(ActvChargedetail).filter(
            and_(
                ActvChargedetail.ClaimId.in_(claim_ids),
                ActvChargedetail.LicenseKey == license_key
            )
        ).all()
        db_facilities = session.query(MfFacility).filter(
            and_(
                MfFacility.ClaimId.in_(claim_ids),
                MfFacility.LicenseKey == license_key
            )).all()
        db_refplans = session.query(PtReferralplan).filter(
            and_(
                PtReferralplan.ClaimId.in_(claim_ids),
                PtReferralplan.LicenseKey == license_key
            )
        ).all()

        return db_patients, db_charge_details, db_facilities, db_refplans


def get_basic_amd_codes(authorization,
                        facility_name, fclass_code, modcode, proccode):
    _, _, _, proccodeid = LookupProcCode.get_lookupid(authorization,
                                                      LookupProcCode.get_lookup_payload(
                                                          code=proccode),
                                                      lookup_type="proccode")
    _, _, _, modcodeid = LookupModcode.get_lookupid(authorization,  # TODO db_charge_detail.modcode
                                                    LookupModcode.get_lookup_payload(
                                                        code=modcode), lookup_type="modcode")
    _, _, _, facilityid = LookupFacility.get_lookupid(authorization,
                                                      LookupFacility.get_lookup_payload(
                                                          name=facility_name
                                                      ), lookup_type="facility")
    _, _, _, fclassid = LookupFinClass.get_lookupid(authorization,
                                                    LookupFinClass.get_lookup_payload(code=fclass_code),
                                                    lookup_type="finclass")

    if proccodeid is None:
        print('Procedure code provider missing in AMD')
        return False

    if modcodeid is None:
        print('Mod code doesnt exist in AMD')
        return False

    if facilityid is None:
        print('Faciltiy doesnt exist in AMD ', facility_name)
        return False

    if fclassid is None:
        print("Financial class doesn't exist")
        return None

    return proccodeid, modcodeid, facilityid, fclassid


def upload_claims_hl7(license_key, process_id, input_claims_df, engine):
    # Insert all claims to database
    patient_infos = []
    facilities = []
    charge_details = []
    referral_plans = []
    all_claims_df = input_claims_df.fillna('')

    if fclass_code is None:
        print('Financial class not configured for the template.')
        return False

    serials = tuple(list(all_claims_df['SerialNumber']))
    try:
        session = Session(autocommit=True, bind=engine)
        with session.begin():
            existing_claims = session.query(IClaim).filter(
                and_(
                    IClaim.SerialNumber.in_(serials),
                    IClaim.LicenseKey == license_key,
                    IClaim.IntegrationStatus.between(0, 3999))).all()
    except:
        # unlock_tables(engine)
        print(str(sys.exc_info()))
        return 1

    existing_serial_numbes = [c.SerialNumber for c in existing_claims]
    old_claims_df = all_claims_df[input_claims_df['SerialNumber'].isin(existing_serial_numbes)]
    input_claims_df = all_claims_df[input_claims_df['SerialNumber'].isin(existing_serial_numbes) == False]

    print('all claims :', len(all_claims_df), 'new claims :', len(input_claims_df), 'old claims :',
          len(old_claims_df))

    if len(input_claims_df) == 0:
        return 1

    try:
        session = Session(autocommit=True, bind=engine)
        with session.begin():
            maxjobid = session.query(func.max(IJob.jobid)).scalar()
            maxjobid = maxjobid + 1
    except:
        print(str(sys.exc_info()))
        # unlock_tables(engine)
        return 1

    job = IJob(
        LicenseKey=license_key,
        jobid=maxjobid,
        IntegrationStatus=0,
        ProcessId=process_id,
        ParentJob=0
    )

    errors = []
    lock_tables(engine)
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        claimid = session.query(func.max(IClaim.claimid)).scalar()

    iclaims = []
    for index, input_claim in input_claims_df.iterrows():
        claimid += 1
        print('Creating ', input_claim['SerialNumber'], " Claim id : ", claimid)
        claim = create_claim(
            input_claim=input_claim, jobid=job.jobid,
            claimid=claimid, process_id=process_id, license_key=license_key,
            template_id=template_id,
            fclass_code=fclass_code,

        )
        iclaims.append(claim)
        try:
            patient = create_patient_info(input_claim, claim, license_key=license_key)
            facility = create_facility(input_claim, claim, license_key=license_key)
            referral_plan = create_referral_plan(input_claim, claim, license_key=license_key)
            charge_detail = create_charge_detail(input_claim, claim, license_key=license_key)

            claim_cpts = create_claim_cpts(claimid=claimid,
                              authorization=authorization,
                              engine=engine, dos=date_of_service,
                              pos=templates[template_id]['TEMPLATE']['POS'],
                              tos=templates[template_id]['TEMPLATE']['TOS'],
                              code=templates[template_id]['TEMPLATE']['PROCCODES_CODES'],
                              name=templates[template_id]['TEMPLATE']['PROCCODES_NAMES'],
                              proccodes=templates[template_id]['TEMPLATE']['PROCCODES_DICT'],
                              macro_name=templates[template_id]['TEMPLATE']['PROCCODES_MACRONAMES'],
                              )

            if patient is not None:
                patient_infos.append(patient)
                facilities.append(facility)
                referral_plans.append(referral_plan)
                charge_details.append(charge_detail)
            else:
                errors.append((input_claim['SerialNumber'], "Didn't create patient"))
        except:
            pass

            errors.append((input_claim['SerialNumber'], sys.exc_info()))
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)

    # insert to all tables in bulk
    try:
        if len(patient_infos) > 0:
            claim_data = []
            claim_data.append(patient_infos)
            claim_data.append(facilities)
            claim_data.append(referral_plans)
            claim_data.append(charge_details)

            unlock_tables(engine)
            session = Session(bind=engine, autocommit=True)
            with session.begin(subtransactions=True):
                session.add(job)
                session.add_all(iclaims)
                session.add_all(patient_infos)
                session.add_all(facilities)
                session.add_all(referral_plans)
                session.add_all(charge_details)
                print('============================================')
                print('Claims Created')
            return 0
        else:
            unlock_tables(engine)
        print('Errors : ', errors)
    except:
        print("Unexpected error:", sys.exc_info())
        unlock_tables(engine)
        return 1
