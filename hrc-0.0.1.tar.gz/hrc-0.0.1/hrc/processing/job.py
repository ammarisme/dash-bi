import os
import sys

from sqlalchemy.orm import Session

from hrc.integration_db.models import JobPatient, JobDemographic, JobInsurance, JobEligibility, JobCpt, JobVisit


def close_patient_job(engine, job_id):
    print("Closing patient Job :  ", job_id)
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        upd = session.query(JobPatient). \
            filter(JobPatient.job_patient_id == job_id). \
            update({JobPatient.IntegrationStatus: 100})


def close_demo_job(engine, job_id):
    print("Closing demo Job :  ", job_id)
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        upd = session.query(JobDemographic). \
            filter(JobDemographic.id == job_id). \
            update({JobDemographic.IntegrationStatus: 100})


def close_insurance_job(engine, job_id):
    print("Closing insurance Job :  ", job_id)
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        upd = session.query(JobInsurance). \
            filter(JobInsurance.job_insurance_id == job_id). \
            update({JobInsurance.IntegrationStatus: 100})


def close_eligibility_job(engine, job_id):
    print("Closing eligibility Job :  ", job_id)
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        upd = session.query(JobInsurance). \
            filter(JobEligibility.job_eligibility_id == job_id). \
            update({JobEligibility.IntegrationStatus: 100})


def close_cpt_job(engine, job_id):
    print("Closing cpt Job :  ", job_id)
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        upd = session.query(JobInsurance). \
            filter(JobCpt.job_cpt_id == job_id). \
            update({JobCpt.IntegrationStatus: 100})


def close_visit_job(engine, job_id):
    print("Closing visit Job :  ", job_id)
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        upd = session.query(JobVisit). \
            filter(JobVisit.job_visit_id == job_id). \
            update({JobVisit.IntegrationStatus: 100})


def get_pending_patient_jobs(engine, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    connection = engine.raw_connection()
    with session.begin():
        cursor = connection.cursor()
        cursor.callproc("pending_patient_claims_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        cursor.close()
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
    return pending_claims


def get_pending_demo_jobs(engine, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_demo_claims_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        cursor.close()
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
    return pending_claims


def get_pending_insurance_jobs(engine, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    connection = engine.raw_connection()
    with session.begin():
        cursor = connection.cursor()
        cursor.callproc("pending_claim_insurance_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        cursor.close()
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
    return pending_claims


def get_pending_eligibility_jobs(engine, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_claim_eligibility_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
    return pending_claims


def get_pending_cpt_jobs(engine, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    connection = engine.raw_connection()
    with session.begin():
        cursor = connection.cursor()
        cursor.callproc("pending_claim_cpt_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        cursor.close()
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
    return pending_claims


def get_pending_visit_jobs(engine, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_claim_visits_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
    return pending_claims


def get_pending_approval_jobs(engine, license_key):
    pending_claims = []
    try:
        session = Session(autocommit=True, bind=engine, expire_on_commit=True)
        with session.begin():
            connection = engine.raw_connection()
            cursor = connection.cursor()
            cursor.callproc("pending_claim_approvals_by_license_key", [license_key])
            pending_claims = list(cursor.fetchall())
            pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
            cursor.close()
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(sys.exc_info(), fname, exc_tb.tb_lineno)
    finally:
        engine.dispose()

    return pending_claims
