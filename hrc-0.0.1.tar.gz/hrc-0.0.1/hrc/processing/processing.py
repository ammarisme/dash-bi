import os
import sys
import time
import traceback

import docker
from advancedmd.batch import create_batch
from advancedmd.license_key import authorize_license_key
from sqlalchemy.orm import Session
from sqlalchemy.sql.expression import func, and_

from hrc.common.api import get_api_url
from hrc.common.database import get_mysql_connection, get_mysql_host_name, get_mongo_connectionstring, \
    get_mongo_connection, get_mysql_connectionstring
from hrc.common.storage import connect_ftp
from hrc.common.time import ispeak
from hrc.common.user import get_op_user
from hrc.integration_db.models import IJob, IClaim
from hrc.settings import CONFIGURATION


def get_docker_hostname():
    IM_IN_DOCKER = os.environ.get('AM_I_IN_A_DOCKER_CONTAINER', False)
    if IM_IN_DOCKER:
        return CONFIGURATION.DOCKER_DOCKER_HOST
    else:
        return CONFIGURATION.DOCKER_HOST


def get_docker_client():
    docker_host = get_docker_hostname()
    client = docker.from_env(environment=dict({"DOCKER_HOST": docker_host}))
    return client


def redistribute_jobs(split_into, license_key, engine=None):
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        initial_jobid = session.query(func.max(IJob.jobid)).scalar()

    session = Session(autocommit=True, bind=engine)
    with session.begin():
        max_jobid = session.query(func.max(IJob.jobid)).scalar()
        for i in range(split_into):
            jobid = max_jobid + i + 1
            job = IJob(
                LicenseKey=license_key,
                jobid=jobid,
                IntegrationStatus=0
            )
            session.add(job)

    with session.begin():
        print('current max job id', max_jobid)
        pending_claims = session.query(IClaim).filter(
            and_(IClaim.IntegrationStatus.notin_((10, 40)), IClaim.LicenseKey == license_key)).all()
        claimids = [claim.claimid for claim in pending_claims]

        for i in range(split_into):
            jobid = initial_jobid + i + 1
            start = 1 + int(len(claimids) / split_into) * (i)
            end = (i + 1) * int(len(claimids) / split_into)
            print(start, end)
            setclaims = claimids[start:end]
            setclaims = tuple(setclaims)
            upd = session.query(IClaim).filter(IClaim.claimid.in_(setclaims)).update({IClaim.Job_id: jobid},
                                                                                     synchronize_session=False)


def stop_all_jobs(docker_client, license_key):
    containers = docker_client.containers.list()
    number_of_containers = len(containers)
    print("Currently running :", number_of_containers)
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            container.kill()

    return number_of_containers


def start_job(jobid, docker_client):
    cont = docker_client.containers.run(image="cloud.canister.io:5000/abameerdeen/job-runner",
                                        environment=dict({'JOB_ID': str(jobid),
                                                          'DB_HOST_NAME': get_mysql_host_name(),
                                                          'MONGO_CON_STRING': get_mongo_connectionstring(),
                                                          'NETWORK': 'host',
                                                          'DEBUG': '1'
                                                          }),
                                        detach=True,
                                        name='job-runner-' + str(jobid),
                                        network="host"
                                        )
    return cont


def prune_all_containers(docker_client):
    docker_client.containers.prune()


def start_all_jobs(docker_client, license_key, engine=None):
    containers = []
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_claims_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
        for job in pending_claims:
            print('running : ', job[0])
            cont = start_job(job[0], license_key=job[1], docker_client=docker_client)
            time.sleep(75)
            containers.append(cont)
    return containers


def restart_jobs(token, license_key):
    op_user = get_op_user(token)
    docker_client = get_docker_client()
    engine = get_mysql_connection()
    split_into = 2 if ispeak() else 8
    print('going to run ', split_into, ' jobs')
    stop_all_jobs(docker_client, license_key=license_key)
    redistribute_jobs(split_into, license_key=license_key, engine=engine)
    prune_all_containers(docker_client, license_key=license_key)
    create_batch(token, license_key)
    start_all_jobs(engine=engine, license_key=license_key, docker_client=docker_client)
    print('All jobs started')


def system_is_healthy():
    result = []
    isPeak = ispeak()
    result.append("system is at peak mode" if isPeak
                  else "system is at off-peak mode")

    mongo_connection = get_mongo_connection()
    result.append("mongo connected." if mongo_connection != None
                  else "mongo not connected.")
    result.append(get_mongo_connectionstring())

    db_connection = get_mysql_connection()
    result.append("mysql connected." if db_connection != None
                  else "mysql not connected.")
    result.append(get_mysql_connectionstring())

    ftp_connected = connect_ftp('/')
    result.append("ftp connected." if ftp_connected != None
                  else "ftp not connected.")

    try:
        docker_client = get_docker_client()
        containers = docker_client.containers.list()
        result.append("docker daemon connected.")
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        traceback.print_exc()
        result.append("docker daemon not connected.")
    result.append(get_docker_hostname())
    result.append('API URL : ' + get_api_url())
    result.append(str(CONFIGURATION.as_dict()))
    return result


def license_key_is_healthy(license_key):
    result = system_is_healthy()
    ftp_connected = connect_ftp('/' + license_key)
    authorization = authorize_license_key(license_key)
    result.append("ftp connected." if ftp_connected != None
                  else "ftp not connected.")
    result.append('token : ', authorization.token)
    return result


def running_containers(license_key, container_type, docker_client=None):
    if docker_client is None:
        docker_client = get_docker_client()
    containers = docker_client.containers.list()
    conts = [cont for cont in containers if (container_type in cont.name) and (str(license_key) in cont.name)]
    return conts
