import sqlalchemy
from sqlalchemy import and_

from hrc.integration_db.models import ProcessChainDt
from sqlalchemy.orm import Session


def get_process_chain(engine, chain_id):
    session = Session(bind=engine, autocommit=True, expire_on_commit=False)
    with session.begin():
        process_chain_detail = session.query(ProcessChainDt).filter(ProcessChainDt.chain_id == chain_id).all()

    return process_chain_detail


def get_next_process(engine, chain_id, current_process_id):
    session = Session(bind=engine, autocommit=True, expire_on_commit=False)
    with session.begin():
        process_chain_detail = session.query(ProcessChainDt.next) \
            .filter(and_(ProcessChainDt.chain_id == chain_id,
                         ProcessChainDt.current == current_process_id)).all()

    return process_chain_detail


def update_claim_status(engine, claimid, chain_id, current_process_id, transfer_type, license_key, error="", error_type_id = 0):
    session = Session(bind=engine, autocommit=True, expire_on_commit=False)
    with session.begin():
        query = "CALL move_to_next_stage(" + str(claimid) + "," \
                + str(current_process_id) + "," \
                + str(chain_id) + "," + str(transfer_type) + ' ," ' + error + '" , '+str(error_type_id)+' ,"' + str(license_key) + '" )'
        print(query)
        session.execute(sqlalchemy.text(query))


def update_claim_status_session(session, claimid, chain_id, current_process_id, transfer_type, license_key, error="", error_type_id=0):
    with session.begin():
        query = "CALL move_to_next_stage(" + str(claimid) + "," \
                + str(current_process_id) + "," \
                + str(chain_id) + "," + str(transfer_type) + ' ," ' + error + '", '+str(error_type_id)+' , "' + str(license_key) + '" )'
        print(query)
        session.execute(sqlalchemy.text(query))
