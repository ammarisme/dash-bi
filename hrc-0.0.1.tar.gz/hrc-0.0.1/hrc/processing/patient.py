import os
import sys

from sqlalchemy import func, and_
from sqlalchemy.orm import Session

from hrc.common.database import get_mysql_connection
from hrc.integration_db.models import JobUpdatePatient, UpdatePatientInfo, ClaimUpdatedPatient
from hrc.processing.processing import get_docker_client, prune_all_containers
from hrc.settings import CONFIGURATION


def create_update_patient_stage(engine,license_key,split_count):
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        maxjobid = session.query(func.max(JobUpdatePatient.id)).scalar()
        maxjobid = maxjobid + 1

        claims = session.query(UpdatePatientInfo). \
            filter(
            and_(
                UpdatePatientInfo.updated == False,
                UpdatePatientInfo.IntegrationStatus == 0,
                UpdatePatientInfo.LicenseKey == license_key
            )).all()

        if len(claims) == 0:
            return 0

        for i in range(split_count):
            job_id = maxjobid + i
            job = JobUpdatePatient()
            job.LicenseKey = license_key
            job.IntegrationStatus = 0
            job.job_id = job_id

            session.add(job)

            if i != split_count - 1:
                print(i * (len(claims) / split_count),
                      ((i + 1) * (len(claims) / split_count) - 1))
                subset_claims = claims[
                                int(i * (len(claims) / split_count)):int(((i + 1) * (len(claims) / split_count) - 1))]
            else:
                print(i * (len(claims) / split_count),
                      ((i + 1) * (len(claims) / split_count) - 1))
                subset_claims = claims[
                                int(i * (len(claims) / split_count)):]

            claim_demographics = []
            for c in subset_claims:
                claim = ClaimUpdatedPatient()
                claim.IntegrationStatus = 0
                claim.LicenseKey = license_key
                claim.job_id = job_id
                claim.update_claim_info_id = c.id
                claim_demographics.append(claim)

            session.add_all(claim_demographics)

        claimids = [claim.id for claim in claims]
        upd = session.query(UpdatePatientInfo).filter(UpdatePatientInfo.id.in_(claimids)). \
            update({UpdatePatientInfo.IntegrationStatus: 100},
                   synchronize_session=False)

    return maxjobid


def start_all_update_patient_jobs(docker_client, license_key, chained, sleep_time=60, engine=None):
    containers = []
    pending_claims = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_update_patients_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)

        for job in pending_claims:
            try:
                print('running : ', job[0])
                cont = start_update_patient_job(
                    jobid=job[0], license_key=job[1],
                    docker_client=docker_client,
                    chained=chained
                )
                containers.append(cont)
            except:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print(exc_type, fname, exc_tb.tb_lineno)
        cursor.connection.commit()
    return containers


def start_update_patient_job(license_key, jobid, docker_client, chained):
    docker_mode = CONFIGURATION.MODE
    env_variables = dict({'MODE': docker_mode,
                          'JOB_ID': jobid,
                          'NETWORK': 'host',
                          "CHAINED": chained,
                          "LICENSE_KEY": license_key
                          })
    print(env_variables)
    cont = docker_client.containers.run(image="update-patients-job-runner", environment=env_variables, detach=True,
                                        name=str(license_key) + '-update-patients-job-runner-' + str(jobid),
                                        network="host")
    return cont

#
#
# def run_insurance_stage(license_key,token,no_redistribution,no_status_change=False):
#     engine = get_mysql_connection()
#     docker_client = get_docker_client()
#     # stop
#     #stop_all_insurance_containers(docker_client=docker_client, license_key=license_key)
#     prune_all_containers(docker_client)
#
#     # put all pending claims on the job
#     if no_redistribution is None:
#         # create the eligibility job
#         split_count =  4 ; # get_split_count(license_key=license_key)
#         job_id = create_insurance_job(engine, license_key, split_count=split_count)
#         # put all pending claims on the job
#     # start
#         start_all_insurance_jobs(engine=engine, license_key=license_key, docker_client=docker_client, chained="1")
