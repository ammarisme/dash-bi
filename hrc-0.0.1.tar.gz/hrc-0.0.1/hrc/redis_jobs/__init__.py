import sys
import time
import requests
from time import strftime, gmtime
from advancedmd.common.amd_errors import is_429_error, is_credential_error
from hrc.common.time import get_current_time
from advancedmd.common.views.view_utils import todict
from advancedmd.demographics.api_models.amd_payload import AMDPayload
from advancedmd.demographics.api_models.login import Login

amd_api_login_url = 'https://partnerlogin.advancedmd.com/practicemanager/xmlrpc/processrequest.aspx'


class AMDUser():
    def __init__(self):
        self.token = ""
        self.url = ""
        self.login_response = None

    def login_to_amd_api(self, license_key_dt, api_user, api_password, api_appname, connection, force=True,
                         retry_count=10000):
        if force is False:
            self.token = license_key_dt.api_token
            self.url = license_key_dt.api_url

            return self.token

        print('loging in to : ', license_key_dt.license_key)
        login_payload = Login()
        login_payload.action = "login"
        login_payload.class_ = "login"
        login_payload.msgtime = strftime("%m/%d/%Y %I:%M:%S %p", gmtime())
        login_payload.username = api_user
        login_payload.psw = api_password
        login_payload.officecode = license_key_dt.license_key
        login_payload.appname = api_appname
        retries_done = 0
        while True:
            if retries_done >= retry_count:
                print('Max retries done!')
                break
            try:
                self.login_response = self.first_login(login_payload, amd_api_login_url)
                self.login_response = self.login_response.json()
                self.token = self.login_response['PPMDResults']['Results']['usercontext']['#text']
                self.url = self.login_response['PPMDResults']['Results']['usercontext'][
                               '@webserver'] + '/xmlrpc/processrequest.asp'
                break
            except:
                retries_done += 1
                if is_credential_error(self.login_response):
                    connection.hset('license_key:' + str(license_key_dt.license_key), 'status', 2)
                    raise Exception('The system could not log you on. Make sure that your login name, office key, '
                                    'and password are correct')

                if is_429_error(self.login_response):
                    print('429 error : trying again in 60 secs :')
                    time.sleep(60)

        try:
            current_date_time = get_current_time()
        except:
            current_date_time = ''

        try:
            api_url = str(self.url)
            token_api = str(self.token)
            connection.hset('license_key:' + str(license_key_dt.license_key), 'api_url', api_url)
            connection.hset('license_key:' + str(license_key_dt.license_key), 'api_token', token_api)
            connection.hset('license_key:' + str(license_key_dt.license_key), 'last_login_date', str(current_date_time))
            connection.hset('license_key:' + str(license_key_dt.license_key), 'last_login_time', str(current_date_time))
        except:
            print(sys.exc_info())

        return self.token

    def first_login(self, payload_object, url):
        # need to make sure the action, class, msgtime are set.
        amd_payload = AMDPayload()
        payload_object.msgtime = strftime("%m/%d/%Y %I:%M:%S %p", gmtime())
        amd_payload.ppmdmsg = payload_object
        json_payload = todict(amd_payload)
        headers = {'content-type': 'application/json', 'accept': 'application/json'}
        response = requests.post(url, json=json_payload, headers=headers)
        login_url_base = response.json()['PPMDResults']['Results']['usercontext']['@webserver']
        final_response = self.second_login(login_url_base + '/xmlrpc/processrequest.asp', json_payload)
        return final_response

    def second_login(self, url, payload):
        headers = {'content-type': 'application/json', 'accept': 'application/json'}
        response = requests.post(url, json=payload, headers=headers)
        return response

    def get_token(self):
        return self.token
