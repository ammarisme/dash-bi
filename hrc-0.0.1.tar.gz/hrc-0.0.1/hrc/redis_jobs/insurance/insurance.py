import os
import sys
from hrc.settings import CONFIGURATION
from hrc.redis_jobs.common import redis_get_split_count, redis_get_claim_status_data
from hrc.redis_jobs.insurance.insurance_controller import redis_get_insurance_job_status_data, \
    get_redis_existing_claim_insurance_jobs
from hrc.processing.processing import get_docker_client, prune_all_containers, running_containers


def start_insurance_job(license_key, jobid, docker_client, chained):
    docker_mode = CONFIGURATION.MODE
    env_variables = dict({'MODE': docker_mode,
                          'JOB_ID': jobid,
                          'NETWORK': 'host',
                          "CHAINED": chained,
                          "LICENSE_KEY": license_key
                          })
    print(env_variables)
    cont = docker_client.containers.run(image="insurance-job-runner",
                                        environment=env_variables
                                        , detach=True
                                        , name=str(license_key) + '-insurance-job-runner-' + str(jobid)
                                        , network="host"
                                        , volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}}
                                        )
    return cont


def start_all_insurance_jobs(redis_connection, docker_client, license_key, chained):
    insurance_claims_data_frame, insurance_jobs_count = redis_get_insurance_job_status_data(
        redis_connection=redis_connection, license_key=license_key)

    pending_insurance_df = insurance_claims_data_frame[insurance_claims_data_frame["job_status"] == "0"]

    if len(pending_insurance_df) == 0:
        return True

    pending_claims = list(pending_insurance_df["job_id"])
    containers = []
    insurance_containers = running_containers(license_key, 'insurance', docker_client)

    for job in pending_claims:
        try:
            existing_cont = [cont for cont in insurance_containers if str(job) in cont.name]
            if len(existing_cont) > 0:
                continue

            print('running : ', job)
            cont = start_insurance_job(
                jobid=job, license_key=license_key,
                docker_client=docker_client,
                chained=chained
            )
            containers.append(cont)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
    return containers


def create_insurance_job(redis_connection, license_key, split_count):
    claims_data_frame = redis_get_claim_status_data(redis_connection=redis_connection, license_key=license_key)
    pending_claims_df = claims_data_frame[claims_data_frame["claim_status"] == "230"]

    if len(pending_claims_df) == 0:
        return None

    ins_claims_data_frame, ins_jobs_count = redis_get_insurance_job_status_data(redis_connection=redis_connection,
                                                                                license_key=license_key)
    if ins_jobs_count == 0:
        insurance_job_id = 0
    else:
        job_list = ins_claims_data_frame.values[-1].tolist()
        insurance_job_id = int(job_list[0])

    number_of_claims = len(pending_claims_df)
    if number_of_claims < 100:
        split_count = 2
    if number_of_claims < 30:
        split_count = 1

    job_size = int(number_of_claims / split_count) + 1
    for i in range(split_count):
        try:
            claims_data_frame = redis_get_claim_status_data(redis_connection=redis_connection,
                                                            license_key=license_key)
            pending_claims_df = claims_data_frame[claims_data_frame["claim_status"] == "230"]

            if len(pending_claims_df) == 0:
                break

            insurance_job_id = insurance_job_id + 1

            redis_connection.hset('insurance_job_status:' + str(license_key), str(insurance_job_id), "0")
        except:
            redis_connection.hset('patient_job_status:' + str(license_key), str(insurance_job_id), "100")
            print(sys.exc_info())
            continue

        count = 0
        for index, row in pending_claims_df.iterrows():

            try:
                count = count + 1
                if count >= (job_size + 1):
                    break

                claim_job_status = get_redis_existing_claim_insurance_jobs(redis_connection=redis_connection,
                                                                           license_key=license_key,
                                                                           claim_id=str(row['claim_id']))

                if not claim_job_status:
                    continue
            except:
                print(sys.exc_info())
                continue

            try:
                claim_ins_status = redis_connection.hget(
                    'claim_insurance:' + str(insurance_job_id) + '_' + str(license_key), str(row['claim_id']))

                if claim_ins_status is not None:
                    if int(claim_ins_status) < 400:
                        continue
            except:
                print(sys.exc_info())
                continue
            try:
                redis_connection.hset('claim_insurance:' + str(insurance_job_id) + '_' + str(license_key),
                                      str(row['claim_id']), "0")

                is_exist_claim_pat = redis_connection.hexists(
                    'claim_insurance:' + str(insurance_job_id) + '_' + str(license_key), str(row['claim_id']))

                if is_exist_claim_pat:
                    redis_connection.hset('claim_status:' + str(license_key), str(row['claim_id']), 300)
                    redis_connection.hset('claims:' + str(row['claim_id']), 'integration_status', 300)

            except:

                redis_connection.hset('claim_insurance:' + str(insurance_job_id) + '_' + str(license_key),
                                      str(row['claim_id']), "100")
                redis_connection.hset('claim_status:' + str(license_key), str(row['claim_id']), "0")
                redis_connection.hset('claims:' + str(row['claim_id']), 'integration_status', "0")
                print(sys.exc_info())

    return True


def run_insurance_stage(connection, license_key, no_redistribution, status, no_status_change=False):
    docker_client = get_docker_client()
    prune_all_containers(docker_client)

    if no_redistribution is None:
        split_count = redis_get_split_count(connection=connection, license_key=license_key)
        if status == 230:
            try:
                create_insurance_job(redis_connection=connection, license_key=license_key,
                                     split_count=split_count)
            except:
                print(sys.exc_info())

        start_all_insurance_jobs(redis_connection=connection, license_key=license_key,
                                 docker_client=docker_client, chained="1")
