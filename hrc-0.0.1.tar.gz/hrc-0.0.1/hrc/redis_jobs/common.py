import pandas as pd
from advancedmd.common.api_models.batches import NewBatch
from advancedmd.common.views.view_utils import send_to_amd_api
from hrc.redis_jobs import AMDUser
from hrc.common.time import ispeak
from hrc.integration_db.models import LicenseKey


# get split count from license key table according to is peak or not
def redis_get_split_count(connection, license_key):
    multiplier = 1
    try:
        license_key_dict = connection.hgetall('license_key:' + str(license_key))
        if license_key_dict is not None:
            multiplier = int(license_key_dict['peak_multiplier']) if ispeak() else int(
                license_key_dict['off_peak_multiplier'])
    except:
        multiplier = 6

    return multiplier


def redis_get_claim_status_data(redis_connection, license_key):
    claim_statuses_dict = redis_connection.hgetall("claim_status:" + str(license_key))
    claim_ids = [key for key, value in claim_statuses_dict.items()]
    statuses = [value for key, value in claim_statuses_dict.items()]

    data = {"claim_id": claim_ids, "claim_status": statuses}
    claims_data_frame = pd.DataFrame(data)

    return claims_data_frame


def redis_get_license_keys(connection, license_key_type):
    license_key_dict = connection.hgetall('license_keys')
    license_key_list = [key for key, value in license_key_dict.items()]
    license_key_type_list = [value for key, value in license_key_dict.items()]

    data = {'license_key': license_key_list, 'type': license_key_type_list}
    license_key_data_frame = pd.DataFrame(data)

    license_key_type_com = "1_" + str(license_key_type)
    result_df = license_key_data_frame[license_key_data_frame["type"] == str(license_key_type_com)]
    if len(result_df) == 0:
        result_list = None
    else:
        result_list = list(result_df["license_key"])

    return result_list


def redis_get_license_key_details(connection, license_key_list):
    license_key_details = []
    for license_key in license_key_list:
        license_key_dict = connection.hgetall('license_key:' + str(license_key))
        try:
            hl7_status = str(license_key_dict['hl7_status'])
        except:
            hl7_status = 0

        office_key = LicenseKey(
            license_key=license_key,
            api_username=license_key_dict['api_username'],
            api_password=license_key_dict['api_password'],
            api_appname=license_key_dict['api_appname'],
            status=license_key_dict['status'],
            client_name=license_key_dict['client_name'],
            type=license_key_dict['type'],
            api_token=license_key_dict['api_token'],
            off_peak_multiplier=int(license_key_dict['off_peak_multiplier']),
            peak_multiplier=int(license_key_dict['peak_multiplier']),
            last_login=license_key_dict['last_login_date'] + ' ' + license_key_dict['last_login_time'],
            api_url=license_key_dict['api_url'],
            claim_limit=int(license_key_dict['claim_limit']),
            hl7_status=hl7_status
        )
        license_key_details.append(office_key)

    return license_key_details


def redis_get_chain_data(redis_connection, chain_id):
    license_key_dict = redis_connection.hgetall('chain:' + str(chain_id))

    chain_details = [value for key, value in license_key_dict.items()]
    next = []
    next_runner_type = []
    current = []
    current_stage_type = []
    transaction_type = []
    for chain in chain_details:
        arr_chain = str(chain).split(',')
        next.append(arr_chain[0])
        next_runner_type.append(arr_chain[1])
        current.append(arr_chain[2])
        current_stage_type.append(arr_chain[3])
        transaction_type.append(arr_chain[4])

    data = {
        'next': next,
        'next_runner_type': next_runner_type,
        'current': current,
        'current_stage_type': current_stage_type,
        'transaction_type': transaction_type
    }

    chain_data_frame = pd.DataFrame(data)

    return chain_data_frame


def authorize_license_key(license_key, connection, max_retry=10000):
    license_key_details = redis_get_license_key_details(connection, [license_key])
    license_key_dt = license_key_details[0]

    authorization = AMDUser()
    authorization.login_to_amd_api(license_key_dt=license_key_dt,
                                   api_user=license_key_dt.api_username,
                                   api_password=license_key_dt.api_password,
                                   api_appname=license_key_dt.api_appname,
                                   force=True,
                                   connection=connection,
                                   retry_count=max_retry
                                   )
    return authorization


def redis_get_template_by_id(connection, template_id):
    template = connection.hgetall('template:' + str(template_id))
    template['INSORDER'] = template['INSORDER'] if ('INSORDER' in template) else '1'
    template['PREAUTH'] = template['PREAUTH'] if ('PREAUTH' in template) else ''
    template['FACILITYCODE'] = template['FACILITYCODE'] if ('FACILITYCODE' in template) else None
    template['FCLASS'] = template['FCLASS'] if ('FCLASS' in template) else None
    template['DEFAULT_MACRO'] = template['DEFAULT_MACRO'] if ('DEFAULT_MACRO' in template) else None
    template['MACRO'] = template['MACRO'] if ('MACRO' in template) else None
    template['PROC'] = template['PROC'] if ('PROC' in template) else None
    template['MOD1'] = template['MOD1'] if ('MOD1' in template) else None
    template['ACCESSIONFIELDID'] = template['ACCESSIONFIELDID'] if ('ACCESSIONFIELDID' in template) else None
    template['RENDERINGPROVIDER'] = template['RENDERINGPROVIDER'] if ('RENDERINGPROVIDER' in template) else None
    template['RENDERINGPROVIDER'] = template['RENDERINGPROVIDER'] if ('RENDERINGPROVIDER' in template) else None
    template['RESPARTYAC'] = template['RESPARTYAC'] if ('RESPARTYAC' in template) else None
    template['BILLTYPE'] = template['BILLTYPE'] if ('BILLTYPE' in template) else '1'
    template['CHAIN'] = template['CHAIN'] if ('CHAIN' in template) else None
    template['FACILITYID'] = template['FACILITYID'] if ('FACILITYID' in template) else None

    return template


def redis_get_license_key(connection, license_key):
    license_key_dict = connection.hgetall('license_key:' + str(license_key))

    office_key = LicenseKey(
        license_key=license_key,
        api_username=license_key_dict['api_username'],
        api_password=license_key_dict['api_password'],
        api_appname=license_key_dict['api_appname'],
        status=license_key_dict['status'],
        client_name=license_key_dict['client_name'],
        type=license_key_dict['type'],
        api_token=license_key_dict['api_token'],
        off_peak_multiplier=int(license_key_dict['off_peak_multiplier']),
        peak_multiplier=int(license_key_dict['peak_multiplier']),
        last_login=license_key_dict['last_login_date'] + ' ' + license_key_dict['last_login_time'],
        api_url=license_key_dict['api_url'],
        claim_limit=int(license_key_dict['claim_limit'])
    )

    return office_key


def create_batch(license_key, redis_connection):
    license_key_dt = redis_get_license_key(connection=redis_connection, license_key=license_key)

    newbatch = NewBatch()
    authorization = AMDUser()
    authorization.login_to_amd_api(license_key_dt=license_key_dt,
                                   api_user=license_key_dt.api_username,
                                   api_password=license_key_dt.api_password,
                                   api_appname=license_key_dt.api_appname,
                                   force=True,
                                   connection=redis_connection,
                                   retry_count=2
                                   )

    response = send_to_amd_api(newbatch, authorization)
    return response
