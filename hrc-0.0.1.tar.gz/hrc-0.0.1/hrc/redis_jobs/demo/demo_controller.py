import pandas as pd


def redis_get_demo_job_status_data(redis_connection, license_key):
    demo_job_statuses_dict = redis_connection.hgetall('demo_job_status:' + str(license_key))
    job_ids = [key for key, value in demo_job_statuses_dict.items()]
    job_statuses = [value for key, value in demo_job_statuses_dict.items()]

    data = {'job_id': job_ids, 'job_status': job_statuses}
    demo_claims_data_frame = pd.DataFrame(data)
    demo_jobs_count = len(demo_claims_data_frame)

    return demo_claims_data_frame, demo_jobs_count


def redis_get_pending_demo_job_status_data(redis_connection, license_key):
    demo_job_statuses_dict = redis_connection.hgetall('demo_job_status:' + str(license_key))
    job_ids = [key for key, value in demo_job_statuses_dict.items()]
    job_statuses = [value for key, value in demo_job_statuses_dict.items()]

    data = {'job_id': job_ids, 'job_status': job_statuses}
    demo_claims_data_frame = pd.DataFrame(data)

    pending_claims_df = demo_claims_data_frame[demo_claims_data_frame["job_status"] == "0"]

    return pending_claims_df


def get_redis_existing_claim_demo_jobs(redis_connection, license_key, claim_id):
    pending_claims_df = redis_get_pending_demo_job_status_data(redis_connection, license_key)
    job_ids = list(pending_claims_df["job_id"])

    main_df = pd.DataFrame()

    for job_id in job_ids:
        claim_pat_dict = redis_connection.hgetall('claim_demographics:' + str(job_id) + '_' + str(license_key))

        claim_ids = [key for key, value in claim_pat_dict.items()]
        statuses = [value for key, value in claim_pat_dict.items()]

        data = {"claim_id": claim_ids, "claim_status": statuses}
        claims_data_frame = pd.DataFrame(data)

        main_df = main_df.append(claims_data_frame, ignore_index=True)

    pending_claims_df = main_df.loc[main_df["claim_id"] == str(claim_id)]

    if len(pending_claims_df) == 0:
        return True

    existing_claim_jobs = list(pending_claims_df["claim_status"])

    if "0" in existing_claim_jobs:
        return False

    return True
