import sys
from hrc.redis_jobs.common import create_batch
from hrc.redis_jobs.cpt.cpt_controller import redis_get_pending_cpt_job_status_data
from hrc.jobs.approval.approval import run_approval_stage
from hrc.processing.job import get_pending_approval_jobs
from hrc.redis_jobs.cpt.cpt import run_cpt_stage
from hrc.redis_jobs.eligibility.eligibility import run_eligibility_stage
from hrc.redis_jobs.eligibility.eligibility_controller import redis_get_pending_eligibility_job_status_data
from hrc.redis_jobs.insurance.insurance import run_insurance_stage
from hrc.redis_jobs.demo.demo import run_demo_stage
from hrc.redis_jobs.demo.demo_controller import redis_get_pending_demo_job_status_data
from hrc.redis_jobs.insurance.insurance_controller import redis_get_pending_insurance_job_status_data
from hrc.redis_jobs.patient.patient_controller import redis_get_pending_patient_job_status_data
from hrc.processing.processing import get_docker_client, running_containers
from hrc.redis_jobs.visit.visit import run_visit_stage


def start_next_stage(redis_connection, previous_stage, license_key, status, engine):
    docker_client = get_docker_client()
    docker_client.containers.prune()

    if previous_stage == '200':
        # check previous stage container count - patient creation
        patient_containers = running_containers(license_key, 'patient')
        # check previous stage jobs count - patient jobs
        pending_jobs = redis_get_pending_patient_job_status_data(redis_connection=redis_connection,
                                                                 license_key=license_key)
        if len(pending_jobs) == 0 or len(patient_containers) <= 1:
            # start demographics stage - create jobs and start all created jobs
            run_demo_stage(connection=redis_connection, license_key=license_key, status=status)
            print('demo stage started : ')
        else:
            print('there are already patients jobs')

    elif previous_stage == '230':
        # check previous stage container count - demo
        demo_containers = running_containers(license_key, 'demo')
        # check previous stage jobs count - demo jobs
        pending_jobs = redis_get_pending_demo_job_status_data(redis_connection=redis_connection,
                                                              license_key=license_key)

        if len(pending_jobs) == 0 or len(demo_containers) <= 1:
            # start insurance stage - create jobs and start all created jobs
            run_insurance_stage(connection=redis_connection,
                                license_key=license_key,
                                no_redistribution=None, no_status_change=False, status=status)
            print('insurance stage started : ')
        else:
            print('there are already demo jobs')

    elif previous_stage == '400':

        insurance_conts = running_containers(license_key, 'insurance')
        pending_jobs = redis_get_pending_insurance_job_status_data(redis_connection=redis_connection,
                                                                   license_key=license_key)

        if len(pending_jobs) == 0 or len(insurance_conts) <= 1:
            run_eligibility_stage(connection=redis_connection, license_key=license_key, no_status_change=False,
                                  status=status)
            print('eligibility stage started : ')
        else:
            print('there are already insurance jobs')

    elif previous_stage == '600':
        eligibility_conts = running_containers(license_key, 'eliibility')
        pending_insurance_jobs = redis_get_pending_eligibility_job_status_data(redis_connection=redis_connection,
                                                                               license_key=license_key)
        if len(pending_insurance_jobs) == 0 or len(eligibility_conts) <= 1:
            run_cpt_stage(connection=redis_connection, license_key=license_key, status=status)
            print('cpt stage started : ')
        else:
            print('there are already insurance jobs')

    elif previous_stage == '800':
        cpt_containers = running_containers(license_key, 'cpt')
        pending_jobs = redis_get_pending_cpt_job_status_data(redis_connection=redis_connection, license_key=license_key)
        if len(pending_jobs) == 0 or len(cpt_containers) <= 1:
            create_batch(license_key=license_key, redis_connection=redis_connection)
            run_visit_stage(connection=redis_connection, license_key=license_key, no_redistribution=None, status=status,
                            no_status_change=False)
            print('visit stage started : ')
        else:
            print('there are already visit jobs')

    elif previous_stage == '1000':

        visit_approval_containers = running_containers(license_key, 'approval')
        pending_jobs = get_pending_approval_jobs(engine=engine, license_key=license_key)

        if len(pending_jobs) == 0 or len(visit_approval_containers) <= 1:
            run_approval_stage(license_key=license_key, engine=engine, docker_client=docker_client, status=status)
            print('approval stage started : ')
        else:
            print('there are already approval jobs')

    else:
        print('no suitable next stage found')


def job_completed(previous_stage, license_key, status, connection, engine):
    try:
        start_next_stage(redis_connection=connection, previous_stage=previous_stage, license_key=license_key,
                         status=status, engine=engine)
    except:
        exc_info = sys.exc_info()
        print(exc_info)
        return False
    return True
