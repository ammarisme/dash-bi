import pandas as pd


def redis_get_eligibility_job_status_data(redis_connection, license_key):
    eligibility_job_statuses_dict = redis_connection.hgetall('eligibility_job_status:' + str(license_key))
    job_ids = [key for key, value in eligibility_job_statuses_dict.items()]
    job_statuses = [value for key, value in eligibility_job_statuses_dict.items()]

    data = {'job_id': job_ids, 'job_status': job_statuses}
    eligibility_claims_data_frame = pd.DataFrame(data)
    eligibility_jobs_count = len(eligibility_claims_data_frame)

    return eligibility_claims_data_frame, eligibility_jobs_count


def redis_get_pending_eligibility_job_status_data(redis_connection, license_key):
    ins_job_statuses_dict = redis_connection.hgetall('eligibility_job_status:' + str(license_key))
    job_ids = [key for key, value in ins_job_statuses_dict.items()]
    job_statuses = [value for key, value in ins_job_statuses_dict.items()]

    data = {'job_id': job_ids, 'job_status': job_statuses}
    ins_claims_data_frame = pd.DataFrame(data)

    pending_claims_df = ins_claims_data_frame[ins_claims_data_frame["job_status"] == "0"]

    return pending_claims_df


def get_redis_existing_claim_eligibility_jobs(redis_connection, license_key, claim_id):
    pending_claims_df = redis_get_pending_eligibility_job_status_data(redis_connection, license_key)
    pending_claims_df = pending_claims_df[pending_claims_df["job_status"] == "0"]

    job_ids = list(pending_claims_df["job_id"])

    main_df = pd.DataFrame()

    for job_id in job_ids:
        claim_pat_dict = redis_connection.hgetall('claim_eligibility:' + str(job_id) + '_' + str(license_key))

        claim_ids = [key for key, value in claim_pat_dict.items()]
        statuses = [value for key, value in claim_pat_dict.items()]

        data = {"claim_id": claim_ids, "claim_status": statuses}
        claims_data_frame = pd.DataFrame(data)

        main_df = main_df.append(claims_data_frame, ignore_index=True)

    pending_claims_df = main_df.loc[main_df["claim_id"] == str(claim_id)]

    if len(pending_claims_df) == 0:
        return True

    existing_claim_jobs = list(pending_claims_df["claim_status"])

    if "0" in existing_claim_jobs:
        return False

    return True
