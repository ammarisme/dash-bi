import os
import sys
from hrc.settings import CONFIGURATION
from hrc.redis_jobs.common import redis_get_split_count, redis_get_claim_status_data
from hrc.redis_jobs.visit.visit_controller import redis_get_visit_job_status_data, get_redis_existing_claim_visit_jobs
from hrc.processing.processing import get_docker_client, prune_all_containers, running_containers


def start_visit_job(license_key, jobid, docker_client, chained, no_status_change=False):
    docker_mode = CONFIGURATION.MODE

    if no_status_change:
        env_variables = dict({'MODE': docker_mode,
                              'JOB_ID': jobid,
                              'NETWORK': 'host',
                              'NO_STATUS_CHANGE': '1',
                              "CHAINED": "1",
                              "LICENSE_KEY": license_key
                              })
    else:
        env_variables = dict({'MODE': docker_mode,
                              'JOB_ID': jobid,
                              'NETWORK': 'host',
                              "CHAINED": "1",
                              "LICENSE_KEY": license_key
                              })
    print(env_variables)
    cont = docker_client.containers.run(image="visits-job-runner",
                                        environment=env_variables
                                        , detach=True
                                        , name=str(license_key) + '-visits-job-runner-' + str(jobid)
                                        , network="host"
                                        , volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}}
                                        )
    return cont


def start_all_visits_jobs(docker_client, license_key, chained, no_status_change, redis_connection):
    visit_claims_data_frame, visit_jobs_count = redis_get_visit_job_status_data(redis_connection=redis_connection,
                                                                                license_key=license_key)
    pending_visit_df = visit_claims_data_frame[visit_claims_data_frame["job_status"] == "0"]

    if len(pending_visit_df) == 0:
        return True

    pending_claims = list(pending_visit_df["job_id"])
    containers = []
    visit_containers = running_containers(license_key, 'visit', docker_client)

    for job in pending_claims:
        try:
            existing_cont = [cont for cont in visit_containers if str(job) in cont.name]
            if len(existing_cont) > 0:
                continue

            print('running : ', job)
            cont = start_visit_job(
                jobid=job, license_key=license_key,
                no_status_change=no_status_change,
                docker_client=docker_client,
                chained=chained
            )
            containers.append(cont)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
    return containers


def create_visit_job(redis_connection, license_key, split_count):
    claims_data_frame = redis_get_claim_status_data(redis_connection=redis_connection, license_key=license_key)
    pending_claims_df = claims_data_frame[claims_data_frame["claim_status"] == "800"]

    if len(pending_claims_df) == 0:
        return None

    visit_claims_data_frame, visit_jobs_count = redis_get_visit_job_status_data(redis_connection=redis_connection,
                                                                                license_key=license_key)
    if visit_jobs_count == 0:
        visit_job_id = 0
    else:
        job_list = visit_claims_data_frame.values[-1].tolist()
        visit_job_id = int(job_list[0])

    number_of_claims = len(pending_claims_df)
    if number_of_claims < 100:
        split_count = 2
    if number_of_claims < 30:
        split_count = 1

    job_size = int(number_of_claims / split_count) + 1
    for i in range(split_count):

        try:
            claims_data_frame = redis_get_claim_status_data(redis_connection=redis_connection,
                                                            license_key=license_key)
            pending_claims_df = claims_data_frame[claims_data_frame["claim_status"] == "800"]

            if len(pending_claims_df) == 0:
                break

            visit_job_id = visit_job_id + 1

            redis_connection.hset('visit_job_status:' + str(license_key), str(visit_job_id), "0")

        except:
            redis_connection.hset('visit_job_status:' + str(license_key), str(visit_job_id), "100")
            print(sys.exc_info())
            continue

        count = 0
        for index, row in pending_claims_df.iterrows():
            try:
                count = count + 1
                if count >= (job_size + 1):
                    break

                claim_job_status = get_redis_existing_claim_visit_jobs(redis_connection=redis_connection,
                                                                       license_key=license_key,
                                                                       claim_id=str(row['claim_id']))

                if not claim_job_status:
                    continue
            except:
                print(sys.exc_info())
                continue

            try:
                claim_visit_status = redis_connection.hget(
                    'claim_visit:' + str(visit_job_id) + '_' + str(license_key), str(row['claim_id']))

                if claim_visit_status is not None:
                    if int(claim_visit_status) < 400:
                        continue
            except:
                print(sys.exc_info())
                continue

            try:
                redis_connection.hset('claim_visit:' + str(visit_job_id) + '_' + str(license_key),
                                      str(row['claim_id']), "0")

                is_exist_claim_visit = redis_connection.hexists(
                    'claim_visit:' + str(visit_job_id) + '_' + str(license_key), str(row['claim_id']))

                if is_exist_claim_visit:
                    redis_connection.hset('claim_status:' + str(license_key), str(row['claim_id']), 900)
                    redis_connection.hset('claims:' + str(row['claim_id']), 'integration_status', 900)

            except:
                redis_connection.hset('claim_visit:' + str(visit_job_id) + '_' + str(license_key),
                                      str(row['claim_id']), "100")
                redis_connection.hset('claim_status:' + str(license_key), str(row['claim_id']), "0")
                redis_connection.hset('claims:' + str(row['claim_id']), 'integration_status', "0")
                print(sys.exc_info())

    return True


def run_visit_stage(connection, license_key, no_redistribution, status, no_status_change=False):
    docker_client = get_docker_client()
    prune_all_containers(docker_client)

    if no_redistribution is None:
        split_count = redis_get_split_count(connection=connection, license_key=license_key)
        if status == 800:
            try:
                job_id = create_visit_job(redis_connection=connection, license_key=license_key, split_count=split_count)
            except:
                print(sys.exc_info())
        start_all_visits_jobs(redis_connection=connection, license_key=license_key, docker_client=docker_client,
                              no_status_change=no_status_change, chained="1")
