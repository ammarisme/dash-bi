import os
import sys
from hrc.redis_jobs.common import redis_get_claim_status_data, redis_get_split_count
from hrc.redis_jobs.patient.patient_controller import redis_get_patient_job_status_data, \
    get_redis_existing_claim_pat_jobs
from hrc.processing.processing import prune_all_containers, running_containers
from hrc.settings import CONFIGURATION


# start patient job runner / spin patient job runner container
def start_patient_job(license_key, jobid, templateid, docker_client, no_status_change, chained):
    docker_mode = CONFIGURATION.MODE

    if no_status_change:
        env_variables = dict({'MODE': docker_mode,
                              'JOB_ID': jobid,
                              'TEMPLATE_ID': templateid,
                              'NETWORK': 'host',
                              'NO_STATUS_CHANGE': '1',
                              "CHAINED": chained,
                              "LICENSE_KEY": license_key
                              })
    else:
        env_variables = dict({'MODE': docker_mode,
                              'JOB_ID': jobid,
                              'TEMPLATE_ID': templateid,
                              'NETWORK': 'host',
                              'NO_STATUS_CHANGE': '1',
                              "CHAINED": chained,
                              "LICENSE_KEY": license_key
                              })

    print(env_variables)
    cont = docker_client.containers.run(image="patient-job-runner", environment=env_variables, detach=True,
                                        name=str(license_key) + '-patient-job-runner-' + str(jobid),
                                        volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}})
    return cont


# start all created/pending patient jobs
def start_all_patient_jobs(docker_client, license_key, no_status_change, redis_connection, chained="0"):
    # check the pending patient claim count for this job id
    patient_claims_data_frame, patient_jobs_count = redis_get_patient_job_status_data(redis_connection=redis_connection,
                                                                                      license_key=license_key)
    pending_patient_df = patient_claims_data_frame[patient_claims_data_frame["job_status"] == "0"]

    if len(pending_patient_df) == 0:
        return True

    # get pending claim ids as a list
    pending_claims = list(pending_patient_df["job_id"])
    containers = []
    patient_containers = running_containers(license_key, 'patient', docker_client)

    # start patent job runners according to jobs
    for job in pending_claims:
        try:
            existing_cont = [cont for cont in patient_containers if str(job) in cont.name]
            if len(existing_cont) > 0:
                continue

            print('running : ', job)
            cont = start_patient_job(
                jobid=str(job), templateid='1', license_key=license_key,
                docker_client=docker_client, no_status_change=no_status_change,
                chained=chained
            )
            containers.append(cont)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            f_name = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, f_name, exc_tb.tb_lineno)
    return containers


# create patient jobs from pending patient records
def create_patient_job(redis_connection, license_key, split_count):
    # get claim status data from redis and filter pending patient claims data
    claims_data_frame = redis_get_claim_status_data(redis_connection=redis_connection, license_key=license_key)
    pending_claims_df = claims_data_frame[claims_data_frame["claim_status"] == "0"]

    if len(pending_claims_df) == 0:
        return None

    # get existing patient_job_status records for get max job id
    patient_claims_data_frame, patient_jobs_count = redis_get_patient_job_status_data(redis_connection=redis_connection,
                                                                                      license_key=license_key)
    if patient_jobs_count == 0:
        patient_job_id = 0
    else:
        job_list = patient_claims_data_frame.values[-1].tolist()
        patient_job_id = int(job_list[0])

    # change previously selected split count according to pending claim count
    if len(pending_claims_df) < 100:
        split_count = 2

    if len(pending_claims_df) < 30:
        split_count = 1

    # create patient jobs and assign claims to jobs
    job_size = int(len(pending_claims_df) / split_count) + 1
    for i in range(split_count):

        try:
            claims_data_frame = redis_get_claim_status_data(redis_connection=redis_connection,
                                                            license_key=license_key)
            pending_claims_df = claims_data_frame[claims_data_frame["claim_status"] == "0"]

            if len(pending_claims_df) == 0:
                break

            patient_job_id = patient_job_id + 1

            redis_connection.hset('patient_job_status:' + str(license_key), str(patient_job_id), "0")

        except:
            redis_connection.hset('patient_job_status:' + str(license_key), str(patient_job_id), "100")
            print(sys.exc_info())
            continue

        count = 0
        for index, row in pending_claims_df.iterrows():

            try:
                count = count + 1
                if count >= (job_size + 1):
                    break

                claim_job_status = get_redis_existing_claim_pat_jobs(redis_connection=redis_connection,
                                                                     license_key=license_key,
                                                                     claim_id=str(row['claim_id']))
                if not claim_job_status:
                    continue
            except:
                print(sys.exc_info())
                continue
            try:
                redis_connection.hset('claim_patient:' + str(patient_job_id) + '_' + str(license_key),
                                      str(row['claim_id']), "0")

                is_exist_claim_pat = redis_connection.hexists(
                    'claim_patient:' + str(patient_job_id) + '_' + str(license_key), str(row['claim_id']))

                if is_exist_claim_pat:
                    redis_connection.hset('claim_status:' + str(license_key), str(row['claim_id']), "100")
                    redis_connection.hset('claims:' + str(row['claim_id']), 'integration_status', "100")

            except:
                redis_connection.hset('claim_patient:' + str(patient_job_id) + '_' + str(license_key),
                                      str(row['claim_id']), "100")
                redis_connection.hset('claim_status:' + str(license_key), str(row['claim_id']), "0")
                redis_connection.hset('claims:' + str(row['claim_id']), 'integration_status', "0")
                print(sys.exc_info())

    return True


# Create patient jobs from newly uploaded claim data and start patient jobs
def run_patients_jobs_stage(redis_connection, docker_client, license_key, status):
    # prune/clear all the stopped docker containers
    prune_all_containers(docker_client)

    # select split count according to the peak time or not
    split_count = redis_get_split_count(connection=redis_connection, license_key=license_key)
    if status == 0:
        try:
            # create patient jobs
            create_patient_job(redis_connection=redis_connection, license_key=license_key, split_count=split_count)
        except:
            print(sys.exc_info())

    # start all the created patient jobs
    start_all_patient_jobs(docker_client=docker_client, license_key=license_key, no_status_change=False,
                           redis_connection=redis_connection, chained="1")
