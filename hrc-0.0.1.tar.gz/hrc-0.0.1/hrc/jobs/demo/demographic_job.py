import sys
import time

import sqlalchemy
from sqlalchemy import and_, func
from sqlalchemy.orm import Session

from advancedmd.processing.common import start_job
from hrc.integration_db.models import ClaimPatient, JobDemographic, ClaimDemographic, IClaim
from hrc.processing.processing import get_docker_client


def start_successor_demo_job(engine, claim_patient_job_id, license_key, token,
                             amd_url):
    demo_job_id = create_demo_job(
        engine=engine,
        claim_patient_job_id=claim_patient_job_id,
        license_key=license_key
    )
    docker_client = get_docker_client()

    patient_job_container = start_job(
        license_key=license_key,
        jobid=demo_job_id,
        image_name='demo-job-runner',
        docker_client=docker_client,
        token=token,
        amd_url=amd_url,
        no_status_change=False)


def create_demo_job(engine, claim_patient_job_id, license_key):
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        maxjobid = session.query(func.max(JobDemographic.id)).scalar()
        maxjobid = maxjobid + 1

        job_demographic = JobDemographic()
        job_demographic.LicenseKey = license_key
        job_demographic.IntegrationStatus = 0
        job_demographic.id = maxjobid

        claims = session.query(ClaimPatient). \
            filter(
            and_(
                ClaimPatient.job_patient_id == claim_patient_job_id,
                ClaimPatient.IntegrationStatus == 100
            )).all()

        claim_demographics = []
        for claim in claims:
            claim_demographic = ClaimDemographic()
            claim_demographic.IntegrationStatus = 0
            claim_demographic.LicenseKey = license_key
            claim_demographic.claimid = claim.claimid
            claim_demographic.job_demo_id = maxjobid

            claim_demographics.append(claim_demographic)
        claimids = [claim.claimid for claim in claims]

        upd = session.query(IClaim).filter(IClaim.claimid.in_(claimids)). \
            update({IClaim.IntegrationStatus: 220},
                   synchronize_session=False)

        session.add(job_demographic)
        session.add_all(claim_demographics)
        return maxjobid


def create_demo_stage(engine, license_key, split_count):
    session = Session(bind=engine)
    with session.begin(subtransactions=True):
        maxjobid = session.query(func.max(JobDemographic.id)).scalar()
        maxjobid = maxjobid + 1

        claims = session.query(IClaim). \
            filter(
            and_(
                IClaim.IntegrationStatus == 200,
                IClaim.LicenseKey == license_key
            )).all()

        number_of_claims = len(claims)
        if number_of_claims < 100:
            split_count = 2
        elif number_of_claims < 30:
            split_count = 1

        job_size = int(number_of_claims / split_count) + 1
        for i in range(split_count):
            while True:
                try:
                    query = "CALL create_demo_job(" + str(license_key) + "," \
                            + str(0) + "," \
                            + str(job_size) + ' )'
                    print(query)
                    session.execute(sqlalchemy.
                                    text(query))
                    break;
                except:
                    print(sys.exc_info())
                    time.sleep(10)

    return maxjobid

