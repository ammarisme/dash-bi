import json
import os
import sys
import time
import traceback

from advancedmd.demographics.api_models.update_patient import UpdatePatient

from hrc.jobs.demo.demographic_job import create_demo_stage
from hrc.settings import CONFIGURATION
from sqlalchemy import and_
from sqlalchemy.orm import Session
from advancedmd.common.api_models.lookup.lookup_respparty import LookupResparty
from advancedmd.demographics.api_models.add_patient import AddPatient
from advancedmd.processing.common import get_split_count
from hrc.common.database import get_mysql_connection
from hrc.integration_db.models import JobUpdatePatient, ClaimUpdatedPatient, UpdatePatientInfo
from hrc.processing.processing import get_docker_client, prune_all_containers, running_containers


def start_demo_job(license_key, jobid, templateid, intake_status, docker_client, chained):
    docker_mode = CONFIGURATION.MODE
    env_variables = dict({'MODE': docker_mode,
                          'JOB_ID': jobid,
                          'TEMPLATE_ID': templateid,
                          'NETWORK': 'host',
                          'INTAKE_STATUS': intake_status,
                          "CHAINED": chained
                          })

    print(env_variables)
    cont = docker_client.containers.run(image="demo-job-runner",
                                        environment=env_variables
                                        , detach=True
                                        , name=str(license_key) + '-demo-job-runner-' + str(jobid)
                                        , network="host"
                                        , volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}}
                                        )
    return cont


def start_all_demo_jobs(docker_client, license_key, chained, intake_status=0, sleep_time=60, engine=None):
    containers = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_demo_claims_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        cursor.close()
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)

    demo_containers = running_containers(license_key, 'demo', docker_client)

    for job in pending_claims:
        try:
            existing_cont = [cont for cont in demo_containers if str(job[0]) in cont.name]
            if len(existing_cont) > 0:
                continue

            print('running : ', job[0])
            cont = start_demo_job(
                jobid=job[0], templateid='1', license_key=job[1],
                docker_client=docker_client, intake_status=intake_status,
                chained=chained
            )
            containers.append(cont)
        except:
            print(sys.exc_info())
    return containers


def add_patient(authorization, fclassid, name, dob,
                gender, relationship, chart,
                hipaarelationship, city, state, zip,
                address1, address2, homephone, officephone, email,
                insorder, employer, maritalstatus, ssn, profileid):
    homephone = "" if homephone is None else homephone
    officephone = "" if officephone is None else officephone
    email = "" if email is None else email
    address2 = "" if address2 is None else address2
    address1 = "" if address1 is None else address1

    title = "MR" if gender.lower() == "M" else "MISS"
    respparty_name = 'SELF'
    resppartyid = ''
    responsible_party_exist = False
    while True:
        addPatient = AddPatient(
            fclassid=fclassid, name=name, dob=dob,
            gender=gender, title=title, relationship=relationship, chart=chart,
            hipaarelationship=hipaarelationship, profileid=profileid, city=city, state=state, zip=zip,
            address1=address1, address2=address2, homephone=homephone, officephone=officephone, email=email,
            insorder=insorder, employer=employer, maritalstatus=maritalstatus, ssn=ssn, respparty_name=respparty_name,
            resppartyid=resppartyid
        )
        request, response = addPatient.request(authorization)
        response = json.loads(response.content.decode('utf8'))

        if response['PPMDResults']['Error'] is not None \
                and response["PPMDResults"]["Results"]['@success'] == '0':
            print('name : ', name)
            print('dob : ', dob)
            fault = response["PPMDResults"]['Error']['Fault']
            if 'faultcode' in fault:
                print('faultcode: ', response["PPMDResults"]['Error']['Fault']['faultcode'])

            if 'faultstring' in fault:
                print('faultstring: ', response["PPMDResults"]['Error']['Fault']['faultstring'])

            if 'method' in fault:
                print('method: ', response["PPMDResults"]['Error']['Fault']['detail']['method'])

            if 'description' in fault:
                print('description: ', response["PPMDResults"]['Error']['Fault']['detail']['description'])

            if 'detail' in fault and 'code' in fault['detail']:
                responsible_party_exist = fault['detail']['code'] == '-2147217302'
                if responsible_party_exist:
                    # lookup the responsible party and add that as the responsible party id
                    request, response, respparty, resppartyid = LookupResparty.get_lookupid(authorization,
                                                                                            LookupResparty.get_lookup_payload(
                                                                                                name=name),
                                                                                            lookup_type="respparty")
                    respparty_name = name
                    resppartyid = resppartyid
                    hipaarelationship = "G8"

                    continue

        elif response['PPMDResults']['Error'] is not None:
            print(response['PPMDResults']['Error'])
            request, response, None

        if 'patientlist' in response["PPMDResults"]["Results"]:
            patientid = response["PPMDResults"]["Results"]["patientlist"]["patient"]["@id"]
        else:
            patientid = None

        return request, response, patientid


def run_demo_stage(engine, license_key, token, url,status,
                   no_redistribution="0", intake_status=None, dont_start=False):
    try:
        docker_client = get_docker_client()
        prune_all_containers(docker_client)

        split_count = get_split_count(engine=engine, license_key=license_key)
        if status == 200:
            try:
                demo_job_id = create_demo_stage(engine, license_key, split_count)
            except:
                print(sys.exc_info())

        start_all_demo_jobs(engine=engine, license_key=license_key,
                            docker_client=docker_client, intake_status=intake_status, chained="1")
        engine.dispose()
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        print(sys.exc_info())
        engine.dispose()


class PatientResponse():
    def __init__(self, patient, patientid, claimid, time, license_key):
        self.patientid = patientid
        self.patient = patient
        self.claimid = claimid
        self.license_key = license_key
        self.time = time


class DemoResponse():
    def __init__(self, demographics, patientid, claimid, time, license_key):
        self.patientid = patientid
        self.demographics = demographics
        self.claimid = claimid
        self.license_key = license_key
        self.createdAt = time


def update_patient(authorization, patient_id, old_sex=None, sex=None, old_title=None, old_ssn=None, title=None,
                   ssn=None, insorder=None, o_insorder=None):
    if sex is not None:
        title = "MR" if sex.lower() == "M" else "MISS"
    update_patient = UpdatePatient(
        patient_id=patient_id,
        old_sex=old_sex, sex=sex, old_title=old_title,
        old_ssn=old_ssn, ssn=ssn, insorder=insorder, o_insorder=o_insorder,
        title=title
    )
    request, response = update_patient.request(authorization)
    response = json.loads(response.content.decode('utf8'))

    if response['PPMDResults']['Error'] is not None \
            and response["PPMDResults"]["Results"] is None:
        fault = response["PPMDResults"]['Error']['Fault']

        faultcode, faultstring, method, description = None, None, None, None
        if 'detail' in fault and 'faultcode' in fault:
            faultcode = fault['detail']['code']
            print('faultcode: ', faultcode)

        if 'faultstring' in fault:
            print('faultstring: ', response["PPMDResults"]['Error']['Fault']['faultstring'])

        if 'detail' in fault and 'method' in fault['detail']:
            print('method: ', response["PPMDResults"]['Error']['Fault']['detail']['method'])

        if 'detail' in fault and 'description' in fault['detail']:
            print('description: ', response["PPMDResults"]['Error']['Fault']['detail']['description'])
        if faultcode == '-2147217398':
            return 1

    elif response['PPMDResults']['Error'] is not None:
        print(response['PPMDResults']['Error'])
        return 0
    else:
        return 2


def update_patients_bulk(authorization, job_id, license_key):
    engine = get_mysql_connection()
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        db_demo_job = session.query(JobUpdatePatient).filter(JobUpdatePatient.id == job_id).first()
        if db_demo_job is None:
            print('Response : No demo_job entry found')
            return 1
        update_pending_patients = session.query(
            ClaimUpdatedPatient, UpdatePatientInfo) \
            .join(UpdatePatientInfo) \
            .filter(and_(UpdatePatientInfo.LicenseKey == license_key,
                         ClaimUpdatedPatient.IntegrationStatus == 0,
                         UpdatePatientInfo.IntegrationStatus == 100,
                         ClaimUpdatedPatient.job_id == job_id)).all()

    if update_pending_patients is None or len(update_pending_patients) == 0:
        print('Response : No pending update patients found')
        return 1

    for claim in update_pending_patients:
        update_patient_info = claim.UpdatePatientInfo
        update_patient_info_id = update_patient_info.id
        if update_patient_info.amd_patientid is None:
            patient_updated(engine, update_patient_info_id, success_status=3)
            continue
        try:
            success = update_patient(authorization=authorization,
                                     patient_id=update_patient_info.amd_patientid,
                                     old_sex='U',
                                     sex=update_patient_info.gender,
                                     old_title='MISS',
                                     old_ssn='',
                                     ssn='')
            # success = get_demographic_of_patient(
            #     authorization=authorization, claimid=claimid, patientid=patientid,
            #     demographics_mongo=demographics_mongo, license_key=license_key, lag=lag
            # )

            if success in [1, 2]:
                patient_updated(engine, update_patient_info_id, success_status=success)

        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            traceback.print_exc()

    return True


def patient_updated(engine, update_patient_info_id, success_status):
    session = Session(bind=engine, autocommit=True)
    with session.begin():
        success_status = (success_status + 1) * 100
        upd_claimpatient = session.query(ClaimUpdatedPatient). \
            filter(ClaimUpdatedPatient.id == update_patient_info_id) \
            .update({ClaimUpdatedPatient.IntegrationStatus: 100}, synchronize_session=False)

        upd_claim = session.query(UpdatePatientInfo). \
            filter(UpdatePatientInfo.id == update_patient_info_id) \
            .update({UpdatePatientInfo.IntegrationStatus: success_status}, synchronize_session=False)
