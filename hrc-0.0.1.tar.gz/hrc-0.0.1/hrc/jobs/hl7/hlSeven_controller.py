import sys
import traceback

from hrc.processing.processing import prune_all_containers
from hrc.settings import CONFIGURATION


def start_hl_integration(license_key, docker_client):
    try:
        docker_mode = CONFIGURATION.MODE
        prune_all_containers(docker_client)
        env_variables = dict({'MODE': docker_mode,
                              'NETWORK': 'host',
                              'LICENSE_KEY': license_key
                              })
        cont = docker_client.containers.run(image="hl7-integration",
                                            environment=env_variables
                                            , detach=True
                                            , name=str(license_key) + '-hl7-job-runner')

        return cont
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(e, exc_type, exc_tb.tb_lineno)
        traceback.print_exc()
        return None
