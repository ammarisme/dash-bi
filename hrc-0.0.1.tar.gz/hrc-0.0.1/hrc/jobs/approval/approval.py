import os
import sys
import time

import sqlalchemy
from hrc.common.database import get_mysql_connection
from hrc.integration_db.models import JobApproval, IClaim, ClaimApprovals, CompletedClaims
from hrc.processing.processing import get_docker_client, prune_all_containers
from hrc.settings import CONFIGURATION
from sqlalchemy import func, and_
from sqlalchemy.orm import Session

from advancedmd.processing.common import get_split_count


def start_approval_job(license_key, jobid, docker_client):
    docker_mode = CONFIGURATION.MODE

    env_variables = dict({'MODE': docker_mode,
                          'JOB_ID': jobid,
                          'NETWORK': 'host',
                          'LICENSE_KEY': license_key
                          })
    print(env_variables)
    cont = docker_client.containers.run(image="approval-job-runner",
                                        environment=env_variables
                                        , detach=True
                                        , name=str(license_key) + '-approval-job-runner-' + str(jobid)
                                        , network="host"
                                        , volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}}
                                        )
    return cont


def start_all_approval_jobs(docker_client, license_key, engine):
    containers = []
    print('containers')
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_claim_approvals_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
        cursor.close()
        connection.close()

    for job in pending_claims:
        try:
            print('running : ', job[0])
            cont = start_approval_job(
                jobid=job[0], license_key=job[1],
                docker_client=docker_client
            )
            containers.append(cont)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(sys.exc_info(), fname, exc_tb.tb_lineno)

    return containers


def create_approval_job(engine, split_count, license_key):
    claim_ids = []
    maxjobid = None
    try:
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("get_claims_to_auto_approve", [license_key])
        claim_ids = list(cursor.fetchall())
        claim_ids = sorted(claim_ids, key=lambda tup: tup[0])
        cursor.close()
        connection.close()
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        print(sys.exc_info())

    try:
        session = Session(autocommit=True, bind=engine, expire_on_commit=False)
        with session.begin():

            maxjobid = session.query(func.max(JobApproval.job_approval_id)).scalar()
            if maxjobid is None:
                maxjobid = 0
            maxjobid = maxjobid + 1

            claims = session.query(CompletedClaims).filter(
                and_(CompletedClaims.IntegrationStatus == 1000, CompletedClaims.LicenseKey == license_key,
                                                       CompletedClaims.claimid.in_(claim_ids))).all()

            if len(claims) < 100:
                split_count = 2

            job_size = int(len(claims) / split_count) + 1

            if len(claims) == 0:
                print('No pending records found for approval ')
            else:
                for i in range(split_count):
                    while True:
                        try:
                            query = "CALL create_approval_job(" + str(license_key) + "," \
                                    + str(0) + "," \
                                    + str(job_size) + ' )'
                            print(query)
                            session.execute(sqlalchemy.text(query))
                            break
                        except:
                            print(sys.exc_info())
                            time.sleep(10)
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        print(sys.exc_info())

    return maxjobid


def stop_all_approval_containers(docker_client, license_key):
    containers = docker_client.containers.list()
    number_of_containers = len(containers)
    print("Currently running :", number_of_containers)
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-approval-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            container.kill()

    return number_of_containers


def run_approval_stage(license_key, engine, docker_client, status):
    # stop
    stop_all_approval_containers(docker_client=docker_client, license_key=license_key)
    prune_all_containers(docker_client)

    # put all pending claims on the job
    split_count = get_split_count(license_key=license_key, engine=engine)

    if status == 1000:
        try:
            create_approval_job(engine=engine, license_key=license_key, split_count=split_count)
        except:
            print(sys.exc_info())
    start_all_approval_jobs(engine=engine, license_key=license_key, docker_client=docker_client)

    engine.dispose()
