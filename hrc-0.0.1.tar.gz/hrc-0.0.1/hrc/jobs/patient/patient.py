import sys

from advancedmd.processing.common import get_split_count
from hrc.jobs.patient.patient_controller import create_patient_job, start_all_patient_jobs
from hrc.processing.processing import prune_all_containers
from hrc.services import logging_service

logging = logging_service('patient')


def run_patients_jobs_stage(engine, docker_client, license_key, status):
    prune_all_containers(docker_client)
    split_count = get_split_count(engine=engine, license_key=license_key)
    if status == 0:
        try:
            create_patient_job(engine=engine, license_key=license_key, split_count=split_count)
        except Exception as e:
            logging.error('[{}][{}]'.format(license_key, e))
            print(sys.exc_info())
    start_all_patient_jobs(engine=engine, license_key=license_key, sleep_time=0, docker_client=docker_client,
                           no_status_change=False, chained="1")
