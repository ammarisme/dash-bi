import os
import sys
import sqlalchemy
from sqlalchemy import and_, func
from sqlalchemy.orm import Session

from django.http import HttpResponseServerError
from hrc.processing.patient import create_update_patient_stage
from hrc.processing.processing import running_containers
from hrc.common.database import get_mysql_connection, get_mongo_connection
from hrc.controllers.demographics_job import stop_all_demojob_containers, start_all_demo_jobs
from hrc.integration_db.models import JobPatient, ClaimPatient, IClaim, PtPatientinfoDummy, MfPatient
from hrc.processing.processing import get_docker_client, prune_all_containers
from hrc.settings import CONFIGURATION
from advancedmd.processing.demographics.demographic_job import create_demo_stage
from hrc.services import logging_service


logging = logging_service('patient')


def run_update_patient_stage(engine, license_key, no_redistribution, dont_start):
    try:
        split_count = 4
        # create the demo job
        # split_count = get_split_count(license_key)

        docker_client = get_docker_client()
        prune_all_containers(docker_client)

        if no_redistribution is False:
            create_update_patient_stage(engine, license_key, split_count)
        engine.dispose()
    except Exception as e:
        engine.dispose()
        exc_info = sys.exc_info()
        print(exc_info)
        logging.error('[{}][{}]'.format(license_key, e))
        return HttpResponseServerError(exc_info)


def create_patient_job(engine, license_key, split_count):
    session = Session(bind=engine)
    with session.begin(subtransactions=True):
        claims = session.query(IClaim). \
            filter(
            and_(
                IClaim.IntegrationStatus == 0,
                IClaim.LicenseKey == license_key
            )).all()

        if len(claims) < 100:
            split_count = 2

        job_size = int(len(claims) / split_count) + 1
        for i in range(split_count):
            query = "CALL create_patient_job(" + str(license_key) + "," \
                    + str(0) + "," \
                    + str(job_size) + ' )'
            print(query)
            session.execute(sqlalchemy.text(query))
    return 0


def stop_all_patient_job_containers(docker_client, license_key):
    containers = docker_client.containers.list()
    number_of_containers = len(containers)
    print("Currently running :", number_of_containers)
    logging.info('[{}][Currently running : {}]'.format(license_key, number_of_containers))
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-patient-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            logging.info('[{}][Stopping : {}]'.format(license_key, container.image.tags[0]))
            container.kill()

    return number_of_containers


def start_all_patient_jobs(docker_client, license_key, no_status_change, sleep_time=60, engine=None,chained="0"):
    containers = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_patient_claims_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
        patient_containers = running_containers(license_key, 'patient', docker_client)
        cursor.close()
        connection.close()

    for job in pending_claims:
        try:
            existing_cont = [cont for cont in patient_containers if str(job[0]) in cont.name]
            if len(existing_cont) > 0:
                continue

            print('running : ', job[0])
            logging.info('[{}][Running : {}]'.format(license_key, job[0]))
            cont = start_patient_job(
                jobid=job[0], templateid='1', license_key=job[1],
                docker_client=docker_client, no_status_change=no_status_change,
                chained=chained
            )
            containers.append(cont)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            logging.error('[{}][{}]'.format(license_key, e))
    return containers


def start_patient_job(license_key, jobid, templateid, docker_client, no_status_change, chained):
    docker_mode = CONFIGURATION.MODE

    if no_status_change:
        env_variables = dict({'MODE': docker_mode, 'JOB_ID': jobid, 'TEMPLATE_ID': templateid,  'NETWORK': 'host',
                              'NO_STATUS_CHANGE': '1', "CHAINED": chained})
    else:
        env_variables = dict({'MODE': docker_mode, 'JOB_ID': jobid, 'TEMPLATE_ID': templateid, 'NETWORK': 'host',
                              'NO_STATUS_CHANGE': '1', "CHAINED": chained})

    logging.info('[{}][{}][{}][Docker starting]'.format(license_key, jobid, env_variables))
    cont = docker_client.containers.run(image="patient-job-runner", environment=env_variables, detach=True,
                                        name=str(license_key) + '-patient-job-runner-' + str(jobid),
                                        volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}})

    return cont


def run_demo_stage(license_key, no_redistribution, intake_status, dont_start):
    engine = get_mysql_connection()

    # create the demo job
    create_demo_stage(engine, license_key, 2)

    docker_client = get_docker_client()
    # stop
    stop_all_demojob_containers(docker_client=docker_client, license_key=license_key)
    prune_all_containers(docker_client)
    logging.info('[{}][Prune dockers]'.format(license_key))
    # start
    if dont_start is False:
        start_all_demo_jobs(engine=engine, license_key=license_key, docker_client=docker_client,
                            intake_status=intake_status, chained="1")
