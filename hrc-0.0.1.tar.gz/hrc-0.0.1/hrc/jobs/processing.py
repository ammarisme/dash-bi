import sys

from advancedmd.license_key import get_license_key_dt
from advancedmd.common.user import AMDUser
from advancedmd.batch import create_batch
from hrc.jobs.approval.approval import run_approval_stage
from hrc.jobs.cpt.cpt import run_cpt_stage
from hrc.jobs.demo.patient import run_demo_stage
from hrc.jobs.insurance.eligibility import run_eligibility_stage
from hrc.jobs.insurance.insurance import run_insurance_stage
from hrc.jobs.visit.visit import run_visit_stage
from hrc.processing.job import get_pending_patient_jobs, get_pending_demo_jobs, get_pending_insurance_jobs, \
    get_pending_cpt_jobs, get_pending_approval_jobs
from hrc.common.database import get_mysql_connection
from hrc.processing.processing import get_docker_client
from advancedmd.processing.cpt.cpt import start_successor_cpt_job
from advancedmd.processing.eligibility.eligibility import start_successor_eligibility_job
from advancedmd.processing.insurance.insurance import start_successor_insurance_job
from advancedmd.processing.demographics.demographic_job import start_successor_demo_job
from advancedmd.processing.visit.visit import start_successor_visit_job
from hrc.settings import CONFIGURATION


def running_containers(license_key, container_type):
    docker_client = get_docker_client()
    containers = docker_client.containers.list()
    conts = [cont for cont in containers if (container_type in cont.name) and (str(license_key) in cont.name)]
    return conts


def start_next_stage(engine, previous_stage, license_key, status):
    docker_client = get_docker_client()
    docker_client.containers.prune()
    containers = docker_client.containers.list()

    if previous_stage == '200':
        patient_containers = running_containers(license_key, 'patient')
        pending_jobs = get_pending_patient_jobs(engine=engine, license_key=license_key)
        if len(pending_jobs) == 0 or len(patient_containers) <= 1:
            authorization = authorize(license_key, engine)
            run_demo_stage(engine=engine,
                           license_key=license_key,
                           token=authorization.token, url=authorization.url, status=status)
            print('demo stage started : ')
        else:
            print('there are already patients jobs')
    elif previous_stage == '230':
        demo_containers = running_containers(license_key, 'demo')
        pending_jobs = get_pending_demo_jobs(engine=engine, license_key=license_key)
        if len(pending_jobs) == 0 or len(demo_containers) <= 1:
            authorization = authorize(license_key, engine)
            run_insurance_stage(engine=engine,
                                license_key=license_key,
                                no_redistribution=None, no_status_change=False,
                                token=authorization.token, url=authorization.url, status=status)
            print('insurance stage started : ')
        else:
            print('there are already demo jobs')
    elif previous_stage == '400':
        insurance_conts = running_containers(license_key, 'insurance')
        pending_jobs = get_pending_insurance_jobs(engine=engine, license_key=license_key)
        if len(pending_jobs) == 0 or len(insurance_conts) <= 1:
            authorization = authorize(license_key, engine)
            run_eligibility_stage(engine=engine,
                                  license_key=license_key,
                                  no_redistribution=None, no_status_change=False,
                                  token=authorization.token, url=authorization.url, status=status
                                  )
            print('eligibility stage started : ')
        else:
            print('there are already insurance jobs')
    elif previous_stage == '600':
        eligibility_conts = running_containers(license_key, 'eliibility')
        pending_insurance_jobs = get_pending_insurance_jobs(engine=engine, license_key=license_key)
        if len(pending_insurance_jobs) == 0 or len(eligibility_conts) <= 1:
            authorization = authorize(license_key, engine)
            run_cpt_stage(engine=engine,
                          license_key=license_key,
                          token=authorization.token, url=authorization.url,
                          no_redistribution=None, no_status_change=False, status=status)
            print('cpt stage started : ')
        else:
            print('there are already insurance jobs')
    elif previous_stage == '800':
        cpt_containers = running_containers(license_key, 'cpt')
        pending_jobs = get_pending_cpt_jobs(engine=engine, license_key=license_key)
        if len(pending_jobs) == 0 or len(cpt_containers) <= 1:
            authorization = authorize(license_key, engine)
            token = CONFIGURATION.OPS_USER_TOKEN
            create_batch(token, license_key, engine=engine)
            run_visit_stage(license_key=license_key,
                            token=authorization.token, url=authorization.url,
                            no_redistribution=None, no_status_change=False, status=status)
            print('visit stage started : ')
        else:
            print('there are already visit jobs')

    elif previous_stage == '1000':

        visit_approval_containers = running_containers(license_key, 'approval')
        pending_jobs = get_pending_approval_jobs(engine=engine, license_key=license_key)

        if len(pending_jobs) == 0 or len(visit_approval_containers) <= 1:
            run_approval_stage(license_key=license_key, no_redistribution=None)
            print('approval stage started : ')
        else:
            print('there are already approval jobs')

    else:
        print('no suitable next stage found')


def authorize(license_key, engine):
    authorization = AMDUser()
    license_key_dt = get_license_key_dt(license_key, engine)
    authorization.login_to_amd_api(license_key, op_user="",
                                   api_password=license_key_dt.api_password,
                                   api_user=license_key_dt.api_username,
                                   api_appname=license_key_dt.api_appname,
                                   force=False,
                                   engine=engine
                                   )
    return authorization


def job_completed(previous_stage, license_key, job_id, status):
    try:
        engine = get_mysql_connection()
        start_next_stage(engine, previous_stage, license_key, status)
        engine.dispose()
    except:
        engine.dispose()
        exc_info = sys.exc_info()
        print(exc_info)
        return False
    return True;


def start_successor_job(engine, previous_stage, job_id, license_key, token, amd_url):
    print('AMD_URL: ', amd_url)
    print('TOKEN: ', token)
    if previous_stage == '0':  # patients done
        start_successor_demo_job(
            engine=engine,
            claim_patient_job_id=job_id,
            license_key=license_key,
            token=token,
            amd_url=amd_url
        )
        print('demo job starting : ', job_id)
    elif previous_stage == '230':  # demographics done
        start_successor_insurance_job(
            engine=engine,
            claim_demo_job_id=job_id,
            license_key=license_key,
            token=token,
            amd_url=amd_url
        )
        print('insurance job starting : ', job_id)
    elif previous_stage == '400':  # insurance done
        start_successor_eligibility_job(
            engine=engine,
            claim_insurance_job_id=job_id,
            license_key=license_key,
            token=token,
            amd_url=amd_url
        )
        print('eligibility job starting : ', job_id)
    elif previous_stage == '600':  # eligibility done
        start_successor_cpt_job(
            engine=engine,
            claim_eligibility_job_id=job_id,
            license_key=license_key,
            token=token,
            amd_url=amd_url
        )
        print('cpt job starting : ', job_id)
    elif previous_stage == '800':  # cpts done
        start_successor_visit_job(
            engine=engine,
            claim_cpt_job_id=job_id,
            license_key=license_key,
            token=token,
            amd_url=amd_url
        )
        print('visit job starting : ', job_id)
    else:
        print('no suitable next stage found')
