import os
import sys
import time
import sqlalchemy

from hrc.settings import CONFIGURATION
from sqlalchemy import and_, func
from sqlalchemy.orm import Session
from advancedmd.processing.common import start_job, get_split_count
from hrc.common.database import get_mysql_connection
from hrc.integration_db.models import IClaim, JobVisit, ClaimVisit
from hrc.processing.processing import get_docker_client, prune_all_containers, running_containers
from hrc.services import logging_service

logging = logging_service('visit')


def start_successor_visit_job(engine, claim_cpt_job_id, license_key, token, amd_url):
    demo_job_id = create_visit_job(
        engine=engine,
        claim_cpt_job_id=claim_cpt_job_id,
        license_key=license_key
    )
    docker_client = get_docker_client()

    start_job(
        license_key=license_key,
        jobid=demo_job_id,
        image_name='visits-job-runner',
        docker_client=docker_client,
        token=token,
        amd_url=amd_url,
        no_status_change=False)


def create_visit_job(engine, license_key, split_count):
    logging.info('[{}][Create visit job]'.format(license_key))
    session = Session(bind=engine)
    with session.begin(subtransactions=True):
        claims = session.query(IClaim). \
            filter(
            and_(
                IClaim.IntegrationStatus == 800,
                IClaim.LicenseKey == license_key
            )).all()
        number_of_claims = len(claims)
        if number_of_claims < 100:
            split_count = 2
        elif number_of_claims < 30:
            split_count = 1

        job_size = int(number_of_claims / split_count) + 1
        for i in range(split_count):
            while True:
                try:
                    query = "CALL create_visit_job(" + str(license_key) + "," \
                            + str(0) + "," + str(job_size) + ' )'
                    print(query)
                    session.execute(sqlalchemy.text(query))
                    break
                except Exception as e:
                    logging.error('[{}][{}]'.format(license_key, e))
                    time.sleep(10)
    return 0


def run_visit_stage(license_key, token, url, no_redistribution, status, no_status_change=False):
    engine = get_mysql_connection()
    docker_client = get_docker_client()
    prune_all_containers(docker_client)

    logging.info('[{}][Run visit stage]'.format(license_key))
    # put all pending claims on the job
    if no_redistribution is None:
        # create the eligibility job
        split_count = get_split_count(engine=engine, license_key=license_key)
        if status == 800:
            try:
                create_visit_job(engine=engine, license_key=license_key, split_count=split_count)
            except Exception as e:
                logging.error('[{}][{}]'.format(license_key, e))

        start_all_visits_jobs(engine=engine, license_key=license_key, docker_client=docker_client,
                              no_status_change=no_status_change, chained="1")


#
#
# def create_visit_job(engine, license_key):
#     session = Session(bind=engine, expire_on_commit=False, autocommit=True)
#     with session.begin():
#         job = JobVisit()
#         job.IntegrationStatus = 0
#         job.LicenseKey = license_key
#         session.add(job)
#
#     session = Session(bind=engine, expire_on_commit=False, autocommit=True)
#     with session.begin():
#         job_demo_id = session.query(func.max(JobVisit.job_visit_id)).scalar()
#         return job_demo_id

# return None


def accumulate_all_pending_claim_visits(license_key, job_id, engine, no_status_change=False):
    session = Session(bind=engine, expire_on_commit=False, autocommit=True)
    with session.begin():
        pending_claims = session.query(IClaim).filter(
            and_(
                IClaim.LicenseKey == license_key,
                IClaim.IntegrationStatus == 800
            )).all()
        claims = []
        for claim in pending_claims:
            claim_ins = ClaimVisit()
            claim_ins.IntegrationStatus = 0
            claim_ins.LicenseKey = license_key
            claim_ins.claimid = claim.claimid
            claim_ins.job_visit_id = job_id

            claims.append(claim_ins)
        session.add_all(claims)

        if not no_status_change:
            claimids = [claim.claimid for claim in pending_claims]
            session.query(IClaim).filter(IClaim.claimid.in_(claimids)) \
                .update({IClaim.IntegrationStatus: 900}, synchronize_session=False)


def redistribute_claims_of_visit_job(split_into, job_id, license_key, engine=None):
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        max_jobid = session.query(func.max(JobVisit.job_visit_id)).scalar()
        for i in range(split_into):
            jobid = max_jobid + i + 1
            job = JobVisit(
                LicenseKey=license_key,
                job_visit_id=jobid,
                IntegrationStatus=0,
                ParentJob=job_id
            )
            session.add(job)

    session = Session(autocommit=True, bind=engine)
    with session.begin():
        pending_claims = session.query(ClaimVisit).filter(ClaimVisit.job_visit_id == job_id).all()
        claimids = [claim.claimid for claim in pending_claims]

        for i in range(split_into):
            jobid = max_jobid + i + 1
            start = 1 + int(len(claimids) / split_into) * i
            end = (i + 1) * int(len(claimids) / split_into)
            setclaims = claimids[start:end]
            setclaims = tuple(setclaims)
            session.query(ClaimVisit).filter(ClaimVisit.claimid.in_(setclaims)) \
                .update({ClaimVisit.job_visit_id: jobid}, synchronize_session=False)


def stop_all_visit_containers(docker_client, license_key):
    containers = docker_client.containers.list()
    number_of_containers = len(containers)
    logging.info('[{}][Currently running: {}]'.format(license_key, number_of_containers))
    print("Currently running :", number_of_containers)
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-visit-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            logging.info('[{}][stopping: {}]'.format(license_key, container.image.tags[0]))
            container.kill()

    return number_of_containers


def start_all_visits_jobs(docker_client, license_key, chained, no_status_change=False, sleep_time=60, engine=None):
    containers = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_claim_visits_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
        cursor.close()
        connection.close()

    visit_containers = running_containers(license_key, 'visit', docker_client)
    for job in pending_claims:
        try:
            existing_cont = [cont for cont in visit_containers if str(job[0]) in cont.name]
            if len(existing_cont) > 0:
                continue

            logging.info('[{}][running: {}]'.format(license_key, job[0]))
            print('running : ', job[0])
            cont = start_visit_job(
                jobid=job[0], license_key=job[1],
                no_status_change=no_status_change,
                docker_client=docker_client,
                chained=chained
            )
            containers.append(cont)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            logging.error('[{}][{}][{}]'.format(license_key, job, e))
    return containers


def start_visit_job(license_key, jobid, docker_client, chained, no_status_change=False):
    docker_mode = CONFIGURATION.MODE

    if no_status_change:
        env_variables = dict({'MODE': docker_mode,
                              'JOB_ID': jobid,
                              'NETWORK': 'host',
                              'NO_STATUS_CHANGE': '1',
                              "CHAINED": "1"
                              })
    else:
        env_variables = dict({'MODE': docker_mode,
                              'JOB_ID': jobid,
                              'NETWORK': 'host',
                              "CHAINED": "1"
                              })
    print(env_variables)
    logging.info('[{}][{}][Start visit job]'.format(license_key, jobid))
    cont = docker_client.containers.run(image="visits-job-runner", environment=env_variables, detach=True,
                                        name=str(license_key) + '-visits-job-runner-' + str(jobid), network="host",
                                        volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}})
    return cont
