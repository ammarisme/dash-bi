import os
import sys
import time
import traceback
import sqlalchemy
from hrc.settings import CONFIGURATION
from sqlalchemy import and_
from hrc.integration_db.models import ClaimOccurance
from sqlalchemy.orm import Session
from hrc.processing.processing import prune_all_containers, running_containers
from advancedmd.processing.common import get_split_count


def start_cse_job(license_key, jobid, docker_client):
    docker_mode = CONFIGURATION.MODE
    env_variables = dict({'MODE': docker_mode,
                          'JOB_ID': jobid,
                          'NETWORK': 'host',
                          "LICENSE_KEY": license_key
                          })
    print(env_variables)
    cont = docker_client.containers.run(image="cse-job-runner",
                                        environment=env_variables
                                        , detach=True
                                        , name=str(license_key) + '-cse-job-runner-' + str(jobid)
                                        , network="host"
                                        , volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}}
                                        )
    return cont


def start_all_cse_jobs(docker_client, license_key, engine):
    containers = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    connection = engine.raw_connection()
    with session.begin():
        cursor = connection.cursor()
        cursor.callproc("pending_claim_cse_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
        cursor.close()
        connection.close()

    cpt_containers = running_containers(license_key, 'cpt', docker_client)

    for job in pending_claims:
        try:
            existing_cont = [cont for cont in cpt_containers if str(job[0]) in cont.name]
            if len(existing_cont) > 0:
                continue

            print('running : ', job[0])
            cont = start_cse_job(
                jobid=job[0], license_key=job[1],
                docker_client=docker_client
            )
            containers.append(cont)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)

    return containers


def create_cse_job(engine, license_key, pending_claims):
    try:
        session = Session(autocommit=True, bind=engine, expire_on_commit=False)
        with session.begin(subtransactions=True):

            if (len(pending_claims)) > 100:
                split_count = get_split_count(engine=engine, license_key=license_key)
            else:
                split_count = 1

                number_of_claims = len(pending_claims)
                if number_of_claims < 100:
                    split_count = 2
                elif number_of_claims < 30:
                    split_count = 1

                job_size = int(number_of_claims / split_count) + 1

                for i in range(split_count):
                    while True:
                        try:
                            query = "CALL create_cse_job(" + str(license_key) + "," \
                                    + str(0) + "," \
                                    + str(job_size) + ' )'
                            print(query)
                            session.execute(sqlalchemy.
                                            text(query))
                            break
                        except:
                            print(sys.exc_info())
                            time.sleep(10)
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)

    return 0

def stop_all_cse_job_containers(docker_client, license_key):

    containers = docker_client.containers.list()
    number_of_containers = len(containers)

    print("Currently running :", number_of_containers)
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-cse-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            container.kill()

    return number_of_containers


def run_cse_stage(engine, docker_client, license_key):
    conts = None
    try:
        stop_all_cse_job_containers(docker_client=docker_client, license_key=license_key)
        prune_all_containers(docker_client)

        session = Session(autocommit=True, bind=engine, expire_on_commit=False)
        with session.begin():
            pending_claims = session.query(ClaimOccurance). \
                filter(
                and_(
                    ClaimOccurance.status == 0,
                    ClaimOccurance.license_key == license_key
                )).all()
        if (len(pending_claims)) == 0:
            print('pending claim occurrences data not found')
        else:
            cse_job_id = create_cse_job(engine=engine, license_key=license_key, pending_claims=pending_claims)
            conts = start_all_cse_jobs(engine=engine, license_key=license_key, docker_client=docker_client)

        return conts
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        traceback.print_exc()
        return None
