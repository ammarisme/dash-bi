import os
import sys
import time

import sqlalchemy
from sqlalchemy import func, and_
from sqlalchemy.orm import Session
from advancedmd.processing.common import get_split_count
from hrc.integration_db.models import IClaim, JobEligibility, ClaimEligibility
from hrc.processing.processing import get_docker_client, prune_all_containers, running_containers
from hrc.settings import CONFIGURATION
from hrc.services import logging_service

logging = logging_service('eligibility')


def create_eligibility_job(engine, license_key, split_count):
    session = Session(bind=engine)
    with session.begin(subtransactions=True):
        maxjobid = session.query(func.max(JobEligibility.job_eligibility_id)).scalar()
        maxjobid = maxjobid + 1

        claims = session.query(IClaim). \
            filter(
            and_(
                IClaim.IntegrationStatus == 400
            )).all()

        number_of_claims = len(claims)
        if number_of_claims < 100:
            split_count = 2
        elif number_of_claims < 30:
            split_count = 1

        job_size = int(number_of_claims / split_count) + 1

        for i in range(split_count):
            while True:
                try:
                    query = "CALL create_eligibility_job(" + str(license_key) + "," \
                            + str(0) + "," + str(job_size) + ' )'
                    print(query)
                    session.execute(sqlalchemy. text(query))
                    break
                except Exception as e:
                    print(sys.exc_info())
                    logging.error('[{}][{}]'.format(license_key, e))
                    time.sleep(10)

    return maxjobid


def accumulate_all_pending_eligibility_claims(license_key, job_id, engine):
    session = Session(bind=engine, expire_on_commit=False, autocommit=True)
    pending_claims = session.query(IClaim).filter(
        and_(
            IClaim.LicenseKey == license_key,
            IClaim.IntegrationStatus == 400
        )).all()
    with session.begin():
        claims = []
        for claim in pending_claims:
            claim_eligibility = ClaimEligibility()
            claim_eligibility.IntegrationStatus = 0
            claim_eligibility.LicenseKey = license_key
            claim_eligibility.claimid = claim.claimid
            claim_eligibility.job_eligibility_id = job_id

            claims.append(claim_eligibility)
        session.add_all(claims)

        claimids = [claim.claimid for claim in pending_claims]
        session.query(IClaim).filter(IClaim.claimid.in_(claimids)).update({IClaim.IntegrationStatus: 500},
                                                                          synchronize_session=False)


def redistribute_claims_of_eligiilitty_job(split_into, job_id, license_key, engine=None):
    session = Session(autocommit=True, bind=engine)
    with session.begin():
        max_jobid = session.query(func.max(JobEligibility.job_eligibility_id)).scalar()
        for i in range(split_into):
            jobid = max_jobid + i + 1
            job = JobEligibility(
                LicenseKey=license_key,
                job_eligibility_id=jobid,
                IntegrationStatus=0,
                ParentJob=job_id
            )
            session.add(job)

    session = Session(autocommit=True, bind=engine)
    with session.begin():
        pending_claims = session.query(ClaimEligibility).filter(ClaimEligibility.job_eligibility_id == job_id).all()
        claimids = [claim.claimid for claim in pending_claims]

        for i in range(split_into):
            jobid = max_jobid + i + 1
            start = 1 + int(len(claimids) / split_into) * (i)
            end = (i + 1) * int(len(claimids) / split_into)
            print(start, end)
            setclaims = claimids[start:end]
            setclaims = tuple(setclaims)
            session.query(ClaimEligibility).filter(ClaimEligibility.claimid.in_(setclaims)) \
                .update({ClaimEligibility.job_eligibility_id: jobid}, synchronize_session=False)


def stop_all_eligibilityjob_containers(docker_client, license_key):
    containers = docker_client.containers.list()
    number_of_containers = len(containers)
    print("Currently running :", number_of_containers)
    logging.info('[{}][Currently running : {}]'.format(license_key, number_of_containers))
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-eligibility-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            logging.info('[{}][stopping : {}]'.format(license_key, container.image.tags[0]))
            container.kill()

    return number_of_containers


def start_all_eligibility_jobs(docker_client, license_key, chained, sleep_time=60, engine=None):
    containers = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=False)
    with session.begin():
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_claim_eligibility_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
        elg_containers = running_containers(license_key, 'eligibility', docker_client)
        cursor.close()
        connection.close()

    for job in pending_claims:
        print('running : ', job[0])
        logging.info('[{}][running : {}]'.format(license_key, job[0]))
        try:
            existing_cont = [cont for cont in elg_containers if str(job[0]) in cont.name]
            if len(existing_cont) > 0:
                continue

            cont = start_eligibility_job(
                jobid=job[0], license_key=job[1],
                docker_client=docker_client,
                chained="1")
            containers.append(cont)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            logging.error('[{}][{}]'.format(license_key, e))

    return containers


def start_eligibility_job(license_key, jobid, docker_client, chained):
    docker_mode = CONFIGURATION.MODE
    env_variables = dict({'MODE': docker_mode, 'JOB_ID': jobid, 'NETWORK': 'host', "CHAINED": chained})
    print(env_variables)
    cont = docker_client.containers.run(image="eligibility-job-runner", environment=env_variables, detach=True,
                                        name=str(license_key) + '-eligibility-job-runner-' + str(jobid), network="host",
                                        volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}})
    logging.info('[{}][Docker Started]'.format(license_key))
    return cont


def run_eligibility_stage(engine, license_key, token, url, no_redistribution, status, no_status_change=False):
    docker_client = get_docker_client()
    prune_all_containers(docker_client)
    split_count = get_split_count(engine=engine, license_key=license_key)
    if status == 400:
        try:
            create_eligibility_job(engine=engine, license_key=license_key, split_count=split_count)
        except Exception as e:
            print(sys.exc_info())
            logging.error('[{}][{}]'.format(license_key, e))

    start_all_eligibility_jobs(engine=engine, license_key=license_key, docker_client=docker_client, chained="1")
