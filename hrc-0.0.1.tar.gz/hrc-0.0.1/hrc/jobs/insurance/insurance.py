import os
import sys
import time

import sqlalchemy
from hrc.settings import CONFIGURATION
from sqlalchemy import and_
from sqlalchemy.orm import Session
from advancedmd.processing.common import start_job, get_split_count
from hrc.integration_db.models import IClaim
from hrc.processing.processing import get_docker_client, prune_all_containers, running_containers
from hrc.services import logging_service

logging = logging_service('insurance')


def start_insurance_job(license_key, jobid, docker_client, chained):
    docker_mode = CONFIGURATION.MODE
    env_variables = dict({'MODE': docker_mode, 'JOB_ID': jobid, 'NETWORK': 'host', 'CHAINED': chained})
    print(env_variables)
    cont = docker_client.containers.run(image="insurance-job-runner", environment=env_variables, detach=True,
                                        name=str(license_key) + '-insurance-job-runner-' + str(jobid), network="host",
                                        volumes={'C:/workspace/logs': {'bind': '/opt/app/logs', 'mode': 'rw'}})
    logging.info('[{}][Started insurance docker]'.format(license_key))
    return cont


def start_all_insurance_jobs(docker_client, license_key, chained, sleep_time=60, engine=None):
    containers = []
    session = Session(autocommit=True, bind=engine, expire_on_commit=True)
    connection = engine.raw_connection()
    with session.begin():
        cursor = connection.cursor()
        cursor.callproc("pending_claim_insurance_by_license_key", [license_key])
        pending_claims = list(cursor.fetchall())
        pending_claims = sorted(pending_claims, key=lambda tup: tup[2], reverse=True)
        cursor.close()
        connection.close()

    insurance_containers = running_containers(license_key, 'insurance', docker_client)

    for job in pending_claims:
        try:
            existing_cont = [cont for cont in insurance_containers if str(job[0]) in cont.name]
            if len(existing_cont) > 0:
                continue

            print('running : ', job[0])
            logging.info('[{}][running : {}]'.format(license_key, job[0]))
            cont = start_insurance_job(
                jobid=job[0], license_key=job[1],
                docker_client=docker_client,
                chained=chained
            )
            containers.append(cont)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            logging.error('[{}][{}]'.format(license_key, e))
    return containers


def start_successor_insurance_job(engine, claim_demo_job_id, license_key, token, amd_url):
    demo_job_id = create_insurance_job(engine=engine, claim_demo_job_id=claim_demo_job_id, license_key=license_key)
    docker_client = get_docker_client()

    start_job(license_key=license_key, jobid=demo_job_id,image_name='insurance-job-runner', docker_client=docker_client,
              token=token, amd_url=amd_url, no_status_change=False)


def create_insurance_job(engine, license_key, split_count):
    session = Session(bind=engine)
    with session.begin(subtransactions=True):
        claims = session.query(IClaim). \
            filter(
            and_(
                IClaim.IntegrationStatus == 230,
                IClaim.LicenseKey == license_key
            )).all()

        number_of_claims = len(claims)
        if number_of_claims < 100:
            split_count = 2
        elif number_of_claims < 30:
            split_count = 1

        job_size = int(number_of_claims / split_count) + 1

        for i in range(split_count):
            while True:
                try:
                    query = "CALL create_insurance_job(" + str(license_key) + "," \
                            + str(0) + "," + str(job_size) + ' )'
                    print(query)
                    session.execute(sqlalchemy. text(query))
                    break
                except Exception as e:
                    print(sys.exc_info())
                    logging.error('[{}][{}]'.format(license_key, e))
                    time.sleep(10)
    return 0


def run_insurance_stage(engine, license_key, token, url, no_redistribution, status, no_status_change=False):
    docker_client = get_docker_client()
    prune_all_containers(docker_client)

    # put all pending claims on the job
    if no_redistribution is None:
        # create the eligibility job
        split_count = get_split_count(engine=engine, license_key=license_key)
        if status == 230:
            try:
                create_insurance_job(engine, license_key, split_count=split_count)
            except Exception as e:
                print(sys.exc_info())
                logging.error('[{}][{}]'.format(license_key, e))
        # put all pending claims on the job
        # start
        start_all_insurance_jobs(engine=engine, license_key=license_key, docker_client=docker_client, chained="1")
