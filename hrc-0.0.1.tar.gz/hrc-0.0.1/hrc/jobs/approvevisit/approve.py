import os
import sys
import traceback

from advancedmd.processing.common import get_split_count
from django.http import HttpResponse, HttpResponseServerError
from hrc.integration_db.models import VisitApproveJob, SpltVisitApprove, ApprovalVisits
from hrc.processing.processing import prune_all_containers
from hrc.settings import CONFIGURATION
from sqlalchemy import func, and_
from sqlalchemy.orm import Session


def start_visit_job(license_key, jobid, docker_client):
    try:
        docker_mode = CONFIGURATION.MODE

        env_variables = dict({'MODE': docker_mode,
                              'JOB_ID': jobid,
                              'NETWORK': 'host',
                              'LICENSE_KEY': license_key
                              })

        print(env_variables)
        cont = docker_client.containers.run(image="approval-job-runner",
                                            environment=env_variables
                                            , detach=True
                                            , name=str(license_key) + '-visit-approve-job-runner-' + str(jobid)
                                            )

        return cont
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(e, exc_type, exc_tb.tb_lineno)
        traceback.print_exc()
        return HttpResponseServerError(sys.exc_info, status=403)


def start_all_visit_jobs(docker_client, license_key, sleep_time=60, engine=None):
    try:
        containers = []
        # get all the pending visit approvals using license key
        connection = engine.raw_connection()
        cursor = connection.cursor()
        cursor.callproc("pending_visit_approvals_by_license_key", [license_key])
        pending_visits = list(cursor.fetchall())
        pending_visits = sorted(pending_visits, key=lambda tup: tup[1], reverse=True)
        cursor.close()

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(e, exc_type, exc_tb.tb_lineno)
        traceback.print_exc()
        raise Exception(sys.exc_info)

    # create docker containers one by one for every distinct job id
    for job in pending_visits:
        try:
            print('running : ', job[0])
            cont = start_visit_job(
                jobid=job[0], license_key=job[1],
                docker_client=docker_client
            )
            containers.append(cont)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)

    return containers


def create_visit_job(engine, license_key, split_count):
    try:
        session = Session(autocommit=True, bind=engine, expire_on_commit=False)
        with session.begin():
            maxjobid = session.query(func.max(VisitApproveJob.Job_Id)).scalar()
            if maxjobid is None:
                maxjobid = 1
            else:
                maxjobid = maxjobid + 1

            # get visit data from ApproveVisits table with filters [ license_key and status==0 ]
            visits = session.query(ApprovalVisits). \
                filter(
                and_(
                    ApprovalVisits.status == 0,
                    ApprovalVisits.LicenseKey == license_key
                )).all()

            if len(visits) == 0:
                return 0

            for i in range(split_count):
                job_id = maxjobid + i
                job = VisitApproveJob()
                job.LicenseKey = license_key
                job.IntegrationStatus = 0
                job.Job_Id = job_id
                session.add(job)
                print('job id : '+str(job_id))
                # creates subsets of approvals and add to the SpltVisitApprove table
                if i != split_count - 1:
                    subset_approvals = visits[
                                   int(i * (len(visits) / split_count)):int(((i + 1) * (len(visits) / split_count)))]
                else:
                    subset_approvals = visits[int(i * (len(visits) / split_count)):]

                visit_approvals = []
                for visit in subset_approvals:
                    visit_v = SpltVisitApprove()
                    visit_v.IntegrationStatus = 0
                    visit_v.LicenseKey = license_key
                    visit_v.visit_number_approve_id = visit.approve_visits_id
                    visit_v.job_visit_approve_id = job_id

                    visit_approvals.append(visit_v)

                session.add_all(visit_approvals)

            visit_ids = [visit.approve_visits_id for visit in visits]
            # update the status of ApprovalVisits table
            upd = session.query(ApprovalVisits).filter(ApprovalVisits.approve_visits_id.in_(visit_ids)). \
                update({ApprovalVisits.status: 100},
                       synchronize_session=False)
            print(upd)

        return job_id

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(e, exc_type, exc_tb.tb_lineno)
        traceback.print_exc()
        raise Exception(sys.exc_info)

    finally:
        engine.dispose()


def stop_all_visit_job_containers(docker_client, license_key):
    containers = docker_client.containers.list()
    number_of_containers = len(containers)
    print("Currently running :", number_of_containers)
    for container in containers:
        if len(container.image.tags) > 0 and str(license_key) + '-visit-approve-job-runner' in container.image.tags[0]:
            print('stopping : ', container.image.tags[0])
            container.kill()

    return number_of_containers


def run_visit_approval_stage(engine, docker_client, license_key):
    conts = None
    try:
        stop_all_visit_job_containers(docker_client=docker_client, license_key=license_key)
        prune_all_containers(docker_client)

        session = Session(autocommit=True, bind=engine, expire_on_commit=False)
        with session.begin():
            visits = session.query(ApprovalVisits). \
                filter(
                and_(
                    ApprovalVisits.status == 0,
                    ApprovalVisits.LicenseKey == license_key
                )).all()

        if (len(visits)) == 0:
            print('visit approval data not found')

        if (len(visits)) > 0:
            # if pending visits count < 100 ==> then assign only one container/job/split_count
            if (len(visits)) > 100:
                split_count = get_split_count(engine=engine, license_key=license_key)
            else:
                split_count = 1

            try:
                create_visit_job(engine=engine, license_key=license_key, split_count=split_count)
            except:
                print(sys.exc_info())

        conts = start_all_visit_jobs(engine=engine, license_key=license_key, sleep_time=0,
                                     docker_client=docker_client)
        return conts
    except:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        traceback.print_exc()
        raise Exception(sys.exc_info())
