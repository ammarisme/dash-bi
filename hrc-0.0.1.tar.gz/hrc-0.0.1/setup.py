import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="hrc",
    version="0.0.1",
    author="Ammar Ameerdeen",
    author_email="ammar.ofc@gmail.com",
    description="Advanced md integration api",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://ammar_a@bitbucket.org/ammar_a/hrc.git",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3.7",
        "License :: Proprietry",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.5'
)
